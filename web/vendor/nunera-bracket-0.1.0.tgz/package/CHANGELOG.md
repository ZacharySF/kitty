# Changelog

## Unreleased

- Replaced generated placeholder capabilities with the exact 2,431 Core and Advanced requirements from the 332-module reference.
- Added explicit reference-only, partial, Core-complete, and Advanced-complete status derived from export and verification evidence.
- Added real export-backed catalog previews for every registry row mapped to a package export.
- Added Vitest component/unit/SSR coverage, Playwright Chromium/Firefox/WebKit infrastructure, axe WCAG checks, visual snapshots, package-consumer verification, registry integrity checks, and bundle budgets under `pnpm verify`.
- Fixed mobile reflow, collection keyboard navigation, command-terminal focus restoration, persisted custom palettes, color contrast, scoped density, and functional target/type sizes.
- Fixed Drawer modal focus behavior, disabled link Buttons, multi-select values, all-disabled Tabs and radios, duplicate tags, dropped-file validation, Field ARIA wiring, Textarea callback composition, Chip semantics, DataTable keyboard/core states, toast deadlines, Dialog IDs, clipboard SSR guards, AppShell layout, area paths, fractional number steps, and Calendar grid navigation.
- Completed family 24: all 24 headless utility modules now ship verified exports, including `Boundary`, `ClientOnly`, `Show`, `Hide`, scoped hotkey sequences with conflict detection, multi-container sortables with keyboard focus restoration, grid/reverse/sticky virtualization with scroll-to-index, versioned persisted state with URL sync, and a View Transition color-mode reveal.
- Added a requirement evidence ledger (`src/lib/registry/evidence.json`) that the registry generator attaches to requirement IDs and `pnpm test:coverage` validates against real test assertions, so Core status can no longer be claimed without passing evidence.
- Split the client registry projection from the evidence ledger so catalog bundles carry verification flags instead of evidence paths.
- Fixed lazily loaded catalog demo chunks dropping their stylesheet, which left export demos unstyled and failing contrast.
- Fixed ARIA structure and labelling defects surfaced by the new per-family axe scan: Calendar grid rows, Kanban lists and card buttons, Popover trigger composition, Select attribute passthrough, and unlabeled file, color, date, and filter controls.
- Completed all 332 registry modules and attached executable evidence to all 2,431 Core and Advanced requirements; the package now exports 306 Svelte components plus the 24 headless utility modules.
- Added 39 responsive, theme-aware, RTL-safe page blocks with CMS content seams, A/B experiments, a generated recipe registry, and the `bracket list` / `bracket add` source installer.
- Added focused `editor`, `charts`, `media`, `maps`, `blocks`, `registry`, and `testing` package entry points and verified each through an isolated packed-package consumer.
- Added advanced chart interaction/rendering, the shared advanced state/platform controller, and all 30 reduced-motion/offscreen-aware effect exports.
- Added generated Figma mappings, migration, block, accessibility, Kudzu, and release documentation; removed obsolete reference-only preview implementations after every catalog module gained a real export.
- Replaced the SVG-only `Icon` primitive with the bundled Ioskeley Nerd Font glyph set, added the `--br-font-icon` token, and made icon-button glyphs explicitly decorative to assistive technology.
- Extended packed-package verification to execute Kudzu palette compatibility and invoke the installed CLI rather than resolving workspace source.
- Replaced the partial component table with generated documentation for all 306 root-exported components and 1,997 resolved inherited props; internal underscore-prefixed surfaces are excluded.
- Added generated references for all 199 non-component root exports, all 15 package export-map entries, and all 39 block recipes, plus complete CLI and icon contracts and a canonical documentation index.
- Populated Figma mapping properties from resolved component APIs, documented empty non-visual mappings and the absence of a shipped Figma plugin, and added a freshness/coverage/link gate to `pnpm verify`.
- Rewrote the stale repository review and implementation plan as clearly marked historical records, and made private-package and uncompleted manual screen-reader release limitations explicit.

## 0.1.0 — 2026-03-24

- Added the initial Svelte 5 field-terminal component library.
- Added 48 accessible component exports and six headless utility modules.
- Added 14 switchable themes, 16 semantic color roles, scoped theming, palette validation, and three density modes.
- Added Kudzu palette conversion and incremental CSS-variable compatibility.
- Added a 332-module, 26-family reference registry alongside the reusable library exports.
- Added representative reference previews for catalog discovery; these previews are not separate reusable implementations.
