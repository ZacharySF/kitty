# Bracket

Bracket is a field-terminal Svelte 5 component library for Kudzu and related interfaces. The root package exports 306 reusable components and 199 additional typed APIs; focused entries cover all 24 headless utility modules, 39 installable page blocks, a 16-role palette engine, and three density modes. Its executable catalog maps all 332 reference modules across 26 families to public implementations and attaches automated evidence to all 2,431 Core and Advanced requirements.

## Requirements

- Svelte 5.57.2 or newer
- A bundler that consumes Svelte package sources, such as Vite with `@sveltejs/vite-plugin-svelte`

The package is currently `"private": true` and supported for workspace, file, and packed-tarball consumption. It is not configured for npm publication.

## Local Kudzu installation

From `Kudzu/dashboard`:

```sh
pnpm add @nunera/bracket@file:../../Bracket
```

Import the shared stylesheet once in Kudzu's client entry or root layout:

```ts
import '@nunera/bracket/styles.css';
```

Use components directly:

```svelte
<script lang="ts">
  import { Button, Field, Panel, TextInput } from '@nunera/bracket';

  let callsign = $state('field-07');
</script>

<Panel title="Node registration" icon="◇">
  <Field label="Callsign" for="callsign" required>
    {#snippet children(control)}
      <TextInput {...control} bind:value={callsign} />
    {/snippet}
  </Field>
  <Button intent="primary" onclick={() => console.log(callsign)}>Register</Button>
</Panel>
```

Bracket ships Svelte source, not precompiled component JavaScript. This keeps runes, snippets, source maps, and tree-shaking intact in Kudzu's existing Vite pipeline.

## Focused package entry points

The root entry exports the complete API. Heavy families also have explicit tree-shakeable boundaries:

```ts
import { CodeEditor } from '@nunera/bracket/editor';
import { LineChart } from '@nunera/bracket/charts';
import { VideoPlayer } from '@nunera/bracket/media';
import { BracketMap } from '@nunera/bracket/maps';
import { HeroSection } from '@nunera/bracket/blocks';
import { moduleRegistry, blockRegistry } from '@nunera/bracket/registry';
import { auditTheme } from '@nunera/bracket/testing';
```

Install a source-owned block with its shared runtime:

```sh
pnpm exec bracket list
pnpm exec bracket add hero-section --variant split --dir src/lib
```

See [`docs/BLOCKS.md`](docs/BLOCKS.md) for CMS, A/B, registry, and overwrite contracts.

## Theme and density

The palette contract contains exactly 16 semantic roles:

```ts
import { applyTheme, findTheme, type Density, type Theme } from '@nunera/bracket';

const theme: Theme = findTheme('Kudzu');
const density: Density = 'comfortable';
applyTheme(theme, document.documentElement, density);
```

Built-in themes: Kudzu, Sodium Vapor, Flight Deck, Phosphor P1, Amber VDT, Blueprint, Drafting, Oscilloscope, Hazard, Nixie, Soviet, Deep Void, Graphite, and Signal.

Densities are `compact`, `comfortable`, and `spacious`. `applyTheme` sets `data-br-theme`, `data-br-density`, color-scheme, contrast-aware foregrounds, and all `--br-*` variables on the selected root. Pass a subtree root for scoped themes.

`ThemeProvider` applies the same contract declaratively:

```svelte
<script lang="ts">
  import { ThemeProvider, themes } from '@nunera/bracket';
</script>

<ThemeProvider theme={themes[0]} density="compact">
  {#snippet children()}
    <!-- themed surface -->
  {/snippet}
</ThemeProvider>
```

## Incremental Kudzu migration

Kudzu's current palette shape uses `c1` through `c6`. Bracket uses semantic names:

| Kudzu | Bracket |
| --- | --- |
| `c1` | `structure` |
| `c2` | `signal` |
| `c3` | `go` |
| `c4` | `reference` |
| `c5` | `caution` |
| `c6` | `alternate` |

Use the compatibility adapter while old and new components coexist:

```ts
import { applyKudzuPalette, fromKudzuPalette, toKudzuPalette } from '@nunera/bracket';
import { PALETTES } from '$lib/palettes';

applyKudzuPalette(PALETTES[0], document.documentElement, 'comfortable');

const bracketTheme = fromKudzuPalette(PALETTES[0]);
const legacyPalette = toKudzuPalette(bracketTheme);
```

`applyKudzuPalette` applies all Bracket roles and aliases Kudzu's existing `--void`, `--panel`, `--c1` … `--c6`, and `--danger` variables to them. Existing Kudzu CSS therefore remains functional while each surface moves to Bracket. Remove the aliases only after the final legacy stylesheet consumer is gone.

Recommended cutover:

1. Add the package and import `styles.css` once.
2. Replace Kudzu's palette application with `applyKudzuPalette` without changing existing views.
3. Replace local primitives with Bracket components one feature slice at a time.
4. Move feature CSS to `--br-*` semantic roles.
5. Replace `applyKudzuPalette` with `applyTheme`, then delete the old palette module and duplicated primitives.

## Public API reference

The package has 306 root-exported Svelte components. The canonical [component reference](docs/COMPONENTS.md) documents every one—not a curated subset—with resolved inherited props, types, defaults, bindable state, snippets, callbacks, native attributes, registry ownership, data/ARIA hooks, and CSS variables.

All 199 other root exports are documented in the generated [TypeScript and headless API reference](docs/API.md). The [package surface reference](docs/PACKAGE.md) lists every root, focused, JSON, style, wildcard, and executable entry. Use those generated references instead of inferring support from source filenames or this overview.

Native attributes are forwarded only where the component contract says so. Bind only props marked `bindable`; use typed `classes`/`styles` parts only where listed. Underscore-prefixed modules are implementation details even when a pre-1.0 wildcard path can resolve them.

## Headless utilities

The 24 reference utility modules are implemented and verified. Major groups include:

- DOM placement and layering: `portal`, `focusScope`, `dismissableLayer`, `visuallyHidden`, `lockScroll`
- Lifecycle and composition: `createPresence`, `mergeProps`, `Boundary`, `ClientOnly`, `isBrowser`, `whenClient`
- Input and interaction: scoped hotkeys, sortable drag/drop, gestures, press handling, and collections
- Measurement and rendering: virtualization, intersection/size observers, breakpoints, and media queries
- Environment: color mode, locale, messages, idle/visibility, and client guards
- State and data: persistence, undo, clipboard, downloads, announcements, and locale-aware formatting

Import public utilities from the root or their documented `@nunera/bracket/headless/*` path. Exact signatures and return contracts are generated in [`docs/API.md`](docs/API.md).

Start with the complete [`docs` index](docs/README.md). It links foundation contracts, every component and TypeScript API, package entries, theming, icons, blocks and CLI behavior, migration, Kudzu compatibility, Figma limitations, accessibility evidence, and release procedures.

## Catalog

The catalog is an executable requirements registry. It records all 332 reference modules, their exact Core and Advanced requirements, family membership, public exports, and evidence-derived implementation status. Every row renders a real exported component, utility, behavior, or installable block recipe. `pnpm test:coverage` rejects missing exports, requirements, evidence paths, assertions, or stale generated artifacts.

Run the registry demo:

```sh
pnpm install
pnpm dev
```

The demo includes full-text requirement search, family navigation, explicit implementation status, export-backed interactive previews, expandable Core/Advanced contracts, all built-in palettes, persisted live 16-role palette editing, contrast checks, density switching, keyboard collection navigation, keyboard help, and a command terminal.

Terminal commands:

```text
theme <name>
group <family>
density compact|comfortable|spacious
find <capability>
```

## Accessibility and platform behavior

- Semantic native controls and labels
- Visible `:focus-visible` treatment
- Keyboard-operable tabs, radio groups, dialogs, command surfaces, and disclosures
- Live regions for transient feedback
- Reduced-motion and forced-colors accommodations
- Logical properties and RTL-safe layout rules
- Touch targets expanded on coarse pointers
- SSR-safe theme and browser utility guards

Consumers remain responsible for meaningful labels, alternative text, valid table headers, and application-level focus order.

Automated checks do not certify screen-reader usability. Complete the dated NVDA/Firefox, VoiceOver/Safari, and TalkBack/Chrome release matrix in [`docs/ACCESSIBILITY.md`](docs/ACCESSIBILITY.md).

## Verification

```sh
pnpm generate:docs   # regenerate registry, component, API, package, block, and Figma contracts
pnpm test:docs       # verify generated freshness, complete public coverage, and Markdown links
pnpm verify          # docs plus diagnostics, Chromium gates, package consumer, build, and budgets
pnpm verify:release  # verify plus the configured Chromium, Firefox, and WebKit browser matrix
pnpm test:unit       # pure utility, state-transition, registry, and CLI contracts
pnpm test:component  # rendered Svelte behavior
pnpm test:ssr        # server-rendering and browser-global guards
pnpm test:browser    # Chromium interaction and responsive behavior
pnpm test:a11y       # axe WCAG A/AA checks
pnpm test:visual     # Playwright screenshot comparison
pnpm test:package    # isolated packed-package consumer build
pnpm test:coverage   # 26-family/332-module registry integrity
pnpm test:bundle     # production build and chunk/aggregate size budgets
```
