<script lang="ts">
  import Button from '../components/Button.svelte';
  import { ROLES, contrast, themeCss, themes, type Theme } from '../theme';
  interface Props { theme: Theme; onchange: (theme: Theme) => void; onclose: () => void }
  let { theme, onchange, onclose }: Props = $props();
  let draft = $state<Theme>({ ...themes[0] });
  let syncedName = $state('');
  let copied = $state(false);

  $effect(() => {
    if (theme.name !== syncedName) {
      draft = { ...theme };
      syncedName = theme.name;
    }
  });

  function update(role: (typeof ROLES)[number], value: string) {
    draft[role] = value;
    draft = { ...draft };
    onchange(draft);
  }

  function hslToHex(hue: number, saturation: number, lightness: number): string {
    const s = saturation / 100;
    const l = lightness / 100;
    const chroma = (1 - Math.abs(2 * l - 1)) * s;
    const x = chroma * (1 - Math.abs((hue / 60) % 2 - 1));
    const offset = l - chroma / 2;
    const [red, green, blue] = hue < 60 ? [chroma, x, 0] : hue < 120 ? [x, chroma, 0] : hue < 180 ? [0, chroma, x] : hue < 240 ? [0, x, chroma] : hue < 300 ? [x, 0, chroma] : [chroma, 0, x];
    return `#${[red, green, blue].map((channel) => Math.round((channel + offset) * 255).toString(16).padStart(2, '0')).join('')}`;
  }

  function randomize() {
    const dark = contrast(draft.ink, draft.panel) > 4.5;
    ROLES.slice(9, 15).forEach((role, index) => {
      const hue = Math.round((Math.random() * 360 + index * 61) % 360);
      draft[role] = hslToHex(hue, dark ? 62 : 58, dark ? 70 : 38);
    });
    draft = { ...draft };
    onchange(draft);
  }

  async function copy() {
    await navigator.clipboard.writeText(themeCss(draft));
    copied = true;
    setTimeout(() => { copied = false; }, 1200);
  }
</script>

<section class="studio">
  <header><b>PALETTE LAB</b><span>16 semantic roles · live scoped output</span><button aria-label="Close palette editor" onclick={onclose}>×</button></header>
  <div class="tokens">
    {#each ROLES as role (role)}
      <label><input type="color" value={draft[role]} oninput={(event) => update(role, event.currentTarget.value)} /><span>{role}</span><code>{draft[role]}</code></label>
    {/each}
  </div>
  <div class="checks">
    {#each ['ink','mute','dim','structure','signal','go','reference','caution','alternate','danger'] as role (role)}
      <span class:pass={contrast(draft[role as keyof Theme] as string, draft.panel) >= (role === 'ink' ? 7 : role === 'mute' ? 4.5 : 3)}>{role} <b>{contrast(draft[role as keyof Theme] as string, draft.panel).toFixed(2)}:1</b></span>
    {/each}
  </div>
  <footer>
    <Button size="sm" onclick={() => { draft = { ...theme }; onchange(draft); }}>Reset</Button>
    <Button size="sm" intent="reference" onclick={randomize}>Randomize accents</Button>
    <Button size="sm" intent="primary" variant="solid" onclick={copy}>{copied ? 'Copied CSS' : 'Copy CSS'}</Button>
  </footer>
</section>

<style>
  .studio{border:1px solid var(--br-signal);background:var(--br-panel)}
  header{display:grid;grid-template-columns:auto 1fr auto;gap:10px;padding:7px 10px;border-bottom:1px solid var(--br-line);background:var(--br-inset)}
  header b{color:var(--br-signal);font-size:10px;letter-spacing:.18em}header span{color:var(--br-dim);font-size:10px}header button{min-width:24px;min-height:24px;border:0;background:none;color:var(--br-mute)}
  .tokens{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:5px;padding:10px}.tokens label{display:grid;grid-template-columns:24px 1fr auto;align-items:center;gap:6px;padding:4px;border:1px solid var(--br-line);background:var(--br-inset)}
  input{width:24px;height:24px;padding:0;border:1px solid var(--br-line);background:none}.tokens span{color:var(--br-dim);font-size:10px;letter-spacing:.1em;text-transform:uppercase}.tokens code{color:var(--br-mute);font-size:10px}
  .checks{display:grid;grid-template-columns:repeat(auto-fit,minmax(105px,1fr));gap:4px;padding:0 10px 10px}.checks span{padding:3px 5px;border:1px solid color-mix(in srgb,var(--br-danger) 40%,var(--br-line));color:var(--br-danger);font-size:10px}.checks span.pass{border-color:color-mix(in srgb,var(--br-go) 40%,var(--br-line));color:var(--br-go)}.checks b{float:right}
  footer{display:flex;justify-content:flex-end;gap:6px;padding:8px 10px;border-top:1px solid var(--br-line)}
</style>
