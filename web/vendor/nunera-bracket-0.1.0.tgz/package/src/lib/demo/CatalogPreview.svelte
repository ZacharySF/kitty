<script lang="ts">
  import type { CatalogEntry } from '../catalog';
  import { entryOrdinal } from './preview';
  import './preview.css';

  interface Props { entry: CatalogEntry }
  let { entry }: Props = $props();
  const ordinal = $derived(entryOrdinal(entry));

  /* Each loader stays distinct so Vite attaches the chunk's CSS to the right dynamic import. */
  const implementedLoaders = {
    core: () => import('./implemented/ImplementedCore.svelte'),
    controls: () => import('./implemented/ImplementedControls.svelte'),
    rich: () => import('./implemented/ImplementedRich.svelte'),
    utilities: () => import('./implemented/ImplementedUtilities.svelte'),
    systems: () => import('./implemented/ImplementedSystems.svelte')
  };

  function loaderKey(group: string): keyof typeof implementedLoaders {
    if (['foundations', 'layout', 'type', 'actions', 'forms'].includes(group)) return 'core';
    if (['inputs', 'selection', 'datetime', 'special'].includes(group)) return 'controls';
    if (['editors', 'media', 'visualization', 'planning', 'collaboration', 'ai', 'commerce', 'effects'].includes(group)) return 'rich';
    if (group === 'utilities') return 'utilities';
    return 'systems';
  }

  const implementation = $derived(implementedLoaders[loaderKey(entry.group)]());
</script>

<div class="preview" data-preview-id={entry.id} data-preview-ordinal={ordinal}>
  {#await implementation}
    <div class="demo-loading" role="status">Loading export demo…</div>
  {:then module}
    {@const Demo = module.default}
    <Demo {entry} />
  {/await}
</div>
