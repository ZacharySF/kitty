<script lang="ts">
  import type { CatalogEntry } from '../../catalog';
  import Accordion from '../../components/Accordion.svelte';
  import Alert from '../../components/Alert.svelte';
  import AlertDialog from '../../components/AlertDialog.svelte';
  import Backdrop from '../../components/Backdrop.svelte';
  import BottomSheet from '../../components/BottomSheet.svelte';
  import ActionSheet from '../../components/ActionSheet.svelte';
  import BulkActionBar from '../../components/BulkActionBar.svelte';
  import BackToTop from '../../components/BackToTop.svelte';
  import BeforeAfter from '../../components/BeforeAfter.svelte';
  import BasicTable from '../../components/BasicTable.svelte';
  import BottomNavigation from '../../components/BottomNavigation.svelte';
  import AnnouncementBanner from '../../components/AnnouncementBanner.svelte';
  import ConnectionIndicator from '../../components/ConnectionIndicator.svelte';
  import CookieConsent from '../../components/CookieConsent.svelte';
  import ContextMenu from '../../components/ContextMenu.svelte';
  import ErrorBoundaryFallback from '../../components/ErrorBoundaryFallback.svelte';
  import Collapsible from '../../components/Collapsible.svelte';
  import Countdown from '../../components/Countdown.svelte';
  import DescriptionList from '../../components/DescriptionList.svelte';
  import FeedbackWidget from '../../components/FeedbackWidget.svelte';
  import Dock from '../../components/Dock.svelte';
  import Footer from '../../components/Footer.svelte';
  import Hamburger from '../../components/Hamburger.svelte';
  import InfiniteScroll from '../../components/InfiniteScroll.svelte';
  import LocaleSwitcher from '../../components/LocaleSwitcher.svelte';
  import ItemList from '../../components/ItemList.svelte';
  import JsonViewer from '../../components/JsonViewer.svelte';
  import LogViewer from '../../components/LogViewer.svelte';
  import Meter from '../../components/Meter.svelte';
  import ProgressCircle from '../../components/ProgressCircle.svelte';
  import ResultStatus from '../../components/ResultStatus.svelte';
  import FloatingWindow from '../../components/FloatingWindow.svelte';
  import HoverCard from '../../components/HoverCard.svelte';
  import Lightbox from '../../components/Lightbox.svelte';
  import Spinner from '../../components/Spinner.svelte';
  import Avatar from '../../components/Avatar.svelte';
  import Badge from '../../components/Badge.svelte';
  import Breadcrumbs from '../../components/Breadcrumbs.svelte';
  import Button from '../../components/Button.svelte';
  import Card from '../../components/Card.svelte';
  import Chip from '../../components/Chip.svelte';
  import CommandPalette from '../../components/CommandPalette.svelte';
  import DataTable from '../../components/DataTable.svelte';
  import Dialog from '../../components/Dialog.svelte';
  import Drawer from '../../components/Drawer.svelte';
  import EmptyState from '../../components/EmptyState.svelte';
  import Menubar from '../../components/Menubar.svelte';
  import Navbar from '../../components/Navbar.svelte';
  import NavigationMenu from '../../components/NavigationMenu.svelte';
  import NavigationRail from '../../components/NavigationRail.svelte';
  import { Menu } from '../../components/menu';
  import Pagination from '../../components/Pagination.svelte';
  import Panel from '../../components/Panel.svelte';
  import Popover, { type PopoverTriggerProps } from '../../components/Popover.svelte';
  import Progress from '../../components/Progress.svelte';
  import ReadMore from '../../components/ReadMore.svelte';
  import QrCode from '../../components/QrCode.svelte';
  import Skeleton from '../../components/Skeleton.svelte';
  import Stat from '../../components/Stat.svelte';
  import Tabs from '../../components/Tabs.svelte';
  import Timeline from '../../components/Timeline.svelte';
  import Sidebar from '../../components/Sidebar.svelte';
  import SkipLink from '../../components/SkipLink.svelte';
  import StatusIndicator from '../../components/StatusIndicator.svelte';
  import Spreadsheet from '../../components/Spreadsheet.svelte';
  import Stepper from '../../components/Stepper.svelte';
  import TableOfContents from '../../components/TableOfContents.svelte';
  import ToastRegion, { type ToastItem } from '../../components/ToastRegion.svelte';
  import TreeView from '../../components/TreeView.svelte';
  import Tour from '../../components/Tour.svelte';
  import Tooltip from '../../components/Tooltip.svelte';
  import BlockSurface, { type BlockMode } from '../../blocks/_BlockSurface.svelte';

  interface Props { entry: CatalogEntry }
  let { entry }: Props = $props();
  let chipSelected = $state(true);
  let selectedRows = $state<string[]>(['relay']);
  let toasts = $state<ToastItem[]>([]);
  let dialogOpen = $state(false);
  let drawerOpen = $state(false);
  let popoverOpen = $state(false);
  let commandOpen = $state(false);
  let tab = $state('overview');
  let accordion = $state(['mission']);
  let page = $state(3);
  let menuAction = $state('');
  let alertDialogOpen = $state(false);
  let bottomSheetOpen = $state(false);
  let lightboxOpen = $state(false);
  let tourOpen = $state(false);
  let backdropOpen = $state(false);
  let actionSheetOpen = $state(false);
  let navValue = $state('home');
  let sheet = $state([['2', '3', '=A1+B1'], ['', '', '']]);
  let step = $state(1);
  let locale = $state('en');

  const rows = [
    { id: 'relay', subsystem: 'Relay', state: 'Nominal' },
    { id: 'mesh', subsystem: 'Mesh', state: 'Standby' }
  ];
  const columns = [
    { key: 'subsystem' as const, label: 'Subsystem' },
    { key: 'state' as const, label: 'State' }
  ];
  const commands = [
    { id: 'open', label: 'Open telemetry', shortcut: 'T', run: () => undefined },
    { id: 'sync', label: 'Synchronize mesh', shortcut: 'S', run: () => undefined }
  ];
  const contextItems = [{ id: 'inspect', label: 'Inspect relay', icon: '◇', shortcut: 'I', action: () => undefined }];
  const menubarMenus = [{ id: 'file', label: 'File', items: [{ id: 'new', label: 'New mission', action: () => undefined }] }, { id: 'view', label: 'View', items: [{ id: 'telemetry', label: 'Telemetry', action: () => undefined }] }];
  const bulkActions = [{ id: 'archive', label: 'Archive', action: () => undefined }];
  const destinations = [{ id: 'home', label: 'Home', icon: '⌂' }, { id: 'search', label: 'Search', icon: '⌕' }, { id: 'profile', label: 'Profile', icon: '○' }];
  const displayItems = [{ id: 'relay', label: 'Relay', description: 'Online', leading: '◇', trailing: '48 Hz', action: () => undefined }];
  const railDestinations = [{ id: 'home', label: 'Home', icon: '⌂', href: '#home' }, { id: 'search', label: 'Search', icon: '⌕', href: '#search' }, { id: 'profile', label: 'Profile', icon: '○', href: '#profile' }];
  const sidebarSections = [{ label: 'Systems', items: [{ id: 'relay', label: 'Relay', href: '#relay', children: [{ id: 'logs', label: 'Logs', href: '#logs' }] }] }];
</script>

{#snippet overview()}<p>Mission systems nominal.</p>{/snippet}
{#snippet telemetry()}<p>Telemetry at 48 Hz.</p>{/snippet}
{#snippet mission()}<p>Verify route and arm control link.</p>{/snippet}
{#snippet trigger(props: PopoverTriggerProps)}<Button size="sm" {...props}>Details</Button>{/snippet}
{#snippet popoverBody()}<strong>Latency</strong><br />18 ms median{/snippet}
{#snippet tooltipTrigger()}<Button size="sm" variant="ghost">Hover or focus</Button>{/snippet}
{#snippet boundaryContent()}<span>Protected render surface</span>{/snippet}
{#snippet disclosureDemo()}<p>Expanded mission details.</p>{/snippet}
{#snippet hoverTrigger()}<Button size="sm" variant="ghost">Pilot profile</Button>{/snippet}
{#snippet contextTarget()}<div class="row">Right-click telemetry row</div>{/snippet}

<div class="implemented-demo" data-export-demo={entry.exports.join(' ')}>
  {#if entry.group === 'blocks'}
    <BlockSurface mode={entry.id as BlockMode} variant="compact" content={{ title: entry.name, description: 'Responsive, CMS-ready, and available in A/B variants.' }} />
  {:else if entry.id === 'avatar-and-avatar-group'}
    <div class="row"><Avatar name="Michael Kryvonis" status="online" size={42} /><Avatar name="Bracket Operator" status="away" size={42} /></div>
  {:else if entry.id === 'badge'}
    <div class="row"><Badge label="Nominal" intent="success" pulse /><Badge label="Warnings" intent="warning" count={3} /></div>
  {:else if entry.id === 'tag-chip'}
    <div class="row"><Chip label="Telemetry" intent="primary" selected={chipSelected} onclick={() => chipSelected = !chipSelected} removable /><Chip label="ROS 2" intent="reference" /></div>
  {:else if entry.id === 'card'}
    <Card title="Control link" description="Mesh relay connected" interactive selected><span>18 ms round-trip</span></Card>
  {:else if entry.id === 'stat-kpi'}
    <div class="stats"><Stat label="Packets" value="98.7K" delta={12.4} comparison="vs prior" /><Stat label="Latency" value="18 ms" delta={-8.1} lowerIsBetter /></div>
  {:else if entry.id === 'timeline'}
    <Timeline events={[{ title: 'Boot', time: '08:00', intent: 'success' }, { title: 'Mesh joined', time: '08:02', intent: 'primary' }]} />
  {:else if entry.id === 'empty-state'}
    <EmptyState title="No incidents" description="All monitored systems are nominal." glyph="◇" />
  {:else if entry.id === 'status-indicator'}
    <div class="row"><StatusIndicator status="online" label="Relay online" /></div>
  {:else if entry.id === 'list-list-item'}
    <ItemList items={displayItems} dividers dense />
  {:else if entry.id === 'description-list-key-value'}
    <DescriptionList items={[{ term: 'Frequency', description: '48 Hz' }, { term: 'Latency', description: '18 ms' }]} />
  {:else if entry.id === 'tree-view'}
    <TreeView expanded={['systems']} value="relay" nodes={[{ id: 'systems', label: 'Systems', icon: '□', children: [{ id: 'relay', label: 'Relay' }] }]} />
  {:else if entry.id === 'json-viewer-object-inspector'}
    <JsonViewer value={{ state: 'nominal', frequency: 48 }} />
  {:else if entry.id === 'log-viewer'}
    <LogViewer lines={[{ id: 'one', timestamp: '09:00', text: '\u001b[32mRelay online\u001b[0m' }]} />
  {:else if entry.id === 'qr-code'}
    <div class="row"><QrCode value="https://bracket.test" size={92} label="Bracket QR" /></div>
  {:else if entry.id === 'before-after-comparison-slider'}
    <BeforeAfter before="/favicon.svg" after="/favicon.svg" beforeAlt="Before" afterAlt="After" />
  {:else if entry.id === 'countdown-timer-clock'}
    <Countdown mode="stopwatch" running={false} />
  {:else if entry.id === 'table-basic'}
    <BasicTable caption="Telemetry" striped bordered dense columns={[{ key: 'system', label: 'System' }, { key: 'state', label: 'State' }]} rows={[{ system: 'Relay', state: 'Nominal' }]} />
  {:else if entry.id === 'spreadsheet'}
    <Spreadsheet bind:value={sheet} rows={2} columns={3} />
  {:else if entry.id === 'data-grid-data-table'}
    <DataTable {rows} {columns} keyField="id" bind:selected={selectedRows} pageSize={2} />
  {:else if entry.id === 'alert-callout'}
    <Alert title="Link stable" description="All control packets acknowledged." intent="success" dismissible />
  {:else if entry.id === 'toast-snackbar'}
    <div class="row"><Button size="sm" onclick={() => toasts = [{ id: crypto.randomUUID(), title: 'Saved', message: 'Configuration applied.', intent: 'success', duration: 1800 }]}>Show toast</Button></div><ToastRegion bind:toasts />
  {:else if entry.id === 'progress-bar'}
    <Progress value={68} label="Upload" /><Progress indeterminate label="Calibrating" />
  {:else if entry.id === 'skeleton'}
    <Skeleton lines={3} shape="text" />
  {:else if entry.id === 'banner-announcement-bar'}
    <AnnouncementBanner message="Scheduled maintenance at 22:00" actionLabel="Details" dismissible />
  {:else if entry.id === 'progress-circle-ring'}
    <div class="row"><ProgressCircle value={72} label="Synchronization" /></div>
  {:else if entry.id === 'spinner-loader'}
    <div class="row"><Spinner label="Loading telemetry" color="success" /><span>LOADING TELEMETRY</span></div>
  {:else if entry.id === 'meter-gauge'}
    <Meter label="Battery" value={72} low={20} high={80} optimum={90} />
  {:else if entry.id === 'result-status-page'}
    <ResultStatus status="success" title="Mission uploaded" message="All records synchronized." />
  {:else if entry.id === 'error-boundary-fallback'}
    <ErrorBoundaryFallback>{#snippet children()}{@render boundaryContent()}{/snippet}</ErrorBoundaryFallback>
  {:else if entry.id === 'connection-offline-indicator'}
    <div class="row"><ConnectionIndicator /><span>CONNECTION MONITOR ACTIVE</span></div>
  {:else if entry.id === 'cookie-consent'}
    <CookieConsent policyHref="#privacy" />
  {:else if entry.id === 'feedback-widget-survey'}
    <FeedbackWidget mode="emoji" question="Rate this mission" />
  {:else if entry.id === 'modal-dialog'}
    <div class="row"><Button size="sm" onclick={() => dialogOpen = true}>Open dialog</Button></div>
    <Dialog bind:open={dialogOpen} title="Confirm mission"><p>Proceed with the selected route?</p></Dialog>
  {:else if entry.id === 'drawer-sheet'}
    <div class="row"><Button size="sm" onclick={() => drawerOpen = true}>Open drawer</Button></div>
    <Drawer bind:open={drawerOpen} title="Inspector"><p>Runtime diagnostics and controls.</p></Drawer>
  {:else if entry.id === 'popover'}
    <div class="row"><Popover bind:open={popoverOpen} {trigger}>{#snippet children()}{@render popoverBody()}{/snippet}</Popover></div>
  {:else if entry.id === 'tooltip'}
    <div class="row"><Tooltip content="Verified component tooltip" delay={0}>{#snippet children()}{@render tooltipTrigger()}{/snippet}</Tooltip></div>
  {:else if entry.id === 'alert-dialog-confirm'}
    <div class="row"><Button size="sm" intent="danger" onclick={() => alertDialogOpen = true}>Delete mission</Button></div>
    <AlertDialog bind:open={alertDialogOpen} title="Delete mission?" description="This cannot be undone." destructive />
  {:else if entry.id === 'bottom-sheet'}
    <div class="row"><Button size="sm" onclick={() => bottomSheetOpen = true}>Open bottom sheet</Button></div>
    <BottomSheet bind:open={bottomSheetOpen} title="Mission actions"><p>Archive or duplicate this mission.</p></BottomSheet>
  {:else if entry.id === 'hover-card'}
    <div class="row"><HoverCard label="Pilot profile" trigger={hoverTrigger}><p>Operator · Arlington sector</p></HoverCard></div>
  {:else if entry.id === 'lightbox'}
    <div class="row"><Button size="sm" onclick={() => lightboxOpen = true}>Open media viewer</Button></div>
    <Lightbox bind:open={lightboxOpen} items={[{ src: '/favicon.svg', alt: 'Bracket mark' }]} />
  {:else if entry.id === 'tour-onboarding-coachmarks'}
    <div class="row"><Button size="sm" onclick={() => tourOpen = true}>Start tour</Button></div>
    <Tour bind:open={tourOpen} steps={[{ target: '.implemented-demo', title: 'Catalog', description: 'Explore verified modules.' }]} />
  {:else if entry.id === 'floating-window'}
    <div class="window-demo"><FloatingWindow title="Telemetry" x={4} y={4} width="180px" contained><p>48 Hz · nominal</p></FloatingWindow></div>
  {:else if entry.id === 'backdrop-overlay'}
    <div class="row"><Button size="sm" onclick={() => backdropOpen = true}>Show backdrop</Button></div>
    <Backdrop open={backdropOpen} onclick={() => backdropOpen = false} />
  {:else if entry.id === 'command-palette-k'}
    <div class="row"><Button size="sm" onclick={() => commandOpen = true}>Open commands</Button></div><CommandPalette bind:open={commandOpen} {commands} />
  {:else if entry.id === 'dropdown-menu'}
    <Menu.Root onselect={(id) => (menuAction = id)}>
      <Menu.Trigger>Record actions</Menu.Trigger>
      <Menu.Content label="Record actions">
        <Menu.Group label="Edit">
          <Menu.Item label="Rename" shortcut="F2" />
          <Menu.Item label="Duplicate" shortcut="Ctrl D" />
          <Menu.Item label="Archive" disabled />
        </Menu.Group>
        <Menu.Separator />
        <Menu.Item label="Delete" shortcut="Del" />
      </Menu.Content>
    </Menu.Root>
    <span>{menuAction ? 'Action dispatched' : 'No action yet'}</span>
  {:else if entry.id === 'context-menu'}
    <ContextMenu items={contextItems}>{@render contextTarget()}</ContextMenu>
  {:else if entry.id === 'menubar'}
    <Menubar menus={menubarMenus} />
  {:else if entry.id === 'action-sheet'}
    <div class="row"><Button size="sm" onclick={() => actionSheetOpen = true}>Open action sheet</Button></div>
    <ActionSheet bind:open={actionSheetOpen} items={[{ id: 'archive', label: 'Archive mission', action: () => undefined }]} />
  {:else if entry.id === 'bulk-action-bar-selection-toolbar'}
    <BulkActionBar count={3} actions={bulkActions} />
  {:else if entry.id === 'navbar-header-app-bar'}
    <Navbar brand="Bracket" links={[{ label: 'Home', href: '#home', active: true }, { label: 'Docs', href: '#docs' }]} />
  {:else if entry.id === 'hamburger-burger-icon'}
    <div class="row"><Hamburger /><span>Menu</span></div>
  {:else if entry.id === 'navigation-menu-mega-menu'}
    <NavigationMenu groups={[{ id: 'products', label: 'Products', links: [{ label: 'Console', href: '#console', description: 'Mission controls' }] }]} />
  {:else if entry.id === 'sidebar'}
    <Sidebar sections={sidebarSections} active="logs" />
  {:else if entry.id === 'stepper-wizard'}
    <Stepper bind:current={step} steps={[{ id: 'one', label: 'Configure' }, { id: 'two', label: 'Verify' }, { id: 'three', label: 'Launch' }]} />
  {:else if entry.id === 'bottom-navigation-tab-bar'}
    <BottomNavigation bind:value={navValue} items={destinations} />
  {:else if entry.id === 'navigation-rail'}
    <NavigationRail active="home" items={railDestinations} />
  {:else if entry.id === 'table-of-contents-scrollspy'}
    <TableOfContents active="intro" items={[{ id: 'intro', label: 'Introduction' }, { id: 'details', label: 'Details', level: 2 }]} />
  {:else if entry.id === 'skip-link'}
    <div class="row"><SkipLink /><span>Focus the skip link</span></div>
  {:else if entry.id === 'back-to-top'}
    <div class="row"><span>Scroll to reveal</span><BackToTop threshold={0} /></div>
  {:else if entry.id === 'language-locale-switcher'}
    <div class="row"><LocaleSwitcher bind:value={locale} locales={[{ value: 'en', label: 'English' }, { value: 'es', label: 'Español' }]} /></div>
  {:else if entry.id === 'dock'}
    <div class="row"><Dock items={[{ id: 'console', label: 'Console', icon: '◇', action: () => undefined }, { id: 'docs', label: 'Docs', icon: '□', href: '#docs' }]} /></div>
  {:else if entry.id === 'infinite-scroll-load-more'}
    <InfiniteScroll load={() => undefined} auto={false} />
  {:else if entry.id === 'footer'}
    <Footer columns={[{ label: 'Product', links: [{ label: 'Console', href: '#console' }] }]} legal={[{ label: 'Privacy', href: '#privacy' }]} social={[{ label: 'GitHub', href: '#github', icon: '⌘' }]} />
  {:else if entry.id === 'tabs'}
    <Tabs bind:value={tab} tabs={[{ value: 'overview', label: 'Overview', content: overview }, { value: 'telemetry', label: 'Telemetry', content: telemetry }]} />
  {:else if entry.id === 'breadcrumbs'}
    <Breadcrumbs items={[{ label: 'Systems', href: '#display' }, { label: 'Relay', href: '#tables' }, { label: 'Details' }]} />
  {:else if entry.id === 'pagination'}
    <Pagination bind:page pages={8} />
  {:else if entry.id === 'accordion'}
    <Accordion bind:value={accordion} items={[{ value: 'mission', label: 'Mission checklist', content: mission }]} />
  {:else if entry.id === 'panel-section'}
    <Panel title="Telemetry" readout="LIVE" icon="◇"><p>48 Hz · 18 ms · 0 drops</p></Panel>
  {:else if entry.id === 'collapsible-disclosure'}
    <Collapsible label="Mission details">{@render disclosureDemo()}</Collapsible>
  {:else if entry.id === 'read-more-show-more'}
    <ReadMore text="A long mission report with telemetry, operator notes, diagnostics, and recovery instructions for the full field team." maxChars={42} />
  {/if}
</div>

<style>
  .implemented-demo { min-height: 112px; display: grid; align-content: center; gap: 8px; color: var(--br-mute); font-size: 10px; }
  .row { display: flex; place-content: center; align-items: center; gap: 8px; }
  .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
  .window-demo { position: relative; min-height: 112px; }
  p { margin: 0; font-size: 10px; }
  .implemented-demo :global(.br-empty) { min-height: 106px; padding: 8px; }
  .implemented-demo :global(.br-empty__glyph) { font-size: 22px; }
  .implemented-demo :global(.timeline li) { min-height: 42px; }
  .implemented-demo :global([data-block]) { max-height: 220px; overflow: auto; }
</style>
