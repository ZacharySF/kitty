<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { CatalogEntry } from '../../catalog';
  import { formatBytes, formatCurrency, formatDate, formatNumber, formatPercent, formatRelative } from '../../headless/format';
  import { themes } from '../../theme';
  import AppShell from '../../components/AppShell.svelte';
  import Box from '../../components/Box.svelte';
  import AspectRatio from '../../components/AspectRatio.svelte';
  import Center from '../../components/Center.svelte';
  import Container from '../../components/Container.svelte';
  import Divider from '../../components/Divider.svelte';
  import Flex from '../../components/Flex.svelte';
  import Blockquote from '../../components/Blockquote.svelte';
  import Button from '../../components/Button.svelte';
  import ButtonGroup from '../../components/ButtonGroup.svelte';
  import CopyButton from '../../components/CopyButton.svelte';
  import FloatingActionButton from '../../components/FloatingActionButton.svelte';
  import ShareButton from '../../components/ShareButton.svelte';
  import SplitButton from '../../components/SplitButton.svelte';
  import Toggle from '../../components/Toggle.svelte';
  import ToggleGroup from '../../components/ToggleGroup.svelte';
  import Toolbar from '../../components/Toolbar.svelte';
  import CodeBlock from '../../components/CodeBlock.svelte';
  import Heading from '../../components/Heading.svelte';
  import Highlight from '../../components/Highlight.svelte';
  import Icon from '../../components/Icon.svelte';
  import Image from '../../components/Image.svelte';
  import InlineCode from '../../components/InlineCode.svelte';
  import Kbd from '../../components/Kbd.svelte';
  import Link from '../../components/Link.svelte';
  import List from '../../components/List.svelte';
  import Prose from '../../components/Prose.svelte';
  import Spoiler from '../../components/Spoiler.svelte';
  import Text from '../../components/Text.svelte';
  import Watermark from '../../components/Watermark.svelte';
  import Field from '../../components/Field.svelte';
  import Fieldset from '../../components/Fieldset.svelte';
  import Form from '../../components/Form.svelte';
  import InputGroup from '../../components/InputGroup.svelte';
  import Label from '../../components/Label.svelte';
  import Grid from '../../components/Grid.svelte';
  import GridItem from '../../components/GridItem.svelte';
  import Masonry from '../../components/Masonry.svelte';
  import ResizablePanels from '../../components/ResizablePanels.svelte';
  import ScrollArea from '../../components/ScrollArea.svelte';
  import Spacer from '../../components/Spacer.svelte';
  import Sticky from '../../components/Sticky.svelte';
  import IconButton from '../../components/IconButton.svelte';
  import Stack from '../../components/Stack.svelte';
  import TextInput from '../../components/TextInput.svelte';
  import ThemeProvider from '../../components/ThemeProvider.svelte';
  import MessageProvider from '../../components/MessageProvider.svelte';
  import TagsInput from '../../components/TagsInput.svelte';
  import { createLocale } from '../../headless/locale';
  import type { BracketMessages } from '../../headless/messages';
  import { createCollection } from '../../headless/collection';
  import { createControllableState } from '../../headless/controllable';
  import { memoizeOne } from '../../headless/memoize';
  import { computePosition } from '../../headless/positioning';
  import { createPresence } from '../../headless/presence';
  import { press } from '../../headless/press';
  import { catalogStats } from '../../catalog';

  interface Props { entry: CatalogEntry }
  let { entry }: Props = $props();
  let fieldValue = $state('operator@bracket.dev');
  let rtl = $state(false);
  let tags = $state(['حقل', 'شبكة']);
  const locale = createLocale({ locale: 'ar-EG' });
  const arabicMessages: Partial<BracketMessages> = {
    addTagPlaceholder: 'أضف وسماً…',
    removeTag: (values) => `إزالة ${values.tag}`
  };
  let architectureValue = $state(1);
  const architectureState = createControllableState({
    defaultValue: 0,
    controlled: true,
    value: () => architectureValue,
    onChange: (value) => (architectureValue = value)
  });
  const collection = createCollection([
    { id: 'alpha', textValue: 'Alpha' },
    { id: 'disabled', textValue: 'Disabled', disabled: true },
    { id: 'bravo', textValue: 'Bravo' }
  ]);
  let presses = $state(0);
  const summarize = memoizeOne((verified: number, total: number) => `${verified}/${total}`);
  const anchored = computePosition(
    { left: 96, right: 128, top: 40, bottom: 72, width: 32, height: 32 },
    { width: 88, height: 44 },
    { viewport: { width: 240, height: 120 } }
  );
  let motionOpen = $state(true);
  const demoPresence = createPresence(true, { exitDuration: 120 });
  let motionState = $state(demoPresence.state);
  const unsubscribePresence = demoPresence.subscribe(() => (motionState = demoPresence.state));
  $effect(() => demoPresence.set(motionOpen));
  onDestroy(() => { unsubscribePresence(); demoPresence.destroy(); });
</script>

<div class="implemented-demo" data-export-demo={entry.exports.join(' ')}>
  {#if entry.id === 'architecture-and-api'}
    <div class="foundation-sample">
      <span>CONTROLLED VALUE {architectureValue}</span>
      <Button size="sm" onclick={() => architectureState.update((value) => value + 1)}>Transition</Button>
    </div>
  {:else if entry.id === 'accessibility'}
    <div class="foundation-sample">
      <button class="br-btn" use:press={{ onPress: () => (presses += 1) }}>Normalized press {presses}</button>
      <span>ROVING {collection.first()} → {collection.next(collection.first(), 1)}</span>
    </div>
  {:else if entry.id === 'performance'}
    <div class="foundation-sample"><span>MEMOIZED COVERAGE</span><strong>{summarize(catalogStats.coreRequirementsVerified, catalogStats.coreRequirements)}</strong></div>
  {:else if entry.id === 'motion-system'}
    <div class="foundation-sample">
      <Button size="sm" onclick={() => (motionOpen = !motionOpen)}>Toggle presence</Button>
      {#if motionState !== 'exited'}<span class="motion-sample" data-state={motionState}>ENTER / EXIT</span>{/if}
    </div>
  {:else if entry.id === 'modern-platform-integration'}
    <div class="foundation-sample"><span>ANCHOR {anchored.side.toUpperCase()}</span><code>{anchored.x},{anchored.y} · {anchored.transformOrigin}</code></div>
  {:else if entry.id === 'developer-experience'}
    <div class="foundation-sample"><span>MACHINE REGISTRY</span><strong>{catalogStats.modules} MODULES</strong><code>typed · tested · documented</code></div>
  {:else if entry.id === 'theming-and-design-tokens'}
    <ThemeProvider theme={themes[5]} density="compact"><div class="theme-sample">SCOPED BLUEPRINT THEME</div></ThemeProvider>
  {:else if entry.id === 'box-view'}
    <Box padding={{ base: '6px', md: '16px' }} background="raised" border>Responsive token Box</Box>
  {:else if entry.id === 'stack-vstack-hstack'}
    <Stack direction="horizontal" gap="6px">{#each ['STACK', 'WRAP', 'ALIGN'] as item (item)}<span class="cell">{item}</span>{/each}</Stack>
  {:else if entry.id === 'flex'}
    <Flex justify="between" align="center"><span class="cell">FLEX</span><span class="cell">SURFACE</span></Flex>
  {:else if entry.id === 'grid-simple-grid'}
    <Grid columns={{ base: 2, md: 3 }} gap="5px">{#each [1, 2, 3] as item (item)}<GridItem columnSpan={item === 3 ? 2 : 1}><span class="cell">0{item}</span></GridItem>{/each}</Grid>
  {:else if entry.id === 'container'}
    <Container size="sm"><div class="cell">CENTERED CONTAINER</div></Container>
  {:else if entry.id === 'center-square-circle'}
    <Center shape="circle" size="72px"><span>CENTER</span></Center>
  {:else if entry.id === 'spacer'}
    <Flex><span class="cell">START</span><Spacer /><span class="cell">END</span></Flex>
  {:else if entry.id === 'divider-separator'}
    <Divider label="SECTOR" style="dashed" />
  {:else if entry.id === 'aspect-ratio'}
    <AspectRatio ratio="16/9"><div class="cell">16:9 MEDIA</div></AspectRatio>
  {:else if entry.id === 'masonry'}
    <Masonry columns={3}>{#each ['A', 'B', 'C'] as item (item)}<div class="cell">{item}</div>{/each}</Masonry>
  {:else if entry.id === 'resizable-panels-splitter'}
    <ResizablePanels>
      {#snippet first()}<div class="cell">FIRST</div>{/snippet}
      {#snippet second()}<div class="cell">SECOND</div>{/snippet}
    </ResizablePanels>
  {:else if entry.id === 'scroll-area'}
    <ScrollArea orientation="horizontal"><div class="scroll-demo">NATIVE HORIZONTAL SCROLL AREA</div></ScrollArea>
  {:else if entry.id === 'sticky'}
    <!-- svelte-ignore a11y_no_noninteractive_tabindex -->
    <div class="sticky-demo" role="region" tabindex="0" aria-label="Sticky positioning example"><Sticky offset="4px"><span class="cell">STICKY</span></Sticky><span>Scrollable content</span></div>
  {:else if entry.id === 'app-shell'}
    <div class="shell-demo"><AppShell>
      {#snippet header()}<span>HEADER</span>{/snippet}
      {#snippet navigation()}<span>NAV</span>{/snippet}
      {#snippet children()}<span>WORKSPACE</span>{/snippet}
    </AppShell></div>
  {:else if entry.id === 'text'}
    <Text as="span" size="lg" color="signal" clamp={2}>Token text with truncation, clamping, alignment, and polymorphic output.</Text>
  {:else if entry.id === 'heading'}
    <Heading level={3} size="xl" id="demo-heading" anchorLabel="Link to status heading">STATUS HEADING</Heading>
  {:else if entry.id === 'link'}
    <Link href="#catalog" external standalone underline="hover">External reference</Link>
  {:else if entry.id === 'inline-code-and-kbd'}
    <div class="row"><InlineCode>pnpm verify</InlineCode><Kbd keys={['Ctrl', 'K']} /></div>
  {:else if entry.id === 'blockquote'}
    <Blockquote citation="Flight manual"><span>Maintain visual contact with the vehicle.</span></Blockquote>
  {:else if entry.id === 'list'}
    <List marker="→" items={[{ label: 'Inspect', children: [{ label: 'Airframe' }] }, { label: 'Arm' }]} />
  {:else if entry.id === 'prose-typography-wrapper'}
    <Prose><h3>PROSE</h3><p>Consistent rhythm for raw Markdown output.</p></Prose>
  {:else if entry.id === 'highlight-mark'}
    <Highlight text="Signal nominal · Signal stable" query="Signal" />
  {:else if entry.id === 'icon'}
    <div class="foundation-sample"><span>NERD FONT ICONS</span><div class="row"><Icon name="check" label="Complete" size={28} /><Icon name="warn" label="Warning" size={28} /></div></div>
  {:else if entry.id === 'image'}
    <div class="foundation-sample"><Image src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='120'%3E%3Crect width='240' height='120' fill='%23182016'/%3E%3Cpath d='M0 90L60 45l45 32 45-55 90 68' stroke='%236fd3c0' fill='none'/%3E%3C/svg%3E" alt="Telemetry terrain" ratio="16/9" rounded="md" /><span>LAZY IMAGE</span></div>
  {:else if entry.id === 'spoiler'}
    <Spoiler label="Reveal coordinates"><span>32.7357° N · 97.1081° W</span></Spoiler>
  {:else if entry.id === 'watermark'}
    <Watermark text="DRAFT"><div class="cell">MISSION DOCUMENT</div></Watermark>
  {:else if entry.id === 'code-block'}
    <CodeBlock code={'const ready = true;\nrun(ready);'} language="ts" lineNumbers />
  {:else if entry.id === 'formatters'}
    <div class="formats"><span>{formatNumber(12345.67)}</span><span>{formatCurrency(84.2, 'USD')}</span><span>{formatPercent(.873)}</span><span>{formatBytes(5242880)}</span><span>{formatDate(new Date(2026, 0, 2))}</span><span>{formatRelative(new Date(Date.now() - 60_000))}</span></div>
  {:else if entry.id === 'button'}
    <div class="row"><Button intent="primary" variant="solid">Execute</Button><Button loading>Queue</Button></div>
  {:else if entry.id === 'icon-button'}
    <div class="row"><IconButton label="Target" icon="⌖" pressed /><IconButton label="Messages" icon="◇" badge={3} /></div>
  {:else if entry.id === 'button-group'}
    <ButtonGroup items={[{ id: 'inspect', label: 'Inspect' }, { id: 'launch', label: 'Launch', intent: 'success' }]} />
  {:else if entry.id === 'split-button'}
    <SplitButton label="Save mission" actions={[{ id: 'draft', label: 'Save draft' }, { id: 'template', label: 'Save template' }]} />
  {:else if entry.id === 'toggle'}
    <Toggle label="Pin target" icon="⌖" />
  {:else if entry.id === 'toggle-group-segmented-control'}
    <ToggleGroup items={[{ id: 'map', label: 'Map' }, { id: 'video', label: 'Video' }, { id: 'data', label: 'Data' }]} value="map" />
  {:else if entry.id === 'toolbar'}
    <Toolbar groups={[[{ id: 'bold', label: 'Bold', toggle: true }, { id: 'italic', label: 'Italic', toggle: true }], [{ id: 'save', label: 'Save' }]]} />
  {:else if entry.id === 'floating-action-button-speed-dial'}
    <div class="fab-demo"><FloatingActionButton label="Create mission" icon="+" extended style="position:absolute" /></div>
  {:else if entry.id === 'copy-button-clipboard'}
    <CopyButton text="BRACKET-ALPHA" />
  {:else if entry.id === 'share-button'}
    <ShareButton title="Mission status" url="https://example.com/mission" />
  {:else if entry.id === 'form'}
    <Form>
      {#snippet children()}<div class="form-demo"><label for="form-demo-code">Code</label><input id="form-demo-code" name="code" required pattern={'[A-Z]{2}'} minlength="2" maxlength="2" /><label for="form-demo-count">Count</label><input id="form-demo-count" name="count" type="number" min="1" max="5" /><Button type="submit" size="sm">Validate</Button></div>{/snippet}
    </Form>
  {:else if entry.id === 'label'}
    <div class="foundation-sample"><Label for="labeled-demo" required>{#snippet children()}Mission code{/snippet}</Label><TextInput id="labeled-demo" value="BR-07" /></div>
  {:else if entry.id === 'fieldset-form-group'}
    <Fieldset legend="Telemetry">
      {#snippet children()}<TextInput aria-label="Channel" value="Primary" />{/snippet}
    </Fieldset>
  {:else if entry.id === 'input-group-addons'}
    <InputGroup clearable onclear={() => (fieldValue = '')}>
      {#snippet prefix()}<span>$</span>{/snippet}
      {#snippet children()}<TextInput aria-label="Budget" bind:value={fieldValue} />{/snippet}
      {#snippet suffix()}<span>USD</span>{/snippet}
      {#snippet actions()}<Button size="sm">Apply</Button>{/snippet}
    </InputGroup>
  {:else if entry.id === 'field-form-control'}
    <Field label="Operator email" for="demo-email" description="Used for mission alerts" required>
      {#snippet children(control)}<TextInput {...control} bind:value={fieldValue} />{/snippet}
    </Field>
  {:else if entry.id === 'internationalization'}
    <div class="i18n" dir={rtl ? 'rtl' : 'ltr'}>
      <MessageProvider messages={rtl ? arabicMessages : {}}>
        <TagsInput bind:value={tags} max={3} />
      </MessageProvider>
      <span>{locale.locale} · {locale.direction} · {formatNumber(1248.5, {}, { locale: locale.locale })}</span>
      <Button size="sm" onclick={() => (rtl = !rtl)}>{rtl ? 'Switch to English' : 'التبديل إلى العربية'}</Button>
    </div>
  {/if}
</div>

<style>
  .implemented-demo { min-height: 112px; display: grid; align-content: center; gap: 8px; color: var(--br-mute); font-size: 10px; }
  .foundation-sample { display: grid; place-items: center; gap: 7px; min-height: 84px; padding: 8px; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-signal); }
  .foundation-sample strong { color: var(--br-go); font-family: var(--br-font-display); font-size: 17px; }
  .foundation-sample code { color: var(--br-caution); }
  .motion-sample { padding: 5px 9px; border: 1px solid var(--br-signal); }
  .motion-sample[data-state='entered'] { opacity: 1; transform: translateY(0); transition: opacity var(--br-motion-fast), transform var(--br-motion-fast); }
  .motion-sample[data-state='exiting'] { opacity: 0; transform: translateY(4px); transition: opacity var(--br-motion-fast), transform var(--br-motion-fast); }
  .row { display: flex; place-content: center; align-items: center; gap: 8px; }
  .cell, .theme-sample { display: grid; place-items: center; min-height: 34px; padding: 6px; border: 1px solid var(--br-line); background: var(--br-raised); color: var(--br-ink); }
  .theme-sample { min-height: 76px; border-color: var(--br-signal); background: var(--br-panel); color: var(--br-signal); }
  .scroll-demo { width: 420px; padding: 12px; color: var(--br-caution); white-space: nowrap; }
  .sticky-demo { height: 92px; overflow: auto; display: grid; gap: 48px; border: 1px solid var(--br-line); }
  .shell-demo { height: 108px; overflow: hidden; border: 1px solid var(--br-line); }
  .shell-demo :global(.shell) { height: 108px !important; font-size: 9px; }
  .shell-demo :global(header), .shell-demo :global(nav), .shell-demo :global(main) { display: grid; place-items: center; padding: 4px; }
  .fab-demo { position: relative; min-height: 84px; overflow: hidden; }
  .form-demo { display: grid; grid-template-columns: auto minmax(0, 1fr); align-items: center; gap: 5px; }
  .form-demo input { border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-ink); }
  .form-demo :global(.br-btn) { grid-column: 2; }
  .formats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 4px; }
  .formats span { padding: 4px; border: 1px solid var(--br-line); color: var(--br-caution); }
</style>
