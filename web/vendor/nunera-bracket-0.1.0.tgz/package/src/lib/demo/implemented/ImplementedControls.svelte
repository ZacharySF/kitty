<script lang="ts">
  import type { CatalogEntry } from '../../catalog';
  import Calendar from '../../components/Calendar.svelte';
  import Checkbox from '../../components/Checkbox.svelte';
  import Cascader from '../../components/Cascader.svelte';
  import CheckboxGroup from '../../components/CheckboxGroup.svelte';
  import ColorPicker from '../../components/ColorPicker.svelte';
  import DatePicker from '../../components/DatePicker.svelte';
  import DateRangePicker from '../../components/DateRangePicker.svelte';
  import DateTimePicker from '../../components/DateTimePicker.svelte';
  import DurationInput from '../../components/DurationInput.svelte';
  import EmojiPicker from '../../components/EmojiPicker.svelte';
  import FilterBuilder from '../../components/FilterBuilder.svelte';
  import Combobox from '../../components/Combobox.svelte';
  import FileUpload from '../../components/FileUpload.svelte';
  import Editable from '../../components/Editable.svelte';
  import MaskedInput from '../../components/MaskedInput.svelte';
  import ImageCropper from '../../components/ImageCropper.svelte';
  import NumberInput from '../../components/NumberInput.svelte';
  import Knob from '../../components/Knob.svelte';
  import MentionInput from '../../components/MentionInput.svelte';
  import PasswordInput from '../../components/PasswordInput.svelte';
  import RadioGroup from '../../components/RadioGroup.svelte';
  import PhoneInput from '../../components/PhoneInput.svelte';
  import PeriodPicker from '../../components/PeriodPicker.svelte';
  import PinInput from '../../components/PinInput.svelte';
  import Rating from '../../components/Rating.svelte';
  import SelectListbox from '../../components/SelectListbox.svelte';
  import SearchInput from '../../components/SearchInput.svelte';
  import Select from '../../components/Select.svelte';
  import Slider from '../../components/Slider.svelte';
  import Switch from '../../components/Switch.svelte';
  import SignaturePad from '../../components/SignaturePad.svelte';
  import TimePicker from '../../components/TimePicker.svelte';
  import TimeSlotPicker from '../../components/TimeSlotPicker.svelte';
  import TimeZoneSelect from '../../components/TimeZoneSelect.svelte';
  import TransferList from '../../components/TransferList.svelte';
  import TreeSelect from '../../components/TreeSelect.svelte';
  import TagsInput from '../../components/TagsInput.svelte';
  import Textarea from '../../components/Textarea.svelte';
  import TextInput from '../../components/TextInput.svelte';

  interface Props { entry: CatalogEntry }
  let { entry }: Props = $props();
  let text = $state('Telemetry online');
  let notes = $state('Preflight complete.');
  let number = $state(1.5);
  let password = $state('Bracket42!');
  let search = $state('virtualizer');
  let tags = $state(['svelte', 'typed']);
  let pin = $state('2608');
  let masked = $state('(817) 555-1212');
  let phone = $state('(817) 555-1212');
  let editable = $state('Mission Alpha');
  let checkboxValues = $state(['alpha']);
  let listboxValue = $state<string | string[]>('alpha');
  let comboValue = $state('');
  let mention = $state('');
  let cascade = $state<string[]>([]);
  let treeValue = $state<string | string[]>('');
  let transfer = $state(['beta']);
  let knob = $state(42);
  let rating = $state(3.5);
  let color = $state('#6fd3c0');
  let checked = $state<boolean | 'indeterminate'>('indeterminate');
  let radio = $state('automatic');
  let switched = $state(true);
  let selected = $state<string | string[]>('alpha');
  let range = $state(64);
  let date = $state('2026-01-15');
  let files = $state<File[]>([]);
  let dateRange = $state({ start: '2026-01-10', end: '2026-01-15' });
  let time = $state('13:30:00');
  let dateTime = $state('2026-01-15T13:30:00');
  let period = $state('2026-Q2');
  let duration = $state({ hours: 1, minutes: 25, seconds: 0 });
  let zone = $state('UTC');
  let slot = $state('');
  let rules = $state([{ id: 'status-rule', field: 'status', operator: 'equals', value: 'nominal' }]);
  const options = [
    { value: 'alpha', label: 'Alpha channel' },
    { value: 'beta', label: 'Beta channel' }
  ];
</script>

<div class="implemented-demo" data-export-demo={entry.exports.join(' ')}>
  {#if entry.id === 'text-input'}
    <TextInput bind:value={text} prefix="[" suffix="]" clearable aria-label="Telemetry status" />
  {:else if entry.id === 'textarea'}
    <Textarea bind:value={notes} autoGrow maxLength={80} aria-label="Mission notes" />
  {:else if entry.id === 'number-input'}
    <NumberInput bind:value={number} step={0.1} min={0} max={9} unit="V" aria-label="Bus voltage" />
  {:else if entry.id === 'password-input'}
    <PasswordInput bind:value={password} showStrength aria-label="Ground station password" />
  {:else if entry.id === 'search-input'}
    <SearchInput bind:value={search} shortcut="/" />
  {:else if entry.id === 'pin-otp-input'}
    <div class="input-sample"><span>ACCESS CODE</span><PinInput bind:value={pin} length={4} label="Access code" /></div>
  {:else if entry.id === 'masked-input'}
    <div class="input-sample"><span>MASKED PHONE</span><MaskedInput bind:value={masked} mask="phone" aria-label="Masked phone number" /></div>
  {:else if entry.id === 'phone-input'}
    <PhoneInput bind:value={phone} label="Operations phone" />
  {:else if entry.id === 'tags-input'}
    <TagsInput bind:value={tags} max={5} />
  {:else if entry.id === 'editable-inline-edit'}
    <Editable bind:value={editable} label="Mission name" />
  {:else if entry.id === 'checkbox'}
    <Checkbox bind:checked label="Arm telemetry" description="Send diagnostics during flight" />
  {:else if entry.id === 'checkbox-group'}
    <CheckboxGroup bind:value={checkboxValues} label="Channels" {options} selectAll orientation="horizontal" />
  {:else if entry.id === 'select-listbox'}
    <SelectListbox bind:value={listboxValue} label="Custom channel" {options} placeholder="Choose channel" />
  {:else if entry.id === 'combobox-autocomplete'}
    <div class="input-sample"><span>SEARCH CHANNEL</span><Combobox bind:value={comboValue} label="Search channel" {options} clearable /></div>
  {:else if entry.id === 'mention-input'}
    <div class="input-sample"><span>MENTION INPUT</span><MentionInput bind:value={mention} label="Message" suggestions={[{ value: 'pilot', label: 'Pilot' }, { value: 'control', label: 'Control' }]} /></div>
  {:else if entry.id === 'cascader'}
    <Cascader bind:value={cascade} label="Location" options={[{ value: 'us', label: 'United States', children: [{ value: 'tx', label: 'Texas', children: [{ value: 'dfw', label: 'Dallas' }] }] }]} />
  {:else if entry.id === 'tree-select'}
    <TreeSelect bind:value={treeValue} label="Assets" nodes={[{ value: 'air', label: 'Aircraft', children: [{ value: 'drone', label: 'Drone' }] }]} />
  {:else if entry.id === 'transfer-list-dual-listbox'}
    <TransferList bind:value={transfer} label="Assignments" items={options} />
  {:else if entry.id === 'knob-dial-angle-slider'}
    <Knob bind:value={knob} label="Gain" />
  {:else if entry.id === 'rating'}
    <Rating bind:value={rating} label="Quality" />
  {:else if entry.id === 'color-picker'}
    <ColorPicker bind:value={color} label="Signal color" swatches={['#6fd3c0', '#ff5964']} />
  {:else if entry.id === 'radio-group'}
    <RadioGroup bind:value={radio} label="Control mode" options={[{ value: 'automatic', label: 'Automatic' }, { value: 'manual', label: 'Manual' }]} orientation="horizontal" />
  {:else if entry.id === 'switch'}
    <Switch bind:checked={switched} label="Live sync" />
  {:else if entry.id === 'native-select'}
    <Select bind:value={selected} {options} placeholder="Choose channel" aria-label="Telemetry channel" />
  {:else if entry.id === 'slider-range-slider'}
    <Slider bind:value={range} label="Output" unit="%" showTooltip />
  {:else if entry.id === 'calendar'}
    <Calendar bind:value={date} month={new Date(2026, 0, 1)} />
  {:else if entry.id === 'date-picker'}
    <DatePicker bind:value={date} />
  {:else if entry.id === 'date-range-picker'}
    <DateRangePicker bind:value={dateRange} />
  {:else if entry.id === 'time-picker'}
    <TimePicker bind:value={time} hour12 minuteStep={5} />
  {:else if entry.id === 'date-time-picker'}
    <DateTimePicker bind:value={dateTime} />
  {:else if entry.id === 'month-year-quarter-picker'}
    <PeriodPicker bind:value={period} mode="quarter" minYear={2026} maxYear={2027} />
  {:else if entry.id === 'duration-input'}
    <DurationInput bind:value={duration} />
  {:else if entry.id === 'time-zone-select'}
    <TimeZoneSelect bind:value={zone} zones={['UTC', 'America/Chicago']} />
  {:else if entry.id === 'time-slot-booking-picker'}
    <TimeSlotPicker bind:value={slot} days={[{ date: '2026-01-15', slots: [{ time: '09:00' }, { time: '10:30' }] }]} />
  {:else if entry.id === 'file-upload-dropzone'}
    <FileUpload bind:files accept="text/plain,.md" maxFiles={2} maxSize={1048576} />
  {:else if entry.id === 'image-cropper-editor'}
    <ImageCropper src="/favicon.svg" alt="Bracket mark" aspect={16/9} />
  {:else if entry.id === 'signature-pad'}
    <div class="input-sample"><span>SIGNATURE PAD</span><SignaturePad width={240} height={72} /></div>
  {:else if entry.id === 'emoji-picker'}
    <EmojiPicker />
  {:else if entry.id === 'filter-builder-query-builder'}
    <FilterBuilder bind:rules fields={[{ id: 'status', label: 'Status', operators: ['equals', 'not equals'] }]} />
  {/if}
</div>

<style>
  .implemented-demo { min-height: 112px; display: grid; align-content: center; gap: 8px; color: var(--br-mute); font-size: 10px; }
  .implemented-demo :global(.calendar) { max-width: 250px; margin: auto; }
  .implemented-demo :global(.calendar .grid button), .implemented-demo :global(.calendar header button) { height: 22px; min-width: 22px; }
  .implemented-demo :global(.calendar .week), .implemented-demo :global(.calendar .grid) { padding: 1px 4px; }
</style>
