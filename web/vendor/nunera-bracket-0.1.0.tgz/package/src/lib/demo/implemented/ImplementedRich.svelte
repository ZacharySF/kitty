<script lang="ts">
  import type { CatalogEntry } from '../../catalog';
  import type { Component } from 'svelte';
  import AreaChart from '../../components/AreaChart.svelte';
  import BarChart from '../../components/BarChart.svelte';
  import BoxPlot from '../../components/BoxPlot.svelte';
  import BulletChart from '../../components/BulletChart.svelte';
  import CalendarHeatmap from '../../components/CalendarHeatmap.svelte';
  import CandlestickChart from '../../components/CandlestickChart.svelte';
  import Chart, { type ChartProps } from '../../components/Chart.svelte';
  import ChordDiagram from '../../components/ChordDiagram.svelte';
  import Funnel from '../../components/Funnel.svelte';
  import GaugeChart from '../../components/GaugeChart.svelte';
  import GeoMap from '../../components/GeoMap.svelte';
  import GroupedBarChart from '../../components/GroupedBarChart.svelte';
  import Heatmap from '../../components/Heatmap.svelte';
  import Histogram from '../../components/Histogram.svelte';
  import LineChart from '../../components/LineChart.svelte';
  import NetworkGraph from '../../components/NetworkGraph.svelte';
  import ParallelCoordinates from '../../components/ParallelCoordinates.svelte';
  import PieChart from '../../components/PieChart.svelte';
  import RadarChart from '../../components/RadarChart.svelte';
  import RadialBarChart from '../../components/RadialBarChart.svelte';
  import Sankey from '../../components/Sankey.svelte';
  import ScatterChart from '../../components/ScatterChart.svelte';
  import Sparkline from '../../components/Sparkline.svelte';
  import StackedAreaChart from '../../components/StackedAreaChart.svelte';
  import StackedBarChart from '../../components/StackedBarChart.svelte';
  import Sunburst from '../../components/Sunburst.svelte';
  import Treemap from '../../components/Treemap.svelte';
  import ViolinPlot from '../../components/ViolinPlot.svelte';
  import Waterfall from '../../components/Waterfall.svelte';
  import Chat from '../../components/Chat.svelte';
  import Kanban, { type KanbanColumn } from '../../components/Kanban.svelte';
  import PromptInput from '../../components/PromptInput.svelte';
  import EditorSurface, { type EditorMode } from '../../components/_EditorSurface.svelte';
  import MediaSurface, { type MediaMode } from '../../components/_MediaSurface.svelte';
  import PlanningSurface, { type PlanningMode } from '../../components/_PlanningSurface.svelte';
  import CollaborationSurface, { type CollaborationMode } from '../../components/_CollaborationSurface.svelte';
  import AISurface, { type AIMode } from '../../components/_AISurface.svelte';
  import CommerceSurface, { type CommerceMode } from '../../components/_CommerceSurface.svelte';
  import EffectSurface, { type EffectMode } from '../../components/_EffectSurface.svelte';

  interface Props { entry: CatalogEntry }
  let { entry }: Props = $props();
  let columns = $state<KanbanColumn[]>([
    { id: 'todo', title: 'QUEUED', cards: [{ id: 'route', title: 'Verify route', tags: ['nav'] }] },
    { id: 'done', title: 'DONE', cards: [{ id: 'mesh', title: 'Join mesh', tags: ['net'] }] }
  ]);
  let prompt = $state('Summarize telemetry anomalies');
  const series = [{ name: 'Latency', points: [{ x: 0, y: 18 }, { x: 1, y: 24 }, { x: 2, y: 16 }, { x: 3, y: 20 }] }];
  const messages = [
    { id: 'one', role: 'user' as const, content: 'Mesh status?' },
    { id: 'two', role: 'assistant' as const, content: 'All four relays are connected.', status: 'sent' as const }
  ];
  const chartDemos: Record<string, Component<Omit<ChartProps, 'type'>>> = {
    'line-chart': LineChart, 'area-chart': AreaChart, 'stacked-area-streamgraph': StackedAreaChart,
    'bar-column-chart': BarChart, 'grouped-bar-chart': GroupedBarChart, 'stacked-bar-chart': StackedBarChart,
    'pie-donut-chart': PieChart, 'scatter-bubble-chart': ScatterChart, 'radar-chart': RadarChart,
    'radial-bar-chart': RadialBarChart, heatmap: Heatmap, 'calendar-heatmap': CalendarHeatmap,
    treemap: Treemap, sunburst: Sunburst, sankey: Sankey, funnel: Funnel,
    'candlestick-ohlc': CandlestickChart, 'box-plot': BoxPlot, histogram: Histogram,
    'violin-plot': ViolinPlot, waterfall: Waterfall, 'gauge-chart': GaugeChart,
    'bullet-chart': BulletChart, 'network-force-graph': NetworkGraph, 'chord-diagram': ChordDiagram,
    'choropleth-geo-map': GeoMap, 'parallel-coordinates': ParallelCoordinates,
    'shared-chart-features': Chart, sparkline: Sparkline
  };
  const Visualization = $derived(chartDemos[entry.id]);
</script>

<div class="implemented-demo" data-export-demo={entry.exports.join(' ')}>
  {#if Visualization}
    <Visualization {series} height={entry.id === 'sparkline' ? 40 : 120} label={entry.name} />
  {:else if entry.group === 'editors'}
    <EditorSurface mode={entry.id as EditorMode} />
  {:else if entry.group === 'media'}
    <MediaSurface mode={entry.id as MediaMode} />
  {:else if entry.id === 'kanban-board'}
    <Kanban bind:columns />
  {:else if entry.group === 'planning'}
    <PlanningSurface mode={entry.id as PlanningMode} />
  {:else if entry.group === 'collaboration'}
    <CollaborationSurface mode={entry.id as CollaborationMode} />
  {:else if entry.id === 'chat-message-list'}
    <Chat {messages} />
  {:else if entry.id === 'prompt-input-composer'}
    <PromptInput bind:value={prompt} onsend={(value) => prompt = `Sent: ${value}`} />
  {:else if entry.group === 'ai'}
    <AISurface mode={entry.id as AIMode} />
  {:else if entry.group === 'commerce'}
    <CommerceSurface mode={entry.id as CommerceMode} />
  {:else if entry.group === 'effects'}
    <EffectSurface mode={entry.id as EffectMode} />
  {/if}
</div>

<style>
  .implemented-demo { min-height: 112px; display: grid; align-content: center; gap: 8px; color: var(--br-mute); font-size: 10px; }
  .implemented-demo :global(.kanban) { max-height: 110px; overflow: auto; }
  .implemented-demo :global(.chat) { max-height: 110px; }
</style>
