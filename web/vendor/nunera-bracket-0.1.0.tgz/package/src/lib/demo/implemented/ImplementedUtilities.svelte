<script lang="ts">
  import type { CatalogEntry } from '../../catalog';
  import Boundary from '../../components/Boundary.svelte';
  import ClientOnly from '../../components/ClientOnly.svelte';
  import { createAnnouncer } from '../../headless/announcer';
  import { isBrowser, whenClient } from '../../headless/client';
  import { readClipboard, writeClipboard } from '../../headless/clipboard';
  import { colorModeScript, createColorMode } from '../../headless/color-mode';
  import { dismissableLayer } from '../../headless/dismissable-layer';
  import { download } from '../../headless/download';
  import { createSortable } from '../../headless/drag-drop';
  import { focusScope } from '../../headless/focus-scope';
  import { gestures } from '../../headless/gestures';
  import { createHotkeys } from '../../headless/hotkeys';
  import { createIdleVisibility } from '../../headless/idle';
  import { createLocale } from '../../headless/locale';
  import { inView, measure } from '../../headless/observers';
  import { createPersistedState } from '../../headless/persisted';
  import { portal } from '../../headless/portal';
  import { createPresence } from '../../headless/presence';
  import { lockScroll } from '../../headless/scroll-lock';
  import { mergeProps } from '../../headless/slot';
  import { createUndoManager } from '../../headless/undo';
  import { calculateVirtualItems, createVirtualizer } from '../../headless/virtualizer';
  import { visuallyHidden } from '../../headless/visually-hidden';
  import Show from '../../components/Show.svelte';
  import Hide from '../../components/Hide.svelte';

  interface Props { entry: CatalogEntry }
  let { entry }: Props = $props();
  let status = $state('Ready');

  const hotkeys = createHotkeys([{ keys: 'ctrl+k', description: 'Open command palette', handler: () => undefined }]);
  const virtual = calculateVirtualItems(240, 120, { count: 1000, estimateSize: () => 24, overscan: 2 });
  const controller = createVirtualizer({ count: 1000, estimateSize: () => 24, sticky: [0] });
  const sortableItems = ['Alpha', 'Bravo', 'Charlie'];
  let sorted = $state([...sortableItems]);
  const sortable = createSortable(sortableItems, { onmove: (next) => { sorted = next; } });
  const presence = createPresence(true, { exitDuration: 120 });
  const locale = createLocale({ locale: 'ar-EG' });
  const merged = mergeProps({ class: 'base' }, { class: 'consumer', style: { color: 'currentColor' } });
  const mergedClass = String(merged.class ?? '');
  const mergedStyle = String(merged.style ?? '');
  const undo = createUndoManager('draft');
  undo.commit('Publish', 'published');
  const memoryStorage = {
    getItem: () => null,
    setItem: () => undefined,
    removeItem: () => undefined
  } as unknown as Storage;
  const persisted = createPersistedState('bracket-preview', 'restored', { storage: memoryStorage });
  const colorMode = isBrowser ? createColorMode({ storageKey: 'bracket-preview-color-mode' }) : null;

  function report(next: string) { status = next; }
  function announce() {
    const announcer = createAnnouncer();
    announcer.announce('Preview announced');
    status = 'Announced';
    setTimeout(() => announcer.destroy(), 500);
  }
  function beginIdle() {
    const idle = createIdleVisibility({ timeout: 10 });
    status = `Tracking · visible ${idle.visible}`;
    setTimeout(() => idle.destroy(), 50);
  }
  function lockPage() {
    const unlock = lockScroll();
    status = 'Scroll locked';
    setTimeout(() => { unlock(); status = 'Scroll restored'; }, 300);
  }
  async function copy() {
    await writeClipboard('Bracket clipboard export');
    status = 'Copied';
  }
  async function paste() {
    try { status = await readClipboard(); }
    catch { status = 'Read unavailable'; }
  }
</script>

<div class="implemented-demo" data-export-demo={entry.exports.join(' ')}>
  {#if entry.id === 'portal'}
    <div id="utility-portal-target"></div><span use:portal={{ target: '#utility-portal-target' }}>Portaled content</span>
  {:else if entry.id === 'focus-scope-focus-trap'}
    <div class="row" use:focusScope={{ autofocus: false, contain: false, restoreFocus: false }}><button>First</button><button>Last</button></div>
  {:else if entry.id === 'dismissable-layer'}
    <div class="layer" use:dismissableLayer={{ ondismiss: (reason) => report(`Dismissed by ${reason}`), outside: false, escape: false }}>Top dismissable layer</div>
  {:else if entry.id === 'visually-hidden'}
    <span use:visuallyHidden>Screen-reader label</span><span>Visually hidden semantic label</span>
  {:else if entry.id === 'presence'}
    <span>Presence: <b>{presence.state}</b> · mounted {String(presence.mounted)}</span>
  {:else if entry.id === 'slot-aschild'}
    <span class={mergedClass} style={mergedStyle}>Merged class and style props</span>
  {:else if entry.id === 'live-announcer'}
    <button onclick={announce}>Announce update</button><output>{status}</output>
  {:else if entry.id === 'hotkeys-manager'}
    <kbd>CTRL + K</kbd><span>{hotkeys.list().length} registered binding · {hotkeys.conflicts().length} conflicts</span>
  {:else if entry.id === 'drag-and-drop-sortable'}
    <div class="row">{#each sorted as item (item)}<button use:sortable.sensor={item} onclick={() => sortable.move(item, 'right')}>{item}</button>{/each}</div>
  {:else if entry.id === 'virtualizer'}
    <div class="virtual"><b>{virtual.items.length}</b><span>rendered of 1,000</span><small>{controller.scrollToIndex(20)}px target</small></div>
  {:else if entry.id === 'in-view-intersection-observer'}
    <div use:inView={{ onchange: (item) => report(item.isIntersecting ? 'In view' : 'Out of view') }}>Intersection-observed region</div>
  {:else if entry.id === 'measure-resize-observer'}
    <div use:measure={{ onchange: (rect) => report(`${Math.round(rect.width)}px wide`) }}>Resize-observed region</div>
  {:else if entry.id === 'media-query-and-breakpoint'}
    <Show above="48rem" fallback={narrow}><span>Desktop layout via <b>Show</b></span></Show>
    <Hide above="48rem"><span>Compact layout via <b>Hide</b></span></Hide>
  {:else if entry.id === 'color-mode-theme-toggle'}
    <button onclick={(event) => report(`Mode ${colorMode?.toggle({ x: event.clientX, y: event.clientY }) ?? 'unavailable'}`)}>Toggle color mode</button><output>{status}</output><small>{colorModeScript().length} byte pre-hydration script</small>
  {:else if entry.id === 'locale-and-direction-providers'}
    <span>{locale.locale} · direction <b>{locale.direction}</b> · {locale.timeZone}</span>
  {:else if entry.id === 'client-only-no-ssr'}
    <ClientOnly><span>Client ready: {String(isBrowser)} · {whenClient.name}</span>{#snippet fallback()}<span>Hydration-safe fallback</span>{/snippet}</ClientOnly>
  {:else if entry.id === 'clipboard-hook'}
    <div class="row"><button onclick={copy}>Copy</button><button onclick={paste}>Paste</button></div><output>{status}</output>
  {:else if entry.id === 'undo-redo-manager'}
    <div class="row"><button onclick={() => undo.undo()}>Undo</button><button onclick={() => undo.redo()}>Redo</button></div><span>{undo.current} · undo {undo.canUndo ? 'ready' : 'empty'}</span>
  {:else if entry.id === 'persisted-state'}
    <span>Current value: <b>{persisted.current}</b></span><button onclick={() => persisted.current = 'updated'}>Persist update</button>
  {:else if entry.id === 'error-and-suspense-boundaries'}
    <Boundary><span>Boundary content rendered</span>{#snippet pending()}<span>Pending</span>{/snippet}{#snippet failed(error)}<span>{String(error)}</span>{/snippet}</Boundary>
  {:else if entry.id === 'scroll-lock'}
    <button onclick={lockPage}>Lock page briefly</button><output>{status}</output>
  {:else if entry.id === 'click-outside-long-press-gestures'}
    <button use:gestures={{ onlongpress: () => report('Long press'), onswipe: (detail) => report(`Swipe ${detail.direction}`) }}>Hold or swipe</button><output>{status}</output>
  {:else if entry.id === 'idle-and-page-visibility'}
    <button onclick={beginIdle}>Track activity</button><output>{status}</output>
  {:else if entry.id === 'download-helper'}
    <button onclick={() => download('data:text/plain,Bracket', { filename: 'bracket.txt' })}>Download sample</button>
  {/if}
</div>

{#snippet narrow()}
  <span>Narrow viewport fallback</span>
{/snippet}

<style>
  .implemented-demo { min-height: 112px; display: grid; place-content: center; gap: 8px; color: var(--br-mute); font-size: 10px; text-align: center; }
  .row { display: flex; justify-content: center; gap: 6px; }
  .layer { border: 1px dashed var(--br-line); padding: 12px; }
  button { min-width: 54px; min-height: 28px; border: 1px solid var(--br-line); background: var(--br-panel); color: var(--br-signal); }
  output, b { color: var(--br-caution); }
  .virtual { display: grid; gap: 3px; }
  .virtual b { font-family: var(--br-font-display); font-size: 24px; }
</style>
