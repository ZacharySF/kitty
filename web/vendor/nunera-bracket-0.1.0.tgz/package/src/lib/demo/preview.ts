import { catalog, type CatalogEntry } from '../catalog';

export function entryOrdinal(entry: CatalogEntry): number {
  return catalog.filter((candidate) => candidate.group === entry.group).findIndex((candidate) => candidate.id === entry.id);
}

export function shortName(name: string): string {
  return name.split(' / ')[0].split(' & ')[0];
}

export function initials(name: string): string {
  return name
    .replace(/[^a-zA-Z0-9 ]/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0])
    .join('')
    .toUpperCase();
}

export function seededValues(seed: string, count: number, minimum = 12, maximum = 88): number[] {
  let state = [...seed].reduce((value, character) => (value * 31 + character.charCodeAt(0)) >>> 0, 2166136261);
  return Array.from({ length: count }, () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return minimum + (state % (maximum - minimum + 1));
  });
}
