<script lang="ts">
  import type { CatalogEntry } from '../catalog';
  import CatalogPreview from './CatalogPreview.svelte';

  interface Props {
    entry: CatalogEntry;
    index: number;
  }

  let { entry, index }: Props = $props();
  let expanded = $state(false);
  const capabilityId = $derived(`${entry.id}-capabilities`);
  const previewLabel = $derived(entry.exports.length ? 'PARTIAL IMPLEMENTATION' : 'REFERENCE PREVIEW');
  const statusLabel = $derived(entry.status.replaceAll('-', ' ').toUpperCase());
</script>

<article class="catalog-card" id={entry.id} data-component-id={entry.id} data-expanded={expanded} data-status={entry.status}>
  <header>
    <span class="index">{String(index + 1).padStart(3, '0')}</span>
    <div>
      <h3>{entry.name}</h3>
      <p>{entry.summary}</p>
    </div>
    <button
      aria-label={`${expanded ? 'Hide' : 'Show'} ${entry.name} capabilities`}
      aria-controls={capabilityId}
      aria-expanded={expanded}
      onclick={() => expanded = !expanded}
    >{expanded ? '−' : '+'}</button>
  </header>

  <CatalogPreview {entry} />

  <footer>
    <div class="tags">
      <span class="demo-tag">{previewLabel}</span>
      <span>{statusLabel}</span>
      <span>CORE REQ · {entry.core.length}</span>
      <span class="advanced">ADV REQ · {entry.advanced.length}</span>
    </div>
    {#if expanded}
      <div class="capabilities" id={capabilityId}>
        <section>
          <b>CORE REQUIREMENTS</b>
          {#each entry.core as feature (feature)}<span>○ {feature}</span>{/each}
          {#if !entry.core.length}<span>— no Core requirements in the reference</span>{/if}
        </section>
        <section>
          <b>ADVANCED REQUIREMENTS</b>
          {#each entry.advanced as feature (feature)}<span>○ {feature}</span>{/each}
          {#if !entry.advanced.length}<span>— no Advanced requirements in the reference</span>{/if}
        </section>
      </div>
    {/if}
  </footer>
</article>

<style>
  .catalog-card {
    display: grid;
    grid-template-rows: auto auto 1fr;
    min-width: 0;
    border: 1px solid var(--br-line);
    background: var(--br-panel);
  }

  header {
    display: grid;
    grid-template-columns: auto 1fr auto;
    gap: 8px;
    align-items: start;
    padding: 8px 9px;
  }

  .index {
    padding-top: 2px;
    color: var(--br-structure);
    font-family: var(--br-font-display);
    font-size: 10px;
  }

  h3 {
    margin: 0;
    color: var(--br-ink);
    font-size: 10.5px;
    letter-spacing: .08em;
    text-transform: uppercase;
  }

  p {
    margin: 2px 0 0;
    color: var(--br-mute);
    font-size: 9.5px;
    line-height: 1.4;
  }

  header button {
    width: 28px;
    height: 28px;
    border: 1px solid var(--br-line);
    background: none;
    color: var(--br-signal);
    cursor: pointer;
  }

  header button:focus-visible {
    outline: 1px solid var(--br-signal);
    outline-offset: 2px;
  }

  .catalog-card:hover {
    border-color: var(--br-lineHot);
  }

  :global(.preview) {
    margin: 0 8px;
  }

  footer {
    align-self: end;
    padding: 7px 8px;
  }

  .tags {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
  }

  .tags span {
    padding: 1px 5px;
    border: 1px solid color-mix(in srgb, var(--br-go) 40%, var(--br-line));
    color: var(--br-go);
    font-size: 10px;
    letter-spacing: .08em;
  }

  .tags .demo-tag {
    border-color: color-mix(in srgb, var(--br-signal) 45%, var(--br-line));
    color: var(--br-signal);
  }

  .tags .advanced {
    border-color: color-mix(in srgb, var(--br-alternate) 40%, var(--br-line));
    color: var(--br-alternate);
  }

  .capabilities {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin-top: 7px;
    padding-top: 7px;
    border-top: 1px dotted var(--br-line);
  }

  .capabilities section {
    display: grid;
    align-content: start;
    gap: 2px;
  }

  .capabilities b {
    margin-bottom: 2px;
    color: var(--br-dim);
    font-size: 10px;
    letter-spacing: .14em;
  }

  .capabilities span {
    color: var(--br-mute);
    font-size: 10px;
    line-height: 1.4;
  }

  .capabilities section:last-child span {
    color: var(--br-alternate);
  }

  @media (max-width: 520px) {
    .capabilities { grid-template-columns: 1fr; }
  }
</style>
