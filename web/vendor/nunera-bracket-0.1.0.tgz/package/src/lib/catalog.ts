import catalogJson from './registry/catalog.json';
import type {
  CatalogDocument,
  CatalogModule,
  CatalogRequirement,
  ModuleKind,
  ModuleStatus,
  RegistryGroup
} from './registry/schema';

export type PreviewKind =
  | 'layout'
  | 'text'
  | 'action'
  | 'input'
  | 'selection'
  | 'date'
  | 'editor'
  | 'display'
  | 'data'
  | 'feedback'
  | 'overlay'
  | 'menu'
  | 'navigation'
  | 'media'
  | 'chart'
  | 'planning'
  | 'social'
  | 'ai'
  | 'commerce'
  | 'motion'
  | 'utility'
  | 'block';

export interface CatalogGroup extends RegistryGroup {}

export interface CatalogEntry {
  id: string;
  name: string;
  group: string;
  preview: PreviewKind;
  summary: string;
  kind: ModuleKind;
  exports: string[];
  status: ModuleStatus;
  core: string[];
  advanced: string[];
  requirements: CatalogRequirement[];
  tags: string[];
}

const registry = catalogJson as CatalogDocument;

function hasEvidence(requirement: CatalogRequirement): boolean {
  return requirement.verified;
}

function statusFor(module: CatalogModule): ModuleStatus {
  const core = module.requirements.filter((requirement) => requirement.tier === 'core');
  const advanced = module.requirements.filter((requirement) => requirement.tier === 'advanced');
  const coreComplete = module.exports.length > 0 && core.every(hasEvidence);
  const advancedComplete = coreComplete && advanced.every(hasEvidence);

  if (advancedComplete) return 'advanced-complete';
  if (coreComplete) return 'core-complete';
  if (module.exports.length > 0 || module.requirements.some(hasEvidence)) return 'partial';
  return 'reference-only';
}

export const catalogGroups: CatalogGroup[] = registry.groups;

export const catalog: CatalogEntry[] = registry.modules.map((module) => {
  const core = module.requirements
    .filter((requirement) => requirement.tier === 'core')
    .map((requirement) => requirement.text);
  const advanced = module.requirements
    .filter((requirement) => requirement.tier === 'advanced')
    .map((requirement) => requirement.text);

  const status = statusFor(module);
  return {
    ...module,
    preview: module.preview as PreviewKind,
    status,
    core,
    advanced,
    tags: [module.preview, module.group, module.kind, status, ...module.id.split('-')].filter(Boolean)
  };
});

const coreRequirements = catalog.flatMap((entry) => entry.requirements.filter((requirement) => requirement.tier === 'core'));
const advancedRequirements = catalog.flatMap((entry) => entry.requirements.filter((requirement) => requirement.tier === 'advanced'));

export const catalogStats = {
  modules: catalog.length,
  groups: catalogGroups.length,
  exportedModules: catalog.filter((entry) => entry.exports.length > 0).length,
  referenceOnlyModules: catalog.filter((entry) => entry.status === 'reference-only').length,
  coreRequirements: coreRequirements.length,
  coreRequirementsVerified: coreRequirements.filter(hasEvidence).length,
  advancedRequirements: advancedRequirements.length,
  advancedRequirementsVerified: advancedRequirements.filter(hasEvidence).length,
  coreCompleteModules: catalog.filter((entry) => entry.status === 'core-complete' || entry.status === 'advanced-complete').length,
  advancedCompleteModules: catalog.filter((entry) => entry.status === 'advanced-complete').length
};

export type {
  CatalogDocument,
  CatalogModule,
  CatalogRequirement,
  EvidenceKind,
  EvidenceRef,
  ModuleKind,
  ModuleStatus,
  RegistryDocument,
  RegistryModule,
  RequirementSpec,
  RequirementTier
} from './registry/schema';
