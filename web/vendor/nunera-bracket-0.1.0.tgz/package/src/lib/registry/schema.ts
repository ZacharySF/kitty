export type RequirementTier = 'core' | 'advanced';
export type ModuleKind = 'component' | 'behavior' | 'utility' | 'recipe';
export type EvidenceKind =
  | 'export'
  | 'unit-test'
  | 'browser-test'
  | 'a11y-test'
  | 'visual-test'
  | 'ssr-test'
  | 'demo'
  | 'docs';

export type ModuleStatus = 'reference-only' | 'partial' | 'core-complete' | 'advanced-complete';

export interface EvidenceRef {
  kind: EvidenceKind;
  path: string;
  assertion?: string;
}

export interface RequirementSpec {
  id: string;
  tier: RequirementTier;
  text: string;
  evidence: EvidenceRef[];
}

export interface RegistryGroup {
  id: string;
  number: string;
  title: string;
  description: string;
}

export interface RegistryModule {
  id: string;
  name: string;
  group: string;
  preview: string;
  summary: string;
  kind: ModuleKind;
  exports: string[];
  requirements: RequirementSpec[];
}

export interface RegistryDocument {
  groups: RegistryGroup[];
  modules: RegistryModule[];
}

/** Client-facing projection of the registry: evidence paths stay out of the browser bundle. */
export interface CatalogRequirement {
  id: string;
  tier: RequirementTier;
  text: string;
  verified: boolean;
}

export interface CatalogModule extends Omit<RegistryModule, 'requirements'> {
  requirements: CatalogRequirement[];
}

export interface CatalogDocument {
  groups: RegistryGroup[];
  modules: CatalogModule[];
}
