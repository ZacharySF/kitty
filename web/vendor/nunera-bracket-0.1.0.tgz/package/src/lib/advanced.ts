export type AdvancedCapability =
  | 'accessibility'
  | 'async'
  | 'collaboration'
  | 'collection'
  | 'commerce'
  | 'content'
  | 'data'
  | 'developer'
  | 'export'
  | 'internationalization'
  | 'interaction'
  | 'layout'
  | 'media'
  | 'motion'
  | 'navigation'
  | 'performance'
  | 'platform'
  | 'security'
  | 'state'
  | 'visual'
  | 'unknown';

export interface StorageAdapter {
  getItem(key: string): string | null;
  setItem(key: string, value: string): unknown;
  removeItem(key: string): unknown;
}

export interface PresencePeer {
  id: string;
  name: string;
  color?: string;
  cursor?: { x: number; y: number };
}

export interface AdvancedPlatform {
  share?: (data: ShareData) => Promise<void>;
  writeText?: (value: string) => Promise<void>;
  vibrate?: (pattern: number | number[]) => boolean;
  startViewTransition?: (callback: () => void) => { finished: Promise<unknown> };
}

export interface AdvancedControllerOptions {
  storage?: StorageAdapter;
  storageKey?: string;
  locale?: string;
  historyLimit?: number;
  announce?: (message: string, priority: 'polite' | 'assertive') => void;
  platform?: AdvancedPlatform;
}

export interface VirtualWindow {
  start: number;
  end: number;
  before: number;
  after: number;
}

export type ExportFormat = 'csv' | 'json' | 'svg';
export type PlatformOperation = 'share' | 'clipboard' | 'haptic' | 'view-transition';

const capabilityRules: Array<[AdvancedCapability, RegExp]> = [
  ['accessibility', /accessib|aria|screen reader|keyboard|focus|contrast|touch target|live.region|inert/i],
  ['internationalization', /locale|CLDR|calendar|time.zone|bidi|RTL|plural|collat|IME|language|numbering/i],
  ['performance', /virtual|worker|million|WebGL|canvas|bundle|hydration|lazy|performance|offscreen|layout shift/i],
  ['motion', /animat|spring|transition|gesture|drag|swipe|pinch|parallax|morph|stagger|velocity|momentum|reduced.motion/i],
  ['media', /video|audio|caption|DRM|HLS|DASH|casting|AirPlay|picture.in.picture|camera|waveform|glTF|GLB|PDF|image|crop/i],
  ['collaboration', /collabor|presence|cursor|comment|reaction|activity|real.time|live update|co.edit|share/i],
  ['commerce', /payment|checkout|cart|price|currency|tax|shipping|coupon|inventory|product|review|subscription/i],
  ['security', /security|permission|auth|sanitize|XSS|CSP|tamper|encrypted|privacy|credential/i],
  ['developer', /Storybook|playground|test|Figma|Code Connect|codemod|LLM|MCP|DevTools|semantic version|license|telemetry|typed|TypeScript|API/i],
  ['export', /export|download|clipboard|copy|CSV|PNG|SVG|print|import|serialize/i],
  ['platform', /native|Popover API|dialog|anchor positioning|container quer|subgrid|view transition|vibrat|pointer pressure|server action|validation API|select/i],
  ['layout', /layout|responsive|resize|width|height|column|row|grid|masonry|sidebar|panel|density|safe.area|sticky|scroll|position|breakpoint|aspect|overlay/i],
  ['navigation', /route|navigation|deep link|breadcrumb|pagination|step|history|URL|back|forward/i],
  ['async', /async|debounce|cancel|loading|pending|stream|retry|error|autosave|server|fetch|prefetch|optimistic|cooldown/i],
  ['collection', /sort|filter|search|group|tree|list|table|grid|selection|reorder|infinite|page|range|item|node|row|column/i],
  ['content', /Markdown|MDX|math|KaTeX|Mermaid|syntax|Shiki|code|text|heading|link|prose|editor|mention|emoji|format|document|JSON|HTML/i],
  ['visual', /color|theme|token|gradient|shadow|border|icon|tooltip|preview|chart|axis|legend|label|annotation|marker|glow|style|illustration/i],
  ['interaction', /press|hover|click|hold|toggle|open|close|dismiss|menu|shortcut|hotkey|pointer|mouse|touch|pen|editable|imperative/i],
  ['state', /state|persist|undo|redo|controlled|uncontrolled|remember|restore|dirty|touched|progress|status|disabled|read|unread/i],
  ['data', /schema|data|value|formula|aggregate|pivot|query|cache|offline|sync|format|unit|date|time/i]
];

export function classifyAdvancedRequirement(text: string): AdvancedCapability {
  for (const [capability, rule] of capabilityRules) if (rule.test(text)) return capability;
  // Remaining domain-specific features use the same executable interaction extension seam.
  return 'interaction';
}

function clone<T>(value: T): T {
  if (typeof structuredClone === 'function') return structuredClone(value);
  if (Array.isArray(value)) return [...value] as unknown as T;
  if (value && typeof value === 'object') return { ...value } as T;
  return value;
}

function csvCell(value: unknown): string {
  const text = value == null ? '' : String(value);
  return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

export function createAdvancedController<T>(moduleId: string, initialState: T, options: AdvancedControllerOptions = {}) {
  let state = clone(initialState);
  const past: T[] = [];
  const future: T[] = [];
  const subscribers = new Set<(state: T) => void>();
  const peers = new Map<string, PresencePeer>();
  const requests = new Map<string, AbortController>();
  const announcements = new Set<string>();
  const collator = new Intl.Collator(options.locale, { sensitivity: 'base', usage: 'search' });
  const storageKey = options.storageKey ?? `bracket:${moduleId}`;
  const historyLimit = Math.max(1, options.historyLimit ?? 100);

  function notify() {
    for (const subscriber of subscribers) subscriber(clone(state));
  }
  function set(next: T) {
    past.push(clone(state));
    if (past.length > historyLimit) past.shift();
    future.length = 0;
    state = clone(next);
    notify();
    return current();
  }
  function current() { return clone(state); }
  function undo() {
    const previous = past.pop();
    if (previous === undefined) return current();
    future.push(clone(state));
    state = previous;
    notify();
    return current();
  }
  function redo() {
    const next = future.pop();
    if (next === undefined) return current();
    past.push(clone(state));
    state = next;
    notify();
    return current();
  }
  function persist() {
    if (!options.storage) return false;
    options.storage.setItem(storageKey, JSON.stringify(state));
    return true;
  }
  function restore() {
    const stored = options.storage?.getItem(storageKey);
    if (stored === null || stored === undefined) return current();
    state = JSON.parse(stored) as T;
    notify();
    return current();
  }
  async function optimistic(next: T, commit: () => Promise<unknown>) {
    const before = current();
    set(next);
    try {
      await commit();
      return current();
    } catch (error) {
      state = before;
      notify();
      throw error;
    }
  }
  async function runLatest<R>(key: string, task: (signal: AbortSignal) => Promise<R>): Promise<R> {
    requests.get(key)?.abort(new DOMException('Superseded', 'AbortError'));
    const controller = new AbortController();
    requests.set(key, controller);
    try {
      return await task(controller.signal);
    } finally {
      if (requests.get(key) === controller) requests.delete(key);
    }
  }
  function subscribe(listener: (state: T) => void) {
    subscribers.add(listener);
    return () => subscribers.delete(listener);
  }
  function publish(update: (state: T) => T) { return set(update(current())); }
  function join(peer: PresencePeer) { peers.set(peer.id, clone(peer)); notify(); }
  function leave(id: string) { peers.delete(id); notify(); }
  function peerList() { return [...peers.values()].map(clone); }
  function reorder<I>(items: readonly I[], from: number, to: number): I[] {
    if (from < 0 || from >= items.length || to < 0 || to >= items.length) return [...items];
    const result = [...items];
    const [item] = result.splice(from, 1);
    result.splice(to, 0, item);
    return result;
  }
  function virtualWindow(count: number, offset: number, itemSize: number, overscan = 3): VirtualWindow {
    const anchor = Math.max(0, Math.min(count - 1, Math.floor(offset / itemSize)));
    const start = Math.max(0, anchor - overscan);
    const end = Math.min(count - 1, anchor + overscan + 1);
    return { start, end, before: start * itemSize, after: Math.max(0, count - end - 1) * itemSize };
  }
  function search<I>(items: readonly I[], query: string, text: (item: I) => string): I[] {
    const normalizedQuery = query.normalize('NFD').replace(/\p{Diacritic}/gu, '');
    return items.filter((item) => {
      const candidate = text(item).normalize('NFD').replace(/\p{Diacritic}/gu, '');
      return candidate.length >= normalizedQuery.length && [...candidate].some((_, index) => collator.compare(candidate.slice(index, index + normalizedQuery.length), normalizedQuery) === 0);
    });
  }
  function exportData(data: unknown, format: ExportFormat): string {
    if (format === 'json') return JSON.stringify(data, null, 2);
    if (format === 'svg') return `<svg xmlns="http://www.w3.org/2000/svg">${String(data)}</svg>`;
    if (!Array.isArray(data) || data.length === 0) return '';
    const rows = data.filter((row): row is Record<string, unknown> => Boolean(row) && typeof row === 'object' && !Array.isArray(row));
    const keys = [...new Set(rows.flatMap((row) => Object.keys(row)))];
    return [keys.join(','), ...rows.map((row) => keys.map((key) => csvCell(row[key])).join(','))].join('\n');
  }
  function announce(message: string, priority: 'polite' | 'assertive' = 'polite') {
    const key = `${priority}:${message}`;
    if (announcements.has(key)) return false;
    announcements.add(key);
    options.announce?.(message, priority);
    queueMicrotask(() => announcements.delete(key));
    return true;
  }
  async function platform(operation: PlatformOperation, payload: unknown) {
    const adapter = options.platform;
    if (operation === 'share') {
      if (!adapter?.share) throw new Error('Share API unavailable');
      await adapter.share(payload as ShareData);
    } else if (operation === 'clipboard') {
      if (!adapter?.writeText) throw new Error('Clipboard API unavailable');
      await adapter.writeText(String(payload));
    } else if (operation === 'haptic') {
      if (!adapter?.vibrate) throw new Error('Vibration API unavailable');
      adapter.vibrate(payload as number | number[]);
    } else {
      if (!adapter?.startViewTransition || typeof payload !== 'function') throw new Error('View Transition API unavailable');
      await adapter.startViewTransition(payload as () => void).finished;
    }
  }
  function destroy() {
    for (const request of requests.values()) request.abort(new DOMException('Destroyed', 'AbortError'));
    requests.clear(); subscribers.clear(); peers.clear();
  }

  return { moduleId, current, set, undo, redo, persist, restore, optimistic, runLatest, subscribe, publish, join, leave, peers: peerList, reorder, virtualWindow, search, exportData, announce, platform, destroy };
}

export type AdvancedController<T> = ReturnType<typeof createAdvancedController<T>>;
