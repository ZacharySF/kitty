import type { Density } from './types';

export const ROLES = [
  'void', 'panel', 'inset', 'raised', 'line', 'lineHot', 'ink', 'mute', 'dim',
  'structure', 'signal', 'go', 'reference', 'caution', 'alternate', 'danger'
] as const;
export type Role = (typeof ROLES)[number];
export type Theme = Record<Role, string> & { name: string };

/** The palette shape used by Kudzu before adopting Bracket's semantic role names. */
export type KudzuPalette = Pick<Theme, 'name' | 'void' | 'panel' | 'inset' | 'raised' | 'line' | 'lineHot' | 'ink' | 'mute' | 'dim' | 'danger'> & {
  c1: string;
  c2: string;
  c3: string;
  c4: string;
  c5: string;
  c6: string;
};

export const themes: Theme[] = [
  { name: 'Kudzu', void:'#080B08', panel:'#10150F', inset:'#0A0E09', raised:'#182016', line:'#2A3626', lineHot:'#56704C', ink:'#D2DCC6', mute:'#879779', dim:'#7D8B74', structure:'#A6D66A', signal:'#6FD3C0', go:'#7FE07A', reference:'#79A8E8', caution:'#E3B550', alternate:'#C98BD6', danger:'#E25B4B' },
  { name: 'Sodium Vapor', void:'#0B0806', panel:'#15100B', inset:'#0E0A07', raised:'#1F1811', line:'#3D2E1E', lineHot:'#7A5A36', ink:'#F2DCC0', mute:'#A88A68', dim:'#6C5842', structure:'#FF9A3C', signal:'#F6C177', go:'#9ED36A', reference:'#7FB0D8', caution:'#FFC94D', alternate:'#E07A9A', danger:'#FF4A3D' },
  { name: 'Flight Deck', void:'#070A0F', panel:'#0F131A', inset:'#080B11', raised:'#1A212C', line:'#2C3442', lineHot:'#5A6878', ink:'#C3CDDF', mute:'#7C889E', dim:'#4E586B', structure:'#9E8FDC', signal:'#4ED2DA', go:'#8FE08C', reference:'#6FA8F0', caution:'#DFB25E', alternate:'#D67BB8', danger:'#E05A5A' },
  { name: 'Phosphor P1', void:'#040A06', panel:'#0A150D', inset:'#061009', raised:'#102118', line:'#1C4A2C', lineHot:'#2F8A52', ink:'#7CFFA8', mute:'#3FA868', dim:'#246B42', structure:'#B4FFD0', signal:'#50FF8C', go:'#35E070', reference:'#2BC45E', caution:'#9CFFC0', alternate:'#1F9E4A', danger:'#FF6B4A' },
  { name: 'Amber VDT', void:'#0A0600', panel:'#150E03', inset:'#0F0901', raised:'#211705', line:'#4A3410', lineHot:'#8A6418', ink:'#FFB94A', mute:'#B07820', dim:'#704C14', structure:'#FFD98A', signal:'#FFB000', go:'#E09A00', reference:'#C78600', caution:'#FFC95E', alternate:'#A06C00', danger:'#FF5436' },
  { name: 'Blueprint', void:'#0A1E33', panel:'#10283F', inset:'#0C2136', raised:'#16324B', line:'#2E5375', lineHot:'#6E9CC4', ink:'#DCEBF7', mute:'#86AECB', dim:'#4E7A9A', structure:'#FFFFFF', signal:'#7FE3FF', go:'#9EEBC4', reference:'#A8CBFF', caution:'#FFD98A', alternate:'#FFA8D8', danger:'#FF8A8A' },
  { name: 'Drafting', void:'#D6D3CA', panel:'#F3F1EA', inset:'#FBFAF6', raised:'#E9E7DE', line:'#B6B2A5', lineHot:'#6E6A5C', ink:'#1C1A17', mute:'#5C584E', dim:'#8F8A7D', structure:'#C8102E', signal:'#00756B', go:'#2F6B2A', reference:'#1B4F9C', caution:'#A86508', alternate:'#8B2E6B', danger:'#C8102E' },
  { name: 'Oscilloscope', void:'#000000', panel:'#0A0A0C', inset:'#050506', raised:'#141418', line:'#2A2A30', lineHot:'#5A5A64', ink:'#D8D8E0', mute:'#78787F', dim:'#4A4A50', structure:'#FFD400', signal:'#00E5FF', go:'#3FFF5A', reference:'#A07CFF', caution:'#FF9500', alternate:'#FF2FD0', danger:'#FF3B30' },
  { name: 'Hazard', void:'#121210', panel:'#1C1C17', inset:'#0E0E0C', raised:'#26261F', line:'#44422F', lineHot:'#857F4A', ink:'#E8E6DC', mute:'#8E8B7E', dim:'#5C5A50', structure:'#FFD600', signal:'#00C2A8', go:'#7ED321', reference:'#4FA8E0', caution:'#FF8A00', alternate:'#FF4FA0', danger:'#FF2E2E' },
  { name: 'Nixie', void:'#0C0806', panel:'#15100A', inset:'#0E0A06', raised:'#211A11', line:'#46301C', lineHot:'#8A5C32', ink:'#F0C89A', mute:'#A07850', dim:'#6A4F34', structure:'#FF7A2E', signal:'#FFC36B', go:'#E0B478', reference:'#FFA86B', caution:'#FFE0A8', alternate:'#C85A3A', danger:'#FF3D20' },
  { name: 'Soviet', void:'#0B0F0A', panel:'#141A10', inset:'#0D120A', raised:'#1E2618', line:'#38412A', lineHot:'#6E7A4E', ink:'#D4D8B8', mute:'#8A8F68', dim:'#585C40', structure:'#E2C85A', signal:'#8FD8A0', go:'#A8D86A', reference:'#6FB8C8', caution:'#E29A4A', alternate:'#D06A5A', danger:'#D83A2A' },
  { name: 'Deep Void', void:'#06060D', panel:'#0D0D1A', inset:'#08080F', raised:'#161628', line:'#28284A', lineHot:'#55558A', ink:'#C8C8E8', mute:'#7777A0', dim:'#4A4A68', structure:'#B49CFF', signal:'#7FE8FF', go:'#8AFFD0', reference:'#8CA8FF', caution:'#FFD27F', alternate:'#FF9CE8', danger:'#FF6B8A' },
  { name: 'Graphite', void:'#0E0E0E', panel:'#171717', inset:'#0A0A0A', raised:'#202020', line:'#2E2E2E', lineHot:'#606060', ink:'#E4E4E4', mute:'#909090', dim:'#5E5E5E', structure:'#FFFFFF', signal:'#C0C0C0', go:'#00D97E', reference:'#A0A0A0', caution:'#E0E0E0', alternate:'#7A7A7A', danger:'#FF4A4A' },
  { name: 'Signal', void:'#08090B', panel:'#101216', inset:'#0A0C0F', raised:'#181C22', line:'#262C36', lineHot:'#566270', ink:'#DCE3EC', mute:'#7E8A9C', dim:'#505A68', structure:'#FF5C4D', signal:'#2DD4BF', go:'#4ADE80', reference:'#60A5FA', caution:'#FBBF24', alternate:'#E879F9', danger:'#EF4444' }
];

const rgb = (hex: string) => [1, 3, 5].map((i) => Number.parseInt(hex.slice(i, i + 2), 16)) as [number, number, number];
export function luminance(hex: string): number {
  const [r, g, b] = rgb(hex).map((v) => { const x = v / 255; return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrast(a: string, b: string): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((a, b) => b - a);
  return (hi + 0.05) / (lo + 0.05);
}
export const onFill = (hex: string) => contrast(hex, '#000000') > contrast(hex, '#FFFFFF') ? '#000000' : '#FFFFFF';

export function applyTheme(theme: Theme, root?: HTMLElement, density: Density = 'comfortable'): void {
  if (typeof document === 'undefined' && !root) return;
  const target = root ?? document.documentElement;
  for (const role of ROLES) target.style.setProperty(`--br-${role}`, theme[role]);
  target.style.setProperty('--br-structure-wash', `${theme.structure}24`);
  for (const role of ['structure', 'signal', 'go', 'reference', 'caution', 'danger'] as const) target.style.setProperty(`--br-on-${role}`, onFill(theme[role]));
  target.style.colorScheme = luminance(theme.panel) > 0.4 ? 'light' : 'dark';
  target.dataset.brTheme = theme.name;
  target.dataset.brDensity = density;
}

/** Maps Kudzu's c1-c6 palette contract to Bracket's semantic color roles. */
export function fromKudzuPalette(palette: KudzuPalette): Theme {
  const { c1, c2, c3, c4, c5, c6, ...shared } = palette;
  return {
    ...shared,
    structure: c1,
    signal: c2,
    go: c3,
    reference: c4,
    caution: c5,
    alternate: c6
  };
}

/** Maps Bracket roles back to Kudzu's palette contract during an incremental migration. */
export function toKudzuPalette(theme: Theme): KudzuPalette {
  const { structure, signal, go, reference, caution, alternate, ...shared } = theme;
  return {
    ...shared,
    c1: structure,
    c2: signal,
    c3: go,
    c4: reference,
    c5: caution,
    c6: alternate
  };
}

/**
 * Applies a Kudzu palette and aliases its legacy CSS variables to Bracket roles.
 * Existing Kudzu surfaces and new Bracket components can then migrate independently.
 */
export function applyKudzuPalette(palette: KudzuPalette, root?: HTMLElement, density: Density = 'comfortable'): void {
  if (typeof document === 'undefined' && !root) return;
  const target = root ?? document.documentElement;
  applyTheme(fromKudzuPalette(palette), target, density);
  const aliases: Record<Exclude<keyof KudzuPalette, 'name'>, Role> = {
    void: 'void',
    panel: 'panel',
    inset: 'inset',
    raised: 'raised',
    line: 'line',
    lineHot: 'lineHot',
    ink: 'ink',
    mute: 'mute',
    dim: 'dim',
    c1: 'structure',
    c2: 'signal',
    c3: 'go',
    c4: 'reference',
    c5: 'caution',
    c6: 'alternate',
    danger: 'danger'
  };
  for (const [legacy, role] of Object.entries(aliases)) {
    target.style.setProperty(`--${legacy}`, `var(--br-${role})`);
  }
}

export function findTheme(name: string): Theme { return themes.find((theme) => theme.name === name) ?? themes[0]; }
export function themeCss(theme: Theme): string {
  return `:root {\n${ROLES.map((role) => `  --br-${role}: ${theme[role]};`).join('\n')}\n}`;
}
export function validTheme(theme: Theme): boolean {
  return ROLES.every((role) => /^#[0-9a-f]{6}$/i.test(theme[role])) && contrast(theme.ink, theme.panel) >= 7 && contrast(theme.mute, theme.panel) >= 4.5;
}
