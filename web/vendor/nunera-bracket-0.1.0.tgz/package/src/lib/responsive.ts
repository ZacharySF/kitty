export interface ResponsiveValues<T> {
  base: T;
  sm?: T;
  md?: T;
  lg?: T;
  xl?: T;
}

export type ResponsiveValue<T> = T | ResponsiveValues<T>;
export type ResponsiveMapper<T> = (value: T) => string;

export function responsiveVariables<T>(name: string, value: ResponsiveValue<T> | undefined, map: ResponsiveMapper<T> = String): string {
  if (value === undefined) return '';
  if (typeof value !== 'object' || value === null) return `--br-${name}-base:${map(value)}`;
  const values = value as ResponsiveValues<T>;
  let css = `--br-${name}-base:${map(values.base)}`;
  for (const breakpoint of ['sm', 'md', 'lg', 'xl'] as const) {
    const current = values[breakpoint];
    if (current !== undefined) css += `;--br-${name}-${breakpoint}:${map(current)}`;
  }
  return css;
}
