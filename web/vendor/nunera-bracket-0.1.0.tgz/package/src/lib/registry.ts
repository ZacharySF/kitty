import blocksJson from './registry/blocks.json';
import modulesJson from './registry/catalog.json';
import figmaJson from './registry/figma.json';

export interface BlockRecipe {
  id: string;
  name: string;
  export: string;
  variants: ('default' | 'compact' | 'split')[];
  files: string[];
  requirements: { id: string; tier: 'core' | 'advanced'; text: string }[];
}
export interface FigmaMapping {
  id: string;
  family: string;
  figmaName: string;
  exports: string[];
  package: string;
  properties: string[];
}

export const blockRegistry = blocksJson as BlockRecipe[];
export const moduleRegistry = modulesJson;
export const figmaMappings = figmaJson as FigmaMapping[];
export type { CatalogDocument, CatalogModule, CatalogRequirement, RegistryGroup } from './registry/schema';
