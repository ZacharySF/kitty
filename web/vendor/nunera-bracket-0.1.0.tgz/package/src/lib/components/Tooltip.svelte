<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { Snippet } from 'svelte';
  import { createPresence } from '../headless/presence';

  interface Props { content: string; children: Snippet; placement?: 'top'|'bottom'|'left'|'right'; delay?: number; disabled?: boolean }
  let { content, children, placement = 'top', delay = 250, disabled = false }: Props = $props();
  let open = $state(false);
  let wrapper = $state<HTMLElement>();
  let timer: ReturnType<typeof setTimeout>;
  let x = $state(0);
  let y = $state(0);
  const id = $props.id();

  const EXIT_DURATION = 120; // matches --br-motion-fast
  const presence = createPresence(false, { exitDuration: EXIT_DURATION });
  let mounted = $state(presence.mounted);
  let dataState = $state(presence.state);

  $effect(() => presence.subscribe(() => {
    mounted = presence.mounted;
    dataState = presence.state;
  }));
  $effect(() => { presence.set(open); });
  onDestroy(() => presence.destroy());

  function show() {
    if (disabled) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (!wrapper) return;
      const rect = wrapper.getBoundingClientRect();
      x = placement === 'left' ? rect.left - 8 : placement === 'right' ? rect.right + 8 : rect.left + rect.width / 2;
      y = placement === 'top' ? rect.top - 8 : placement === 'bottom' ? rect.bottom + 8 : rect.top + rect.height / 2;
      open = true;
    }, delay);
  }
  function hide() { clearTimeout(timer); open = false; }
</script>

<span class="trigger" role="presentation" bind:this={wrapper} aria-describedby={mounted ? id : undefined} onmouseenter={show} onmouseleave={hide} onfocusin={show} onfocusout={hide}>{@render children()}</span>
{#if mounted}
  <span id={id} role="tooltip" class="br-tooltip" data-state={dataState} data-placement={placement} style:left={`${x}px`} style:top={`${y}px`}><span class="arrow" aria-hidden="true"></span>{content}</span>
{/if}

<style>
  .trigger { display: inline-flex; }
  .br-tooltip[data-placement='top'] { transform: translate(-50%, -100%); }
  .br-tooltip[data-placement='bottom'] { transform: translate(-50%, 0); }
  .br-tooltip[data-placement='left'] { transform: translate(-100%, -50%); }
  .br-tooltip[data-placement='right'] { transform: translate(0, -50%); }
  .arrow { display: inline-block; width: 6px; height: 6px; margin-inline-end: 4px; border: 1px solid currentColor; rotate: 45deg; }
  .br-tooltip[data-state='entered'] { animation: br-tooltip-in var(--br-motion-fast) var(--br-ease-entrance); }
  .br-tooltip[data-state='exiting'] { animation: br-tooltip-in var(--br-motion-fast) var(--br-ease-exit) reverse; }
  @keyframes br-tooltip-in {
    from { opacity: 0; }
    to { opacity: 1; }
  }
</style>
