<script lang="ts">
  import AISurface, { type AISurfaceProps } from './_AISurface.svelte';
  let props: Omit<AISurfaceProps, 'mode'> = $props();
</script>

<AISurface mode="streaming-response" {...props} />
