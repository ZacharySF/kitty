<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  interface Props extends HTMLAttributes<HTMLElement> { as?: string; children: Snippet; edge?: 'block-start' | 'block-end' | 'inline-start' | 'inline-end'; offset?: string; zIndex?: number; ref?: HTMLElement | null }
  let { as = 'div', children, edge = 'block-start', offset = '0', zIndex = 20, ref = $bindable(null), style = '', ...rest }: Props = $props();
  const layoutStyle = $derived(`position:sticky;inset-${edge}:${offset};z-index:${zIndex};${style}`);
</script>

<svelte:element this={as} {...rest} bind:this={ref} style={layoutStyle}>{@render children()}</svelte:element>
