<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  interface Props extends HTMLAttributes<HTMLDivElement> { children: Snippet; ratio?: '16/9' | '4/3' | '1/1' | number; ref?: HTMLDivElement | null }
  let { children, ratio = '16/9', ref = $bindable(null), style = '', ...rest }: Props = $props();
  const ratioValue = $derived(typeof ratio === 'number' ? String(ratio) : ratio);
</script>

<div {...rest} bind:this={ref} class="aspect-ratio" style={`aspect-ratio:${ratioValue};${style}`}>{@render children()}</div>

<style>.aspect-ratio { position: relative; overflow: hidden; } .aspect-ratio :global(> *) { width: 100%; height: 100%; object-fit: cover; }</style>
