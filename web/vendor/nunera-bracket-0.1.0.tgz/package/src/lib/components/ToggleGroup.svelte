<script lang="ts">
  import type { Size } from '../types';
  export interface ToggleGroupItem { id: string; label: string; disabled?: boolean; icon?: string }
  interface Props { items: ToggleGroupItem[]; multiple?: boolean; value?: string | string[]; size?: Size; disabled?: boolean; label?: string; onchange?: (value: string | string[]) => void }
  let { items, multiple = false, value = $bindable(''), size = 'md', disabled = false, label = 'Toggle group', onchange }: Props = $props();
  let root: HTMLDivElement;
  const selected = (id: string) => Array.isArray(value) ? value.includes(id) : value === id;
  const firstEnabled = $derived(items.findIndex((item) => !item.disabled));
  function choose(item: ToggleGroupItem) {
    if (disabled || item.disabled) return;
    if (multiple) value = selected(item.id) ? (value as string[]).filter((id) => id !== item.id) : [...(Array.isArray(value) ? value : []), item.id];
    else value = selected(item.id) ? '' : item.id;
    onchange?.(value);
  }
  function keydown(event: KeyboardEvent) {
    if (!['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
    const buttons = [...root.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')];
    if (!buttons.length) return;
    event.preventDefault();
    const current = buttons.indexOf(document.activeElement as HTMLButtonElement);
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (current + (['ArrowRight', 'ArrowDown'].includes(event.key) ? 1 : -1) + buttons.length) % buttons.length;
    buttons[next].focus();
  }
  function roving(node: HTMLDivElement) {
    root = node;
    node.addEventListener('keydown', keydown);
    return { destroy: () => node.removeEventListener('keydown', keydown) };
  }
</script>
<div class="toggle-group" use:roving role="group" aria-label={label}>{#each items as item, index (item.id)}<button type="button" class="br-btn" data-size={size} aria-pressed={selected(item.id)} disabled={disabled || item.disabled} tabindex={!disabled && index === firstEnabled ? 0 : -1} onclick={() => choose(item)}>{#if item.icon}<span aria-hidden="true">{item.icon}</span>{/if}{item.label}</button>{/each}</div>
<style>.toggle-group { display: inline-flex; } .toggle-group .br-btn + .br-btn { margin-inline-start: -1px; } .br-btn[aria-pressed='true'] { border-color: var(--br-signal); background: var(--br-structure-wash); color: var(--br-signal); }</style>
