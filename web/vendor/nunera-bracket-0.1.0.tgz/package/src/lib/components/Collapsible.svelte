<script lang="ts">
  import type { Snippet } from 'svelte';
  interface Props { label:string; children:Snippet; open?:boolean; disabled?:boolean; onchange?:(open:boolean)=>void }
  let { label,children,open=$bindable(false),disabled=false,onchange }:Props=$props();const contentId=$props.id();function toggle(){if(disabled)return;open=!open;onchange?.(open);}
</script>
<div class="collapsible" data-state={open?'open':'closed'}><button type="button" aria-expanded={open} aria-controls={contentId} {disabled} onclick={toggle}><span>{label}</span><span aria-hidden="true" class="chevron">›</span></button>{#if open}<div id={contentId} class="content">{@render children()}</div>{/if}</div>
<style>button{display:flex;align-items:center;justify-content:space-between;width:100%;padding:var(--br-space-2);border:1px solid var(--br-line);background:var(--br-raised);color:var(--br-ink);text-align:start}.chevron{transition:transform var(--br-motion-fast)}button[aria-expanded='true'] .chevron{transform:rotate(90deg)}.content{padding:var(--br-space-3);border:1px solid var(--br-line);border-top:0}</style>
