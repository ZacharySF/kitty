<script lang="ts">
  import type { Snippet } from 'svelte';
  import { getMessages } from '../headless/messages';

  interface Props {
    for: string;
    children: Snippet;
    required?: boolean;
    optional?: boolean;
    class?: string;
  }

  let { for: htmlFor, children, required = false, optional = false, class: className = '' }: Props = $props();
  const messages = $derived(getMessages());
</script>

<label class={['br-label', className]} for={htmlFor}>
  {@render children()}
  {#if required}<span class="required" aria-hidden="true">*</span>{/if}
  {#if optional}<small>{messages.optional}</small>{/if}
</label>

<style>
  .br-label { display: inline-flex; align-items: baseline; gap: var(--br-space-1); color: var(--br-ink); font-weight: 600; }
  .required { color: var(--br-danger); }
  small { color: var(--br-mute); font-weight: 400; }
</style>
