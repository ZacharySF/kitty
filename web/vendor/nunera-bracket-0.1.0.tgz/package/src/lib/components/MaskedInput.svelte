<script lang="ts">
  import type { HTMLInputAttributes } from 'svelte/elements';

  type MaskPreset = 'phone' | 'date' | 'card' | 'postal';
  interface Props extends Omit<HTMLInputAttributes, 'value' | 'oninput' | 'onchange'> {
    value?: string;
    mask: MaskPreset | string;
    onchange?: (value: string) => void;
  }

  const presets: Record<MaskPreset, string> = {
    phone: '(###) ###-####',
    date: '##/##/####',
    card: '#### #### #### ####',
    postal: '#####'
  };

  let { value = $bindable(''), mask, onchange, ...rest }: Props = $props();
  const pattern = $derived(mask in presets ? presets[mask as MaskPreset] : mask);
  const display = $derived(format(value, pattern));

  function format(raw: string, template: string) {
    const characters = raw.replace(/[^a-z0-9]/gi, '').split('');
    let output = '';
    let cursor = 0;
    for (const token of template) {
      if (cursor >= characters.length) break;
      if (!['#', 'A', '*'].includes(token)) {
        output += token;
        continue;
      }
      while (cursor < characters.length) {
        const character = characters[cursor++];
        if (token === '#' && /\d/.test(character)) { output += character; break; }
        if (token === 'A' && /[a-z]/i.test(character)) { output += character.toUpperCase(); break; }
        if (token === '*') { output += character; break; }
      }
    }
    return output;
  }

  function input(event: Event & { currentTarget: EventTarget & HTMLInputElement }) {
    value = format(event.currentTarget.value, pattern);
    event.currentTarget.value = value;
    onchange?.(value);
  }
</script>

<div class="br-control" data-mask={mask}>
  <input {...rest} value={display} inputmode={mask === 'phone' || mask === 'date' || mask === 'card' || mask === 'postal' ? 'numeric' : undefined} oninput={input} />
</div>
