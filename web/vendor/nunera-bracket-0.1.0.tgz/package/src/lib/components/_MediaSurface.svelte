<script lang="ts">
  export type MediaMode = 'video-player' | 'audio-player' | 'waveform-audio-visualizer' | 'carousel' | 'gallery' | 'image-hotspots' | 'marquee' | 'embed' | 'map' | 'pdf-document-viewer' | '3d-model-viewer' | 'camera-scanner' | 'animation-player-lottie-rive';
  export interface MediaSurfaceProps {
    mode: MediaMode;
    src?: string;
    title?: string;
    autoplay?: boolean;
    loop?: boolean;
    oncapture?: (image: string) => void;
  }

  let { mode, src = '', title = 'Bracket media', autoplay = false, loop = true, oncapture }: MediaSurfaceProps = $props();
  let playing = $state(false);
  let position = $state(24);
  let volume = $state(80);
  let slide = $state(0);
  let lightbox = $state<number | null>(null);
  let hotspot = $state(false);
  let zoom = $state(100);
  let rotation = $state(18);
  let page = $state(1);
  let captured = $state('');
  const slides = ['Telemetry', 'Navigation', 'Power'];
  const pixels = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="320" height="180"%3E%3Crect width="320" height="180" fill="%23111c27"/%3E%3Cpath d="M20 130L90 60l50 45 50-65 110 90" fill="none" stroke="%2338bdf8" stroke-width="8"/%3E%3C/svg%3E';
  const mediaSource = $derived(src || pixels);
  const waveform = Array.from({ length: 28 }, (_, index) => 8 + ((index * 13) % 34));

  $effect(() => {
    if (mode !== 'carousel' || !autoplay) return;
    const timer = window.setInterval(() => slide = loop ? (slide + 1) % slides.length : Math.min(slides.length - 1, slide + 1), 3000);
    return () => window.clearInterval(timer);
  });

  function previous() { slide = slide === 0 ? (loop ? slides.length - 1 : 0) : slide - 1; }
  function next() { slide = slide === slides.length - 1 ? (loop ? 0 : slide) : slide + 1; }
  function capture() {
    captured = pixels;
    oncapture?.(captured);
  }
  function fullscreen(event: MouseEvent) {
    (event.currentTarget as HTMLElement).closest('section')?.requestFullscreen?.();
  }
</script>

<section class="media-surface" data-module={mode} data-autoplay={autoplay} data-loop={loop}>
  {#if mode === 'video-player'}
    <video src={src || undefined} poster={mediaSource} controls preload="metadata"><track kind="captions" srclang="en" label="English" src="data:text/vtt,WEBVTT" default/></video>
    <div class="controls"><button type="button" aria-label={playing ? 'Pause video' : 'Play video'} onclick={() => playing = !playing}>{playing ? 'PAUSE' : 'PLAY'}</button><input aria-label="Seek video" type="range" min="0" max="100" bind:value={position}/><input aria-label="Video volume" type="range" min="0" max="100" bind:value={volume}/><button type="button" aria-label="Fullscreen" onclick={fullscreen}>FULL</button></div>
  {:else if mode === 'audio-player'}
    <audio src={src || undefined} controls preload="metadata"></audio>
    <div class="controls"><button type="button" aria-label={playing ? 'Pause audio' : 'Play audio'} onclick={() => playing = !playing}>{playing ? 'PAUSE' : 'PLAY'}</button><input aria-label="Seek audio" type="range" min="0" max="100" bind:value={position}/><input aria-label="Audio volume" type="range" min="0" max="100" bind:value={volume}/><time datetime="PT24S">00:24 / 03:00</time></div>
  {:else if mode === 'waveform-audio-visualizer'}
    <span class="sr-only">Audio waveform</span><svg viewBox="0 0 280 60" role="img" aria-label="Audio waveform">{#each waveform as height, index (index)}<path d={`M${index * 10 + 3} ${30 - height / 2}v${height}`} />{/each}</svg>
  {:else if mode === 'carousel'}
    <div class="carousel" aria-roledescription="carousel"><button type="button" aria-label="Previous slide" onclick={previous}>‹</button><article class="slide" aria-live="polite"><b>{slides[slide]}</b><span>{slide + 1} / {slides.length}</span></article><button type="button" aria-label="Next slide" onclick={next}>›</button></div>
    <nav aria-label="Choose slide">{#each slides as item, index (item)}<button type="button" aria-label={`Go to slide ${index + 1}`} aria-current={slide === index ? 'true' : undefined} onclick={() => slide = index}>{item}</button>{/each}</nav>
  {:else if mode === 'gallery'}
    <span class="sr-only">Image gallery</span><div class="grid">{#each slides as item, index (item)}<button type="button" aria-label={`Open ${item}`} onclick={() => lightbox = index}><img src={pixels} alt={item}/></button>{/each}</div>
    {#if lightbox !== null}<dialog open aria-label="Image lightbox"><img src={pixels} alt={slides[lightbox]}/><button type="button" aria-label="Close lightbox" onclick={() => lightbox = null}>CLOSE</button></dialog>{/if}
  {:else if mode === 'image-hotspots'}
    <div class="hotspots"><img src={pixels} alt="Relay field"/><button class="pin" type="button" aria-label="Open hotspot Signal" aria-expanded={hotspot} onclick={() => hotspot = !hotspot}>+</button>{#if hotspot}<aside class="popover">Signal: 92%</aside>{/if}</div>
  {:else if mode === 'marquee'}
    <div class="marquee"><div class="track">{#each ['BRACKET', 'KUDZU', 'RELAY', 'MESH'] as item (item)}<span>{item}</span>{/each}{#each ['BRACKET', 'KUDZU', 'RELAY', 'MESH'] as item (item)}<span aria-hidden="true">{item}</span>{/each}</div></div>
  {:else if mode === 'embed'}
    <span class="sr-only">Embedded media</span><div class="embed"><iframe src={src || 'about:blank'} {title} loading="lazy"></iframe></div>
  {:else if mode === 'map'}
    <div class="map"><div class="controls"><button type="button" aria-label="Zoom out" onclick={() => zoom = Math.max(50, zoom - 10)}>−</button><output>{zoom}%</output><button type="button" aria-label="Zoom in" onclick={() => zoom = Math.min(200, zoom + 10)}>+</button></div><svg viewBox="0 0 320 150" role="img" aria-label="Map"><path d="M20 120L70 30l55 40 70-45 100 85"/><circle class="marker" cx="125" cy="70" r="7"><title>Relay marker</title></circle></svg></div>
  {:else if mode === 'pdf-document-viewer'}
    <div class="controls"><button type="button" aria-label="Previous page" disabled={page === 1} onclick={() => page--}>PREV</button><output>Page {page} / 3</output><button type="button" aria-label="Next page" disabled={page === 3} onclick={() => page++}>NEXT</button><button type="button" aria-label="Zoom out" onclick={() => zoom -= 10}>−</button><button type="button" aria-label="Zoom in" onclick={() => zoom += 10}>+</button></div><iframe src={src || 'about:blank'} title="PDF document" style:--zoom={zoom / 100}></iframe>
  {:else if mode === '3d-model-viewer'}
    <div class="model" style:--rotation={`${rotation}deg`} role="img" aria-label={title}><div class="cube"><i></i><i></i><i></i></div></div><div class="controls"><button type="button" aria-label="Rotate model left" onclick={() => rotation -= 15}>LEFT</button><button type="button" aria-label="Rotate model right" onclick={() => rotation += 15}>RIGHT</button></div>
  {:else if mode === 'camera-scanner'}
    <video autoplay muted playsinline aria-label="Camera preview"></video><button type="button" aria-label="Capture photo" onclick={capture}>CAPTURE</button>{#if captured}<img src={captured} alt="Captured frame"/>{/if}
  {:else}
    <div class:playing class="animation" role="img" aria-label={title}><i></i><i></i><i></i></div><button type="button" aria-label={playing ? 'Pause animation' : 'Play animation'} onclick={() => playing = !playing}>{playing ? 'PAUSE' : 'PLAY'}</button>
  {/if}
</section>

<style>
  .media-surface { position: relative; display: grid; gap: 6px; min-height: 110px; padding: 7px; overflow: hidden; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-text); font: 10px/1.4 var(--br-font-mono); }
  button, input { border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; } button { padding: 4px 7px; cursor: pointer; }
  video, audio, img, iframe { max-width: 100%; } video { width: 100%; max-height: 170px; background: #05090d; } audio { width: 100%; }
  .controls, nav { display: flex; gap: 5px; align-items: center; }.controls input { min-width: 50px; flex: 1; }
  svg { width: 100%; height: 120px; background: var(--br-surface); } svg path { fill: none; stroke: var(--br-signal); stroke-width: 4; stroke-linecap: round; }
  .carousel { display: grid; grid-template-columns: auto 1fr auto; align-items: stretch; }.slide { display: grid; place-content: center; min-height: 100px; border-block: 1px solid var(--br-line); text-align: center; }.slide span { color: var(--br-mute); }
  nav { justify-content: center; } nav button[aria-current='true'] { border-color: var(--br-signal); }
  .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 5px; }.grid button { padding: 0; }.grid img { display: block; width: 100%; }
  dialog { position: absolute; inset: 5px; z-index: 2; max-width: calc(100% - 10px); border: 1px solid var(--br-signal); background: var(--br-surface); color: inherit; }
  .hotspots { position: relative; }.hotspots img { display: block; width: 100%; }.pin { position: absolute; left: 38%; top: 34%; border-radius: 50%; }.popover { position: absolute; left: 46%; top: 30%; padding: 5px; border: 1px solid var(--br-line); background: var(--br-raised); }
  .marquee { overflow: hidden; }.track { display: flex; width: max-content; gap: 28px; padding: 25px 0; animation: marquee 12s linear infinite; }.track span { color: var(--br-structure); letter-spacing: .14em; }
  .embed { aspect-ratio: 16 / 9; }.embed iframe, [data-module='pdf-document-viewer'] iframe { width: 100%; height: 100%; min-height: 120px; border: 1px solid var(--br-line); background: white; }
  .map { position: relative; }.map .controls { position: absolute; z-index: 1; top: 4px; right: 4px; }.map path { stroke-width: 2; }.marker { fill: var(--br-danger); stroke: white; stroke-width: 2; }
  .model { display: grid; place-items: center; min-height: 115px; perspective: 300px; }.cube { position: relative; width: 55px; height: 55px; transform: rotateX(-24deg) rotateY(var(--rotation)); transform-style: preserve-3d; transition: transform .2s; }.cube i { position: absolute; inset: 0; border: 1px solid var(--br-signal); background: color-mix(in srgb, var(--br-signal) 20%, transparent); }.cube i:nth-child(2) { transform: rotateY(90deg) translateZ(27px); }.cube i:nth-child(3) { transform: rotateX(90deg) translateZ(27px); }
  .animation { display: flex; justify-content: center; gap: 6px; padding: 30px; }.animation i { width: 12px; height: 40px; background: var(--br-signal); transform: scaleY(.3); }.animation.playing i { animation: pulse .8s ease-in-out infinite alternate; }.animation.playing i:nth-child(2) { animation-delay: .2s; }.animation.playing i:nth-child(3) { animation-delay: .4s; }
  @keyframes marquee { to { transform: translateX(-50%); } } @keyframes pulse { to { transform: scaleY(1); } }
  .sr-only { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
  @media (prefers-reduced-motion: reduce) { .track, .animation.playing i { animation: none; } }
</style>
