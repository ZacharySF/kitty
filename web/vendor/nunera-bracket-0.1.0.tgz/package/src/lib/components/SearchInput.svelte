<script lang="ts">
  import { onDestroy } from 'svelte';
  import TextInput from './TextInput.svelte';
  import { getMessages } from '../headless/messages';

  interface Props {
    value?: string;
    placeholder?: string;
    loading?: boolean;
    shortcut?: string;
    debounce?: number;
    onsubmit?: (value: string) => void;
    onchange?: (value: string) => void;
  }

  let { value = $bindable(''), placeholder, loading = false, shortcut = '/', debounce = 180, onsubmit, onchange }: Props = $props();
  const messages = $derived(getMessages());
  const effectivePlaceholder = $derived(placeholder ?? messages.searchPlaceholder);
  let timer: ReturnType<typeof setTimeout> | undefined;

  function input() {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => onchange?.(value), debounce);
  }

  function keydown(event: KeyboardEvent) {
    if (event.key === 'Enter') onsubmit?.(value);
  }

  onDestroy(() => {
    if (timer) clearTimeout(timer);
  });
</script>

<div class="search">
  <span aria-hidden="true">⌕</span>
  <TextInput bind:value placeholder={effectivePlaceholder} clearable type="search" oninput={input} onkeydown={keydown} />
  {#if loading}<i aria-label={messages.searching}>···</i>{:else if shortcut}<kbd>{shortcut}</kbd>{/if}
</div>

<style>
  .search { position: relative; display: grid; grid-template-columns: auto 1fr auto; align-items: center; }
  .search > span { position: absolute; z-index: 1; inset-inline-start: 8px; color: var(--br-signal); }
  .search :global(input) { padding-inline-start: 26px; }
  .search > i, .search > kbd { position: absolute; z-index: 1; inset-inline-end: 6px; }
  .search > i { color: var(--br-caution); font-style: normal; }
</style>
