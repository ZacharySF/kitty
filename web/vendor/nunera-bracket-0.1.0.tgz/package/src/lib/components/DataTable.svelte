<script lang="ts" generics="T extends Record<string, unknown>">
  import type { Column } from '../types';
  import { getMessages } from '../headless/messages';

  interface Props<T> {
    rows: T[];
    columns: Column<T>[];
    caption?: string;
    keyField: keyof T & string;
    selected?: string[];
    sortable?: boolean;
    striped?: boolean;
    loading?: boolean;
    emptyText?: string;
    filter?: string;
    page?: number;
    pageSize?: number;
    resizable?: boolean;
    onselect?: (row: T) => void;
  }

  let {
    rows,
    columns,
    caption,
    keyField,
    selected = $bindable([]),
    sortable = true,
    striped = false,
    loading = false,
    emptyText,
    filter = '',
    page = 1,
    pageSize = Infinity,
    resizable = true,
    onselect
  }: Props<T> = $props();
  const messages = $derived(getMessages());
  const resolvedEmptyText = $derived(emptyText ?? messages.noRows);
  let sortKey = $state<string>();
  let direction = $state<'asc' | 'desc'>('asc');
  let widths = $state<Record<string, number>>({});
  let table = $state<HTMLTableElement>();

  const filtered = $derived(filter
    ? rows.filter((row) => columns.some((column) => String(row[column.key] ?? '').toLocaleLowerCase().includes(filter.toLocaleLowerCase())))
    : rows);
  const sorted = $derived(sortKey
    ? [...filtered].sort((a, b) => {
      const result = String(a[sortKey!]).localeCompare(String(b[sortKey!]), undefined, { numeric: true });
      return direction === 'asc' ? result : -result;
    })
    : filtered);
  const visible = $derived(sorted.slice((Math.max(1, page) - 1) * pageSize, Math.max(1, page) * pageSize));

  function sort(column: Column<T>) {
    if (!sortable || column.sortable === false) return;
    if (sortKey === column.key) direction = direction === 'asc' ? 'desc' : 'asc';
    else {
      sortKey = column.key;
      direction = 'asc';
    }
  }

  function select(row: T) {
    const key = String(row[keyField]);
    selected = selected.includes(key) ? selected.filter((item) => item !== key) : [...selected, key];
    onselect?.(row);
  }

  function rowKeydown(event: KeyboardEvent, row: T) {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    select(row);
  }

  function cellKeydown(event: KeyboardEvent, rowIndex: number, columnIndex: number) {
    const movement: Record<string, [number, number]> = {
      ArrowLeft: [0, -1], ArrowRight: [0, 1], ArrowUp: [-1, 0], ArrowDown: [1, 0]
    };
    const delta = movement[event.key];
    if (!delta || !table) return;
    event.preventDefault();
    const nextRow = Math.max(0, Math.min(visible.length - 1, rowIndex + delta[0]));
    const nextColumn = Math.max(0, Math.min(columns.length - 1, columnIndex + delta[1]));
    table.querySelector<HTMLElement>(`[data-cell="${nextRow}-${nextColumn}"]`)?.focus();
  }

  function setWidth(column: Column<T>, width: number) {
    widths = { ...widths, [column.key]: Math.max(64, Math.round(width)) };
  }

  function resizeKeydown(event: KeyboardEvent, column: Column<T>) {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
    event.preventDefault();
    const header = (event.currentTarget as HTMLElement).parentElement;
    const current = widths[column.key] ?? header?.getBoundingClientRect().width ?? 120;
    setWidth(column, current + (event.key === 'ArrowRight' ? 8 : -8));
  }

  function startResize(event: PointerEvent, column: Column<T>) {
    event.preventDefault();
    event.stopPropagation();
    const handle = event.currentTarget as HTMLElement;
    const startX = event.clientX;
    const startWidth = widths[column.key] ?? handle.parentElement?.getBoundingClientRect().width ?? 120;
    handle.setPointerCapture?.(event.pointerId);
    const move = (moveEvent: PointerEvent) => setWidth(column, startWidth + moveEvent.clientX - startX);
    const stop = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', stop);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop, { once: true });
  }
</script>

<div class="br-table-wrap" aria-busy={loading}>
  <table bind:this={table} class="br-table" data-striped={striped} role="grid">
    {#if caption}<caption>{caption}</caption>{/if}
    <thead>
      <tr>
        {#each columns as column (column.key)}
          <th style:width={widths[column.key] ? `${widths[column.key]}px` : column.width} data-sorted={sortKey === column.key ? direction : undefined} aria-sort={sortKey === column.key ? (direction === 'asc' ? 'ascending' : 'descending') : 'none'}>
            <button class="sort" type="button" aria-label={sortKey === column.key ? (direction === 'asc' ? messages.sortAscending({ column: column.label }) : messages.sortDescending({ column: column.label })) : undefined} onclick={() => sort(column)} disabled={!sortable || column.sortable === false}>
              {column.label}{#if sortKey === column.key} {direction === 'asc' ? '↑' : '↓'}{/if}
            </button>
            {#if resizable}
              <button class="resize" type="button" aria-label={messages.resizeColumn({ column: column.label })} onkeydown={(event) => resizeKeydown(event, column)} onpointerdown={(event) => startResize(event, column)}></button>
            {/if}
          </th>
        {/each}
      </tr>
    </thead>
    <tbody>
      {#if loading}
        <tr><td colspan={columns.length}>{messages.loading}</td></tr>
      {:else if !visible.length}
        <tr><td colspan={columns.length}>{resolvedEmptyText}</td></tr>
      {:else}
        {#each visible as row, rowIndex (String(row[keyField]))}
          <tr
            aria-selected={selected.includes(String(row[keyField]))}
            tabindex="0"
            onclick={() => select(row)}
            onkeydown={(event) => rowKeydown(event, row)}
          >
            {#each columns as column, columnIndex (column.key)}
              <td
                role="gridcell"
                data-numeric={column.numeric}
                data-cell={`${rowIndex}-${columnIndex}`}
                tabindex={rowIndex === 0 && columnIndex === 0 ? 0 : -1}
                onkeydown={(event) => cellKeydown(event, rowIndex, columnIndex)}
              >{#if column.render}{@render column.render(row)}{:else}{String(row[column.key] ?? '—')}{/if}</td>
            {/each}
          </tr>
        {/each}
      {/if}
    </tbody>
  </table>
</div>

<style>
  .br-table { table-layout: fixed; }
  .br-table th { position: relative; }
  .br-table th .sort { padding-inline-end: 12px; }
  .resize { position: absolute; z-index: 1; inset-block: 0; inset-inline: auto -4px; width: 9px; min-height: 24px; padding: 0; border: 0; border-inline-end: 1px solid transparent; background: transparent; cursor: col-resize; }
  .resize:hover, .resize:focus-visible { border-inline-end-color: var(--br-signal); }
  .br-table[data-striped='true'] tbody tr:nth-child(even) td { background: color-mix(in srgb, var(--br-raised) 55%, transparent); }
  tbody tr:focus-visible, td:focus-visible { outline: 1px solid var(--br-signal); outline-offset: -2px; }
</style>
