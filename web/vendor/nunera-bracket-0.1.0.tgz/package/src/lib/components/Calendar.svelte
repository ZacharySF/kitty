<script lang="ts">
  import { getMessages } from '../headless/messages';
  interface Props { value?: string; month?: Date; min?: string; max?: string; weekStart?: 0 | 1; disabledDates?: string[]; rangeStart?: string; rangeEnd?: string; onchange?: (iso: string) => void }

  let { value = $bindable(''), month = $bindable(new Date()), min, max, weekStart = 0, disabledDates = [], rangeStart, rangeEnd, onchange }: Props = $props();
  const messages = $derived(getMessages());
  let focused = $state('');
  const formatter = new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' });
  const weekdays = $derived(Array.from({ length: 7 }, (_, index) => new Intl.DateTimeFormat(undefined, { weekday: 'short' }).format(new Date(2024, 0, 7 + ((index + weekStart) % 7)))));
  const cells = $derived.by(() => {
    const year = month.getFullYear();
    const monthIndex = month.getMonth();
    const first = (new Date(year, monthIndex, 1).getDay() - weekStart + 7) % 7;
    const days = new Date(year, monthIndex + 1, 0).getDate();
    const all = [...Array(first).fill(null), ...Array.from({ length: days }, (_, index) => new Date(year, monthIndex, index + 1))];
    while (all.length % 7) all.push(null);
    return all as Array<Date | null>;
  });
  const weeks = $derived(Array.from({ length: cells.length / 7 }, (_, index) => cells.slice(index * 7, index * 7 + 7)));

  const today = iso(new Date());
  function iso(date: Date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; }
  function disabled(date: Date) {
    const key = iso(date);
    return Boolean((min && key < min) || (max && key > max) || disabledDates.includes(key));
  }
  function inRange(date: Date) { const key = iso(date); return Boolean(rangeStart && rangeEnd && key >= rangeStart && key <= rangeEnd); }
  function select(date: Date) {
    if (disabled(date)) return;
    value = iso(date);
    focused = value;
    onchange?.(value);
  }
  function move(offset: number) { month = new Date(month.getFullYear(), month.getMonth() + offset, 1); }
  function moveYear(offset: number) { month = new Date(month.getFullYear() + offset, month.getMonth(), 1); }
  function focusDate(date: Date) {
    month = new Date(date.getFullYear(), date.getMonth(), 1);
    focused = iso(date);
    queueMicrotask(() => document.getElementById(`br-calendar-${focused}`)?.focus());
  }
  function keydown(event: KeyboardEvent) {
    const target = event.target as HTMLElement;
    const current = target.dataset.date;
    if (!current) return;
    const date = new Date(`${current}T12:00:00`);
    const offsets: Record<string, number> = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 };
    if (event.key in offsets) {
      event.preventDefault();
      date.setDate(date.getDate() + offsets[event.key]);
      focusDate(date);
    } else if (event.key === 'Home' || event.key === 'End') {
      event.preventDefault();
      const day = (date.getDay() - weekStart + 7) % 7;
      date.setDate(date.getDate() + (event.key === 'Home' ? -day : 6 - day));
      focusDate(date);
    } else if (event.key === 'PageUp' || event.key === 'PageDown') {
      event.preventDefault();
      date.setMonth(date.getMonth() + (event.key === 'PageUp' ? -1 : 1));
      focusDate(date);
    }
  }
</script>

<div class="calendar">
  <header><button aria-label="Previous year" onclick={() => moveYear(-1)}>«</button><button aria-label={messages.previousMonth} onclick={() => move(-1)}>←</button><b>{formatter.format(month)}</b><button aria-label={messages.nextMonth} onclick={() => move(1)}>→</button><button aria-label="Next year" onclick={() => moveYear(1)}>»</button></header>
  <div class="grid" role="grid" aria-label={formatter.format(month)} tabindex="-1" onkeydown={keydown}>
    <div class="row week" role="row">{#each weekdays as day (day)}<span role="columnheader">{day}</span>{/each}</div>
    {#each weeks as week, weekIndex (weekIndex)}
      <div class="row" role="row">
        {#each week as date, index (date ? iso(date) : `empty-${weekIndex}-${index}`)}
          {#if date}
            <button
              id={`br-calendar-${iso(date)}`}
              role="gridcell"
              aria-label={date.toDateString()}
              aria-selected={value === iso(date)}
              data-date={iso(date)}
              class:today={iso(date) === today}
              class:in-range={inRange(date)}
              disabled={disabled(date)}
              tabindex={(focused || value || cells.find((cell) => cell && !disabled(cell)) && iso(cells.find((cell) => cell && !disabled(cell))!)) === iso(date) ? 0 : -1}
              onclick={() => select(date)}
              onfocus={() => focused = iso(date)}
            >{date.getDate()}</button>
          {:else}<span role="gridcell" aria-hidden="true"></span>{/if}
        {/each}
      </div>
    {/each}
  </div>
</div>

<style>
  .calendar { width: min(100%, 310px); border: 1px solid var(--br-line); background: var(--br-panel); }
  header { display: grid; grid-template-columns: 30px 30px 1fr 30px 30px; align-items: center; border-bottom: 1px solid var(--br-line); }
  header button, .grid button { min-width: 30px; height: 30px; border: 0; background: none; color: var(--br-mute); }
  header b { text-align: center; font-size: 10px; letter-spacing: .12em; }
  .grid { padding: 4px; }
  .row { display: grid; grid-template-columns: repeat(7, 1fr); }
  .week span { padding: 3px; color: var(--br-dim); font-size: 10px; text-align: center; text-transform: uppercase; }
  .grid button { position: relative; }
  .grid button:hover { background: var(--br-structure-wash); color: var(--br-ink); }
  .grid button[aria-selected='true'] { background: var(--br-signal); color: var(--br-on-signal); }
  .grid button.in-range:not([aria-selected='true']) { background: var(--br-structure-wash); color: var(--br-ink); }
  .grid button.today::after { content: ''; position: absolute; left: 50%; bottom: 2px; width: 3px; height: 3px; transform: translateX(-50%); background: var(--br-go); }
  .grid button:disabled { opacity: .25; }
</style>
