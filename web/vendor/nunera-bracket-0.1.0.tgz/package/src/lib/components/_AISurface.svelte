<script lang="ts">
  export type AIMode = 'streaming-response' | 'reasoning-thinking-block' | 'tool-call-agent-step' | 'citations-sources' | 'suggestion-chips' | 'message-actions' | 'voice-interface' | 'artifact-canvas-panel';
  export interface AISurfaceProps { mode: AIMode; text?: string; streaming?: boolean; onselect?: (value: string) => void; onaction?: (action: string) => void }
  let { mode, text = 'Relay telemetry is stable.', streaming = true, onselect, onaction }: AISurfaceProps = $props();
  let expanded = $state(true);
  let recording = $state(false);
  let visible = $state(true);
  let vote = $state<'up' | 'down' | null>(null);
</script>

<section class="ai-surface" data-module={mode}>
  {#if mode === 'streaming-response'}
    <div aria-live="polite" aria-busy={streaming}>{text}{#if streaming}<span class="cursor" aria-hidden="true"></span>{/if}</div>
  {:else if mode === 'reasoning-thinking-block'}
    <button type="button" aria-expanded={expanded} onclick={() => expanded = !expanded}>THINKING <span>{expanded ? 'HIDE' : 'SHOW'}</span></button>{#if expanded}<div class="thought"><ol><li>Read source records</li><li>Compare thresholds</li><li>Verify conclusion</li></ol></div>{/if}
  {:else if mode === 'tool-call-agent-step'}
    <header><b class="tool-name">query_telemetry</b><span role="status">COMPLETED</span></header><pre class="input">{JSON.stringify({ relay: 4 }, null, 2)}</pre><pre class="output">{JSON.stringify({ status: 'online' }, null, 2)}</pre>
  {:else if mode === 'citations-sources'}
    <p>{text}<sup><a href="#source-1" aria-label="Source 1">1</a></sup></p><ol class="sources"><li id="source-1"><a href="https://example.com/source">Relay operations manual</a></li></ol>
  {:else if mode === 'suggestion-chips'}
    {#each ['Summarize trace', 'Compare relays', 'Draft report'] as suggestion (suggestion)}<button type="button" onclick={() => onselect?.(suggestion)}>{suggestion}</button>{/each}
  {:else if mode === 'message-actions'}
    <button type="button" aria-label="Copy message" onclick={() => onaction?.('copy')}>COPY</button><button type="button" aria-label="Regenerate" onclick={() => onaction?.('regenerate')}>RETRY</button><button type="button" aria-label="Thumbs up" aria-pressed={vote === 'up'} onclick={() => vote = vote === 'up' ? null : 'up'}>👍</button><button type="button" aria-label="Thumbs down" aria-pressed={vote === 'down'} onclick={() => vote = vote === 'down' ? null : 'down'}>👎</button>
  {:else if mode === 'voice-interface'}
    <button class:recording type="button" aria-label={recording ? 'Stop recording' : 'Start recording'} aria-pressed={recording} onclick={() => recording = !recording}><i></i>{recording ? 'LISTENING' : 'MIC'}</button>
  {:else}
    <button type="button" aria-expanded={visible} onclick={() => visible = !visible}>ARTIFACT {visible ? '×' : 'OPEN'}</button>{#if visible}<aside aria-label="Generated artifact"><header>GENERATED REPORT</header><div class="artifact"><h3>Relay health</h3><p>{text}</p></div></aside>{/if}
  {/if}
</section>
<style>
  .ai-surface { display: flex; flex-wrap: wrap; gap: 6px; min-height: 80px; padding: 8px; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-text); font: 10px/1.45 var(--br-font-mono); }.ai-surface > div, .ai-surface > aside, .ai-surface > header, .ai-surface > p { flex: 1 1 100%; }button { border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; padding: 5px 8px; }.cursor { display: inline-block; width: 6px; height: 1em; margin-left: 2px; vertical-align: middle; background: var(--br-signal); animation: blink .8s steps(1) infinite; }.thought { border-left: 2px solid var(--br-structure); padding-left: 8px; color: var(--br-mute); }header { display: flex; justify-content: space-between; }.tool-name { color: var(--br-signal); }[role='status'] { color: var(--br-success); }pre { flex: 1 1 140px; margin: 0; padding: 7px; border: 1px solid var(--br-line); background: var(--br-surface); }.sources { flex-basis: 100%; }.recording i { display: inline-block; width: 8px; height: 8px; margin-right: 5px; border-radius: 50%; background: var(--br-mute); }.recording.recording { border-color: var(--br-danger); }.recording.recording i { background: var(--br-danger); animation: pulse 1s infinite; }aside { display: grid; grid-template-rows: auto 1fr; border: 1px solid var(--br-line); }.artifact { min-height: 85px; padding: 8px; background: var(--br-surface); }@keyframes blink { 50% { opacity: 0; } }@keyframes pulse { 50% { opacity: .35; } }@media (prefers-reduced-motion: reduce) { .cursor, .recording i { animation: none; } }
</style>
