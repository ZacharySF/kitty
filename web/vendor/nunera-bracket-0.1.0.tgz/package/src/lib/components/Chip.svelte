<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import type { Intent } from '../types';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type ChipPart = 'root' | 'label' | 'remove';

  interface Props extends Omit<HTMLAttributes<HTMLElement>, 'onclick'> {
    as?: string;
    label: string;
    intent?: Intent;
    selected?: boolean;
    removable?: boolean;
    leading?: Snippet;
    onclick?: () => void;
    onremove?: () => void;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<ChipPart>;
    styles?: PartOverrides<ChipPart>;
  }
  let { as = 'span', label, intent = 'neutral', selected = false, removable = false, leading, onclick, onremove, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
</script>

<svelte:element this={as} {...rest} bind:this={ref} class={partClass(['br-chip', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} data-intent={intent} data-selected={selected}>
  {#if onclick}
    <button type="button" class={partClass('br-chip__action', classes, 'label')} style={partStyle(undefined, styles, 'label')} aria-pressed={selected} {onclick}>
      {#if leading}{@render leading()}{/if}{label}
    </button>
  {:else}
    <span class={partClass('br-chip__label', classes, 'label')} style={partStyle(undefined, styles, 'label')}>{#if leading}{@render leading()}{/if}{label}</span>
  {/if}
  {#if removable}
    <button type="button" class={partClass('br-chip__remove', classes, 'remove')} style={partStyle(undefined, styles, 'remove')} aria-label={`Remove ${label}`} onclick={onremove}>×</button>
  {/if}
</svelte:element>

<style>
  .br-chip__action, .br-chip__label { display: inline-flex; align-items: center; gap: 6px; }
  .br-chip__action { min-height: 24px; padding: 0; border: 0; background: none; color: inherit; cursor: pointer; font: inherit; }
  .br-chip__remove { min-width: 24px; min-height: 24px; }
  .br-chip[data-selected='true'] { border-color: var(--br-signal); box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--br-signal) 30%, transparent); }
</style>
