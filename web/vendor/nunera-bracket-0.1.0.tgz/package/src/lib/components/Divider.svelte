<script lang="ts">
  import type { HTMLAttributes } from 'svelte/elements';
  type DividerStyle = 'solid' | 'dashed' | 'dotted';
  interface Props extends Omit<HTMLAttributes<HTMLDivElement>, 'style'> { orientation?: 'horizontal' | 'vertical'; decorative?: boolean; label?: string; thickness?: string; style?: DividerStyle; color?: string; ref?: HTMLDivElement | null }
  let { orientation = 'horizontal', decorative = false, label, thickness = '1px', style: lineStyle = 'solid', color = 'var(--br-line)', ref = $bindable(null), ...rest }: Props = $props();
</script>

<div {...rest} bind:this={ref} class="divider" class:vertical={orientation === 'vertical'} role={decorative ? 'none' : 'separator'} aria-orientation={decorative ? undefined : orientation} aria-label={decorative ? undefined : label} data-line-style={lineStyle} style:--divider-thickness={thickness} style:--divider-style={lineStyle} style:--divider-color={color}>
  {#if label}<span>{label}</span>{/if}
</div>

<style>
  .divider { display: flex; align-items: center; gap: var(--br-space-3); color: var(--br-mute); font-size: var(--br-text-sm); }
  .divider::before, .divider::after { content: ''; flex: 1; border-block-start: var(--divider-thickness) var(--divider-style) var(--divider-color); }
  .divider.vertical { display: inline-flex; min-height: 2rem; flex-direction: column; }
  .divider.vertical::before, .divider.vertical::after { border-block-start: 0; border-inline-start: var(--divider-thickness) var(--divider-style) var(--divider-color); }
</style>
