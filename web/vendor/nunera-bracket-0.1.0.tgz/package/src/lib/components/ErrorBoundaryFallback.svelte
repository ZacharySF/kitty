<script lang="ts">
  import type { Snippet } from 'svelte';
  interface Props { children: Snippet; title?: string; retryLabel?: string; onerror?: (error: unknown) => void; onretry?: () => void }
  let { children, title = 'Something went wrong', retryLabel = 'Retry', onerror, onretry }: Props = $props();
  function message(error: unknown) { return error instanceof Error ? error.message : String(error); }
</script>
<svelte:boundary onerror={(error) => onerror?.(error)}>
  {#snippet failed(error, reset)}
    <div class="fallback" role="alert"><strong>{title}</strong><span>{message(error)}</span><button type="button" class="br-btn" onclick={() => { onretry?.(); reset(); }}>{retryLabel}</button></div>
  {/snippet}
  {@render children()}
</svelte:boundary>
<style>.fallback{display:grid;gap:var(--br-space-2);padding:var(--br-space-4);border:1px solid var(--br-danger);color:var(--br-danger)}.fallback span{color:var(--br-mute)}</style>
