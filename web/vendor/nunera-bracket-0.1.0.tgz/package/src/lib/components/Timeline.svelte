<script lang="ts">
  import type { HTMLAttributes } from 'svelte/elements';
  import type { Intent } from '../types';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type TimelinePart = 'root' | 'item' | 'marker' | 'content';

  interface Event { title: string; time: string; description?: string; intent?: Intent; icon?: string }
  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    events: Event[];
    orientation?: 'vertical' | 'horizontal';
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<TimelinePart>;
    styles?: PartOverrides<TimelinePart>;
  }
  let { as = 'ol', events, orientation = 'vertical', class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(['timeline', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} data-orientation={orientation}>{#each events as event, i (i)}<li class={partClass('', classes, 'item')} style={partStyle(undefined, styles, 'item')} data-intent={event.intent}><div class={partClass('marker', classes, 'marker')} style={partStyle(undefined, styles, 'marker')}>{event.icon ?? '◇'}</div><article class={partClass('', classes, 'content')} style={partStyle(undefined, styles, 'content')}><time>{event.time}</time><b>{event.title}</b>{#if event.description}<p>{event.description}</p>{/if}</article></li>{/each}</svelte:element>
<style>.timeline{--tone:var(--br-signal);display:grid;gap:0;margin:0;padding:0;list-style:none}.timeline li{position:relative;display:grid;grid-template-columns:24px 1fr;gap:8px;min-height:58px}.timeline li:not(:last-child)::before{content:'';position:absolute;left:11px;top:20px;bottom:0;border-left:1px solid var(--br-line)}.marker{z-index:1;display:grid;place-items:center;width:23px;height:23px;border:1px solid var(--tone);background:var(--br-panel);color:var(--tone);font-size:9px}.timeline li[data-intent='success']{--tone:var(--br-go)}.timeline li[data-intent='warning']{--tone:var(--br-caution)}.timeline li[data-intent='danger']{--tone:var(--br-danger)}article{display:grid;align-content:start}time{color:var(--br-dim);font-size:8px}b{color:var(--br-ink);font-size:10px}p{font-size:9px}.timeline[data-orientation='horizontal']{grid-auto-flow:column;grid-auto-columns:1fr;overflow:auto}.timeline[data-orientation='horizontal'] li{grid-template-columns:1fr;min-width:150px}.timeline[data-orientation='horizontal'] li::before{left:23px;right:0;top:11px;bottom:auto;border:0;border-top:1px solid var(--br-line)}</style>
