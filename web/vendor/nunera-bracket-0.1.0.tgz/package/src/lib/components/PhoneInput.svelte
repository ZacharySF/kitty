<script lang="ts">
  export interface PhoneCountry {
    code: string;
    name: string;
    flag: string;
    dialCode: string;
  }

  interface Props {
    value?: string;
    country?: string;
    countries?: PhoneCountry[];
    label?: string;
    disabled?: boolean;
    onchange?: (internationalValue: string) => void;
    oncountrychange?: (country: string) => void;
  }

  const defaults: PhoneCountry[] = [
    { code: 'US', name: 'United States', flag: '🇺🇸', dialCode: '+1' },
    { code: 'CA', name: 'Canada', flag: '🇨🇦', dialCode: '+1' },
    { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', dialCode: '+44' }
  ];

  let { value = $bindable(''), country = $bindable('US'), countries = defaults, label = 'Phone number', disabled = false, onchange, oncountrychange }: Props = $props();
  const selected = $derived(countries.find((item) => item.code === country) ?? countries[0]);
  const formatted = $derived(format(value, country));

  function digits(input: string) {
    return input.replace(/\D/g, '');
  }

  function format(input: string, countryCode: string) {
    const number = digits(input).slice(0, countryCode === 'GB' ? 10 : 10);
    if (countryCode === 'GB') return number.length > 4 ? `${number.slice(0, 4)} ${number.slice(4)}` : number;
    if (number.length <= 3) return number;
    if (number.length <= 6) return `(${number.slice(0, 3)}) ${number.slice(3)}`;
    return `(${number.slice(0, 3)}) ${number.slice(3, 6)}-${number.slice(6)}`;
  }

  function notify() {
    onchange?.(`${selected?.dialCode ?? ''}${digits(value)}`);
  }

  function input(event: Event & { currentTarget: EventTarget & HTMLInputElement }) {
    value = format(event.currentTarget.value, country);
    event.currentTarget.value = value;
    notify();
  }

  function selectCountry(event: Event & { currentTarget: EventTarget & HTMLSelectElement }) {
    country = event.currentTarget.value;
    value = format(value, country);
    oncountrychange?.(country);
    notify();
  }
</script>

<div class="phone br-control">
  <select aria-label="Country" value={country} {disabled} onchange={selectCountry}>
    {#each countries as item (item.code)}
      <option value={item.code}>{item.flag} {item.name} {item.dialCode}</option>
    {/each}
  </select>
  <span class="dial" aria-hidden="true">{selected?.dialCode}</span>
  <input type="tel" aria-label={label} value={formatted} {disabled} autocomplete="tel-national" oninput={input} />
</div>

<style>
  .phone select { width: auto; max-width: 11rem; border-inline-end: 1px solid var(--br-line); }
  .dial { padding-inline-start: var(--br-space-2); color: var(--br-mute); font-family: var(--br-font-display); }
</style>
