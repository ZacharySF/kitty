<script lang="ts">
  interface Props { message: string; position?: 'top' | 'bottom'; actionLabel?: string; dismissible?: boolean; onaction?: () => void; ondismiss?: () => void }
  let { message, position = 'top', actionLabel, dismissible = false, onaction, ondismiss }: Props = $props();
  let visible = $state(true);
  function dismiss() { visible = false; ondismiss?.(); }
</script>
{#if visible}<div class="banner" role="status" data-position={position}><span>{message}</span>{#if actionLabel}<button type="button" onclick={() => onaction?.()}>{actionLabel}</button>{/if}{#if dismissible}<button type="button" aria-label="Dismiss announcement" onclick={dismiss}>×</button>{/if}</div>{/if}
<style>.banner{position:relative;display:flex;align-items:center;justify-content:center;gap:var(--br-space-3);width:100%;padding:var(--br-space-2) var(--br-space-4);border-block:1px solid var(--br-line);background:var(--br-raised);color:var(--br-ink)}button{border:0;background:transparent;color:var(--br-signal);text-decoration:underline}</style>
