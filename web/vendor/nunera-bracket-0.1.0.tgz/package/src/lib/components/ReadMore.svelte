<script lang="ts">
  interface Props { text:string; maxChars?:number; expanded?:boolean; moreLabel?:string; lessLabel?:string }
  let { text,maxChars=160,expanded=$bindable(false),moreLabel='Read more',lessLabel='Show less' }:Props=$props();const truncated=$derived(text.length>maxChars);const visible=$derived(!expanded&&truncated?`${text.slice(0,maxChars).trimEnd()}…`:text);
</script>
<div class="read-more"><p>{visible}</p>{#if truncated}<button type="button" aria-expanded={expanded} onclick={()=>expanded=!expanded}>{expanded?lessLabel:moreLabel}</button>{/if}</div>
<style>p{margin:0;color:var(--br-ink)}button{margin-block-start:var(--br-space-1);padding:0;border:0;background:transparent;color:var(--br-signal);text-decoration:underline}</style>
