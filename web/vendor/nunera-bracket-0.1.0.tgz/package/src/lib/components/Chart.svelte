<script lang="ts">
  import type { Snippet } from 'svelte';

  export interface ChartPoint { x: number; y: number; label?: string; size?: number }
  export interface ChartSeries { name: string; color?: string; points: ChartPoint[] }
  export interface ChartAnnotation { x?: number; y?: number; label: string; color?: string }
  export interface ChartContext {
    sx: (value: number) => number;
    sy: (value: number) => number;
    bounds: { xMin: number; xMax: number; yMin: number; yMax: number };
  }
  export type ChartType = 'line' | 'area' | 'stacked-area' | 'bar' | 'grouped-bar' | 'stacked-bar' | 'pie' | 'scatter' | 'radar' | 'radial-bar' | 'heatmap' | 'calendar-heatmap' | 'treemap' | 'sunburst' | 'sankey' | 'funnel' | 'candlestick' | 'box-plot' | 'histogram' | 'violin' | 'waterfall' | 'gauge' | 'bullet' | 'network' | 'chord' | 'choropleth' | 'parallel' | 'sparkline';
  export interface ChartProps {
    series: ChartSeries[];
    width?: number;
    height?: number;
    type?: ChartType;
    minY?: number;
    maxY?: number;
    label?: string;
    legend?: boolean;
    tooltips?: boolean;
    dataLabels?: boolean;
    animate?: boolean;
    annotations?: ChartAnnotation[];
    renderer?: 'svg' | 'canvas' | 'auto';
    scaleY?: 'linear' | 'log';
    secondarySeries?: string[];
    syncId?: string;
    streaming?: boolean;
    overlay?: Snippet<[ChartContext]>;
    ondrilldown?: (series: ChartSeries, point: ChartPoint) => void;
    onbrush?: (range: { start: number; end: number }) => void;
    onexport?: (format: 'csv' | 'svg' | 'png', data: string) => void;
  }

  let {
    series, width = 480, height = 180, type = 'line', minY, maxY, label = 'Chart',
    legend = true, tooltips = true, dataLabels = true, animate = true, annotations = [],
    renderer = 'svg', scaleY = 'linear', secondarySeries = [], syncId, streaming = false,
    overlay, ondrilldown, onbrush, onexport
  }: ChartProps = $props();
  const ticks = [0, .25, .5, .75, 1];
  const colors = ['signal', 'go', 'caution', 'alternate'];
  const bars: ChartType[] = ['bar', 'grouped-bar', 'stacked-bar', 'heatmap', 'calendar-heatmap', 'treemap', 'funnel', 'candlestick', 'box-plot', 'histogram', 'violin', 'waterfall', 'bullet', 'choropleth'];
  const circles: ChartType[] = ['pie', 'radial-bar', 'sunburst', 'gauge', 'chord'];
  const pointTypes: ChartType[] = ['scatter', 'network'];
  let hidden = $state<string[]>([]);
  let zoom = $state(1);
  let crosshair = $state<number | null>(null);
  let brushStart = $state<number | null>(null);
  const activeSeries = $derived(series.filter((item) => !hidden.includes(item.name)));
  const useCanvas = $derived(renderer === 'canvas' || (renderer === 'auto' && series.reduce((total, item) => total + item.points.length, 0) > 5_000));
  const bounds = $derived.by(() => {
    let xMin = Infinity, xMax = -Infinity, yMin = Infinity, yMax = -Infinity;
    for (const item of activeSeries) for (const point of item.points) {
      if (point.x < xMin) xMin = point.x;
      if (point.x > xMax) xMax = point.x;
      const y = scaledY(point.y);
      if (y < yMin) yMin = y;
      if (y > yMax) yMax = y;
    }
    return {
      xMin: Number.isFinite(xMin) ? xMin : 0,
      xMax: Number.isFinite(xMax) ? xMax : 1,
      yMin: minY ?? (Number.isFinite(yMin) ? Math.min(0, yMin) : 0),
      yMax: maxY ?? (Number.isFinite(yMax) ? Math.max(1, yMax) : 1)
    };
  });
  const baseline = $derived(height - 20);
  const context = $derived<ChartContext>({ sx, sy, bounds });

  $effect(() => {
    if (!syncId || typeof window === 'undefined') return;
    const receive = (event: Event) => {
      const detail = (event as CustomEvent<{ syncId: string; x: number }>).detail;
      if (detail.syncId === syncId) crosshair = detail.x;
    };
    window.addEventListener('bracket-chart-crosshair', receive);
    return () => window.removeEventListener('bracket-chart-crosshair', receive);
  });

  function scaledY(value: number) {
    return scaleY === 'log' ? Math.log10(Math.max(Number.MIN_VALUE, value)) : value;
  }
  function sx(x: number) {
    return width / 2 + (34 + (x - bounds.xMin) / (bounds.xMax - bounds.xMin || 1) * (width - 48) - width / 2) * zoom;
  }
  function sy(y: number) {
    const value = scaledY(y);
    return height - 24 - (value - bounds.yMin) / (bounds.yMax - bounds.yMin || 1) * (height - 42);
  }
  function path(data: ChartPoint[]) {
    let result = '';
    for (let index = 0; index < data.length; index += 1) {
      const point = data[index];
      result += `${index ? 'L' : 'M'}${sx(point.x)},${sy(point.y)} `;
    }
    return result.trim();
  }
  function area(data: ChartPoint[]) {
    if (!data.length) return '';
    return `${path(data)} L${sx(data[data.length - 1].x)},${baseline} L${sx(data[0].x)},${baseline} Z`;
  }
  function color(item: ChartSeries, index: number) {
    return item.color ?? `var(--br-${colors[index % colors.length]})`;
  }
  function title(item: ChartSeries, point: ChartPoint) {
    return `${item.name}: ${point.label ?? point.x}, ${point.y}`;
  }
  function labelAllowed(data: ChartPoint[], index: number) {
    if (index === 0) return true;
    const current = data[index], previous = data[index - 1];
    return Math.hypot(sx(current.x) - sx(previous.x), sy(current.y) - sy(previous.y)) > 18;
  }
  function toggle(name: string) {
    hidden = hidden.includes(name) ? hidden.filter((item) => item !== name) : [...hidden, name];
  }
  function plotX(event: PointerEvent) {
    const bounds = (event.currentTarget as SVGElement).getBoundingClientRect();
    return Math.max(34, Math.min(width - 10, (event.clientX - bounds.left) / (bounds.width || width) * width));
  }
  function move(event: PointerEvent) {
    crosshair = plotX(event);
    if (syncId && typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('bracket-chart-crosshair', { detail: { syncId, x: crosshair } }));
  }
  function endBrush(event: PointerEvent) {
    if (brushStart === null) return;
    const end = plotX(event);
    onbrush?.({ start: Math.min(brushStart, end), end: Math.max(brushStart, end) });
    brushStart = null;
  }
  function drill(item: ChartSeries, point: ChartPoint) {
    ondrilldown?.(item, point);
  }
  function keydown(event: KeyboardEvent, item: ChartSeries, point: ChartPoint) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      drill(item, point);
    }
  }
  function sonify(point: ChartPoint) {
    if (typeof window === 'undefined' || !('AudioContext' in window)) return;
    const Audio = window.AudioContext;
    const audio = new Audio();
    const oscillator = audio.createOscillator();
    oscillator.frequency.value = 180 + Math.min(1_200, Math.abs(point.y) * 8);
    oscillator.connect(audio.destination);
    oscillator.start();
    oscillator.stop(audio.currentTime + .06);
    oscillator.addEventListener('ended', () => void audio.close(), { once: true });
  }
  function csv() {
    const rows = ['series,x,y,label'];
    for (const item of series) for (const point of item.points) rows.push([item.name, point.x, point.y, point.label ?? ''].map((value) => JSON.stringify(value)).join(','));
    return rows.join('\n');
  }
  function svgData() {
    return `<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 ${width} ${height}\">${activeSeries.map((item) => `<path d=\"${path(item.points)}\"/>`).join('')}</svg>`;
  }
  function exportChart(format: 'csv' | 'svg' | 'png') {
    if (format === 'csv') onexport?.('csv', csv());
    else if (format === 'svg') onexport?.('svg', svgData());
    else {
      const canvas = document.querySelector<HTMLCanvasElement>(`canvas[data-chart-canvas=\"${label}\"]`);
      onexport?.('png', canvas?.toDataURL('image/png') ?? '');
    }
  }
  function canvasPlot(node: HTMLCanvasElement) {
    if (typeof navigator !== 'undefined' && navigator.userAgent.includes('jsdom')) return;
    let context2d: CanvasRenderingContext2D | null = null;
    try { context2d = node.getContext('2d'); } catch { return; }
    if (!context2d) return;
    context2d.clearRect(0, 0, width, height);
    context2d.strokeStyle = '#38bdf8';
    context2d.lineWidth = 1;
    for (const item of activeSeries) {
      context2d.beginPath();
      item.points.forEach((point, index) => index ? context2d?.lineTo(sx(point.x), sy(point.y)) : context2d?.moveTo(sx(point.x), sy(point.y)));
      context2d.stroke();
    }
  }
</script>
<figure data-chart-type={type} data-animate={animate} data-zoom={zoom} data-renderer={useCanvas ? 'canvas' : 'svg'} style:--chart-height={`${height}px`}>
  <div class="chart-tools" role="toolbar" aria-label={`${label} controls`}>
    <button type="button" aria-label="Zoom out" onclick={() => zoom = Math.max(.5, zoom - .25)}>−</button>
    <button type="button" aria-label="Reset zoom" onclick={() => zoom = 1}>{Math.round(zoom * 100)}%</button>
    <button type="button" aria-label="Zoom in" onclick={() => zoom = Math.min(4, zoom + .25)}>+</button>
    <button type="button" aria-label="Export CSV" onclick={() => exportChart('csv')}>CSV</button>
    <button type="button" aria-label="Export SVG" onclick={() => exportChart('svg')}>SVG</button>
    {#if useCanvas}<button type="button" aria-label="Export PNG" onclick={() => exportChart('png')}>PNG</button>{/if}
  </div>
  {#if streaming}<span class="br-sr" aria-live="polite">Streaming data active</span>{/if}
  {#if useCanvas}<canvas data-chart-canvas={label} aria-label="Chart canvas rendering" width={width} height={height} use:canvasPlot></canvas>{/if}
  <svg
    viewBox={`0 0 ${width} ${height}`}
    role="group"
    aria-label={label}
    onpointermove={move}
    onpointerleave={() => crosshair = null}
    onpointerdown={(event) => brushStart = plotX(event)}
    onpointerup={endBrush}
  >
    <line class="axis" x1="34" x2={width - 10} y1={baseline} y2={baseline}/><line class="axis" x1="34" x2="34" y1="12" y2={baseline}/>
    {#if secondarySeries.length}<line class="axis secondary-axis" x1={width - 10} x2={width - 10} y1="12" y2={baseline}/>{/if}
    {#each ticks as tick (tick)}<line x1="34" x2={width - 10} y1={12 + tick * (height - 36)} y2={12 + tick * (height - 36)} class="grid"/><text x="2" y={15 + tick * (height - 36)}>{Math.round(bounds.yMax - (bounds.yMax - bounds.yMin) * tick)}</text>{/each}
    {#each activeSeries as item, index (item.name)}
      {@const tone = color(item, index)}
      {#if circles.includes(type)}
        {@const total = item.points.reduce((sum, point) => sum + Math.abs(point.y), 0) || 1}
        {#each item.points as point, pointIndex (`${point.x}-${pointIndex}`)}
          <circle class="series radial" data-series={item.name} role="button" aria-label={title(item, point)} tabindex="0" cx={width / 2} cy={height / 2} r={Math.max(12, Math.min(width, height) / 3 - pointIndex * 10)} pathLength="100" stroke-dasharray={`${Math.abs(point.y) / total * 100} 100`} style:stroke={tone} onclick={() => drill(item, point)} onkeydown={(event) => keydown(event, item, point)} onfocus={() => sonify(point)}>{#if tooltips}<title>{title(item, point)}</title>{/if}</circle>
          {#if dataLabels && labelAllowed(item.points, pointIndex)}<text class="data-label" x={width / 2} y={height / 2 - pointIndex * 10}>{point.label ?? point.y}</text>{/if}
        {/each}
      {:else if bars.includes(type)}
        {#each item.points as point, pointIndex (`${point.x}-${pointIndex}`)}
          <rect class="series" data-series={item.name} role="button" aria-label={title(item, point)} tabindex="0" x={sx(point.x) - 8 + index * 8} y={sy(point.y)} width="7" height={Math.max(1, baseline - sy(point.y))} style:fill={tone} onclick={() => drill(item, point)} onkeydown={(event) => keydown(event, item, point)} onfocus={() => sonify(point)}>{#if tooltips}<title>{title(item, point)}</title>{/if}</rect>
          {#if dataLabels && labelAllowed(item.points, pointIndex)}<text class="data-label" x={sx(point.x) - 6 + index * 8} y={sy(point.y) - 3}>{point.label ?? point.y}</text>{/if}
        {/each}
      {:else if pointTypes.includes(type)}
        {#each item.points as point, pointIndex (`${point.x}-${pointIndex}`)}
          <circle class="series" data-series={item.name} role="button" aria-label={title(item, point)} tabindex="0" cx={sx(point.x)} cy={sy(point.y)} r={point.size ?? 4} style:fill={tone} onclick={() => drill(item, point)} onkeydown={(event) => keydown(event, item, point)} onfocus={() => sonify(point)}>{#if tooltips}<title>{title(item, point)}</title>{/if}</circle>
          {#if dataLabels && labelAllowed(item.points, pointIndex)}<text class="data-label" x={sx(point.x) + 5} y={sy(point.y) - 5}>{point.label ?? point.y}</text>{/if}
        {/each}
      {:else}
        <path class="series" data-series={item.name} role="button" aria-label={item.name} tabindex="0" d={type === 'area' || type === 'stacked-area' ? area(item.points) : path(item.points)} style:stroke={tone} style:fill={type === 'area' || type === 'stacked-area' ? `color-mix(in srgb, ${tone} 18%, transparent)` : 'none'} onclick={() => item.points[0] && drill(item, item.points[0])} onkeydown={(event) => item.points[0] && keydown(event, item, item.points[0])} onfocus={() => item.points[0] && sonify(item.points[0])}>{#if tooltips}<title>{item.name}</title>{/if}</path>
        {#if dataLabels}{#each item.points as point, pointIndex (`${point.x}-${pointIndex}`)}{#if labelAllowed(item.points, pointIndex)}<text class="data-label" x={sx(point.x) + 3} y={sy(point.y) - 4}>{point.label ?? point.y}</text>{/if}{/each}{/if}
      {/if}
    {/each}
    {#each annotations as annotation, index (`${annotation.label}-${index}`)}
      <g class="annotation" style:--annotation={annotation.color ?? 'var(--br-warning)'}>
        {#if annotation.x !== undefined}<line x1={sx(annotation.x)} x2={sx(annotation.x)} y1="12" y2={baseline}/>{/if}
        {#if annotation.y !== undefined}<line x1="34" x2={width - 10} y1={sy(annotation.y)} y2={sy(annotation.y)}/>{/if}
        <text x={annotation.x === undefined ? 38 : sx(annotation.x) + 3} y={annotation.y === undefined ? 18 : sy(annotation.y) - 3}>{annotation.label}</text>
      </g>
    {/each}
    {#if crosshair !== null}<line class="crosshair" x1={crosshair} x2={crosshair} y1="12" y2={baseline}/>{/if}
    {#if overlay}{@render overlay(context)}{/if}
  </svg>
  <table class="br-sr"><caption>{label} data</caption><tbody>{#each series as item (item.name)}{#each item.points as point, index (`${point.x}-${index}`)}<tr><th>{item.name}</th><td>{point.label ?? point.x}</td><td>{point.y}</td></tr>{/each}{/each}</tbody></table>
  {#if legend}<figcaption>{#each series as item, index (item.name)}<button type="button" aria-label={`Toggle ${item.name}`} aria-pressed={!hidden.includes(item.name)} onclick={() => toggle(item.name)}><i style:background={color(item, index)}></i>{item.name}</button>{/each}</figcaption>{/if}
</figure>
<style>
  figure { margin: 0; }
  .chart-tools { display: flex; gap: 3px; margin-bottom: 3px; }
  .chart-tools button, figcaption button { border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; font-size: var(--br-text-xs); }
  svg, canvas { display: block; width: 100%; height: auto; max-height: var(--chart-height); border: 1px solid var(--br-line); background: var(--br-inset); }
  canvas + svg { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); }
  .axis { stroke: var(--br-mute); stroke-width: 1; }.grid { stroke: var(--br-line); stroke-width: 1; }.series { stroke-width: 2; vector-effect: non-scaling-stroke; cursor: pointer; }.series:focus { outline: none; stroke-width: 4; }.radial { fill: none; transform: rotate(-90deg); transform-origin: center; }
  text { fill: var(--br-mute); font-size: 8px; }.data-label { paint-order: stroke; stroke: var(--br-inset); stroke-width: 2px; }.annotation line { stroke: var(--annotation); stroke-dasharray: 4 3; }.annotation text { fill: var(--annotation); }.crosshair { stroke: var(--br-signal); stroke-width: 1; pointer-events: none; }
  figcaption { display: flex; flex-wrap: wrap; gap: var(--br-space-2); padding: var(--br-space-1); color: var(--br-mute); font-size: var(--br-text-xs); }figcaption button { display: flex; align-items: center; gap: var(--br-space-1); }figcaption button[aria-pressed='false'] { opacity: .45; }figcaption i { width: 8px; height: 3px; }
  figure[data-animate='true'] .series { animation: br-chart-load var(--br-motion-medium) var(--br-ease-entrance); transform-origin: bottom; }
  @keyframes br-chart-load { from { opacity: 0; transform: scaleY(0); } to { opacity: 1; transform: scaleY(1); } }
  @media (prefers-reduced-motion: reduce) { figure[data-animate='true'] .series { animation: none; } }
</style>
