<script lang="ts">
  interface Props { value?: number; count?: number; label?: string; icon?: string; readOnly?: boolean; disabled?: boolean; allowHalf?: boolean; onchange?: (value: number) => void }
  let { value = $bindable(0), count = 5, label = 'Rating', icon = '★', readOnly = false, disabled = false, allowHalf = true, onchange }: Props = $props();
  function choose(next: number) { if (disabled || readOnly) return; value = next; onchange?.(value); }
</script>

{#if readOnly}
  <div class="rating readonly" role="img" aria-label={`${label}: ${value} of ${count}`}>{#each Array.from({ length: count }) as _, index (index)}<span data-filled={value >= index + 1}>{icon}</span>{/each}</div>
{:else}
  <div class="rating" role="group" aria-label={label} data-half={allowHalf}>
    {#each Array.from({ length: allowHalf ? count * 2 : count }) as _, index (index)}
      {@const rating = allowHalf ? (index + 1) / 2 : index + 1}
      <button type="button" aria-label={`Rate ${rating} of ${count}`} aria-pressed={value === rating} data-filled={value >= rating} {disabled} onclick={() => choose(rating)}>{icon}</button>
    {/each}
  </div>
{/if}
<style>.rating{display:inline-flex}.rating button{width:16px;padding:0;border:0;background:transparent;color:var(--br-line);font-size:18px;overflow:hidden}.rating button:nth-child(even){margin-inline-end:2px}.rating [data-filled='true'],.readonly span[data-filled='true']{color:var(--br-caution)}.readonly{display:inline-flex;gap:2px;color:var(--br-line);font-size:18px}</style>
