<script lang="ts">
  export interface FooterLink { label:string; href:string }
  export interface FooterColumn { label:string; links:FooterLink[] }
  export interface SocialLink extends FooterLink { icon:string }
  interface Props { columns:FooterColumn[]; legal?:FooterLink[]; social?:SocialLink[]; copyright?:string }
  let { columns,legal=[],social=[],copyright }:Props=$props();
</script>
<footer><div class="columns">{#each columns as column (column.label)}<section><h2>{column.label}</h2>{#each column.links as link (link.href)}<a href={link.href}>{link.label}</a>{/each}</section>{/each}</div><div class="base">{#if copyright}<small>{copyright}</small>{/if}<nav aria-label="Legal">{#each legal as link (link.href)}<a href={link.href}>{link.label}</a>{/each}</nav><nav class="social" aria-label="Social media">{#each social as link (link.href)}<a href={link.href} aria-label={link.label}><span aria-hidden="true">{link.icon}</span></a>{/each}</nav></div></footer>
<style>footer{display:grid;gap:var(--br-space-4);padding:var(--br-space-4);border-top:1px solid var(--br-line);background:var(--br-panel)}.columns{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:var(--br-space-4)}section{display:grid;align-content:start;gap:var(--br-space-1)}h2{margin:0;color:var(--br-ink);font-size:var(--br-text-sm)}a{color:var(--br-mute);text-decoration:none}.base{display:flex;align-items:center;gap:var(--br-space-3);padding-block-start:var(--br-space-3);border-top:1px solid var(--br-line)}nav{display:flex;gap:var(--br-space-2)}.social{margin-inline-start:auto}</style>
