<script lang="ts">
  import { onMount, type Snippet } from 'svelte';
  export interface ContextMenuItem { id: string; label?: string; icon?: string; shortcut?: string; group?: string; disabled?: boolean; separator?: boolean; action?: () => void }
  interface Props { items: ContextMenuItem[]; children: Snippet; label?: string }
  let { items, children, label = 'Context actions' }: Props = $props();
  let open = $state(false);
  let x = $state(0);
  let y = $state(0);
  let root: HTMLElement;
  function close(){open=false;}
  function context(event: MouseEvent){event.preventDefault();x=event.clientX;y=event.clientY;open=true;queueMicrotask(()=>root.querySelector<HTMLButtonElement>('[role="menuitem"]:not(:disabled)')?.focus());}
  function choose(item: ContextMenuItem){if(item.disabled||!item.action)return;item.action();close();}
  function keydown(event: KeyboardEvent){const enabled=[...root.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not(:disabled)')];const current=enabled.indexOf(document.activeElement as HTMLButtonElement);if(event.key==='Escape'){close();}else if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();const delta=event.key==='ArrowDown'?1:-1;enabled[(current+delta+enabled.length)%enabled.length]?.focus();}}
  onMount(()=>{const outside=(event:PointerEvent)=>{if(open&&!root.contains(event.target as Node))close();};document.addEventListener('pointerdown',outside);return()=>document.removeEventListener('pointerdown',outside);});
</script>
<div class="context" role="presentation" bind:this={root} oncontextmenu={context}>
  {@render children()}
  {#if open}
    <div class="menu" role="menu" tabindex="-1" aria-label={label} style:left={`${x}px`} style:top={`${y}px`} onkeydown={keydown}>
      {#each items as item (item.id)}
        {#if item.separator}<div role="separator"></div>{:else}
          {#if item.group}<div class="group">{item.group}</div>{/if}
          <button type="button" role="menuitem" disabled={item.disabled} onclick={()=>choose(item)}>{#if item.icon}<span aria-hidden="true">{item.icon}</span>{/if}<span>{item.label}</span>{#if item.shortcut}<kbd>{item.shortcut}</kbd>{/if}</button>
        {/if}
      {/each}
    </div>
  {/if}
</div>
<style>.context{display:contents}.menu{position:fixed;z-index:var(--br-z-popover);min-width:180px;padding:var(--br-space-1);border:1px solid var(--br-lineHot);background:var(--br-panel);box-shadow:var(--br-shadow-lg)}button{display:grid;grid-template-columns:auto 1fr auto;gap:var(--br-space-2);width:100%;padding:var(--br-space-2);border:0;background:transparent;color:var(--br-ink);text-align:start}button:hover,button:focus{background:var(--br-structure);color:var(--br-on-structure)}button:disabled{opacity:.45}.group{padding:var(--br-space-1) var(--br-space-2);color:var(--br-dim);font-size:var(--br-text-xs);text-transform:uppercase}div[role='separator']{height:1px;margin:var(--br-space-1);background:var(--br-line)}kbd{color:inherit}</style>
