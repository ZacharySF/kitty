<script lang="ts">
  import type { HTMLAttributes } from 'svelte/elements';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type SkeletonPart = 'root' | 'item';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    width?: string;
    height?: string;
    shape?: 'text' | 'rect' | 'circle';
    lines?: number;
    animation?: 'pulse' | 'shimmer';
    loaded?: boolean;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<SkeletonPart>;
    styles?: PartOverrides<SkeletonPart>;
  }
  let { as = 'div', width = '100%', height = '12px', shape = 'rect', animation = 'shimmer', lines = 1, loaded = false, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
</script>
{#if !loaded}<svelte:element this={as} {...rest} bind:this={ref} class={partClass(['group', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} aria-hidden="true">{#each Array(lines) as _, i (i)}<span class={partClass('br-skeleton', classes, 'item')} style={partStyle(undefined, styles, 'item')} data-shape={shape} data-animation={animation} style:width={i === lines - 1 && lines > 1 ? '72%' : width} style:height></span>{/each}</svelte:element><span class="br-sr" role="status">Loading</span>{/if}
<style>.group{display:grid;gap:5px}.br-skeleton{display:block}.br-skeleton[data-shape='circle']{aspect-ratio:1;border-radius:50%}.br-skeleton[data-shape='text']{height:.8em!important}.br-skeleton[data-animation='pulse']{animation:pulse 1.2s ease-in-out infinite}.br-skeleton[data-animation='shimmer']{overflow:hidden}@keyframes pulse{50%{opacity:.45}}</style>
