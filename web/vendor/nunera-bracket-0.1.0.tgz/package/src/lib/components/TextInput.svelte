<script lang="ts">
  import type { HTMLInputAttributes } from 'svelte/elements';
  import type { Size } from '../types';
  import { getMessages } from '../headless/messages';

  interface Props extends Omit<HTMLInputAttributes, 'size' | 'value'> {
    value?: string;
    size?: Size;
    variant?: 'outline' | 'filled' | 'underline';
    prefix?: string;
    suffix?: string;
    clearable?: boolean;
    invalid?: boolean;
  }

  let {
    value = $bindable(''),
    size = 'md',
    variant = 'outline',
    prefix,
    suffix,
    clearable = false,
    invalid = false,
    oninput,
    ...rest
  }: Props = $props();
  const messages = $derived(getMessages());
</script>

<div class="br-control" data-invalid={invalid} data-size={size} data-variant={variant}>
  {#if prefix}<span class="br-control__part">{prefix}</span>{/if}
  <input {...rest} bind:value aria-invalid={invalid} oninput={(event) => oninput?.(event)} />
  {#if clearable && value}<button class="clear" type="button" aria-label={messages.clearInput} onclick={() => (value = '')}>×</button>{/if}
  {#if suffix}<span class="br-control__part">{suffix}</span>{/if}
</div>

<style>
  .br-control[data-size='xs'] { min-height: 22px; }
  .br-control[data-size='sm'] { min-height: 26px; }
  .br-control[data-size='lg'] { min-height: 38px; }
  .br-control[data-variant='filled'] { border-color: transparent; background: var(--br-raised); }
  .br-control[data-variant='underline'] { border-width: 0 0 1px; background: transparent; }
  .clear { width: 26px; height: 26px; border: 0; background: transparent; color: var(--br-mute); cursor: pointer; }
  .clear:hover { color: var(--br-ink); }
</style>
