<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';
  import { responsiveVariables, type ResponsiveValue } from '../responsive';
  export type BoxPart = 'root';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    children?: Snippet;
    class?: string;
    padding?: ResponsiveValue<string>;
    margin?: ResponsiveValue<string>;
    background?: ResponsiveValue<'void' | 'panel' | 'inset' | 'raised'>;
    radius?: 'none' | 'sm' | 'md' | 'lg' | (string & {});
    border?: boolean;
    ref?: HTMLElement | null;
    classes?: PartOverrides<BoxPart>;
    styles?: PartOverrides<BoxPart>;
  }
  let { as = 'div', children, class: className = '', style = '', padding, margin, background, border = false, radius, ref = $bindable(null), classes, styles, ...rest }: Props = $props();
  const responsiveStyle = $derived([
    responsiveVariables('box-padding', padding),
    responsiveVariables('box-margin', margin),
    responsiveVariables('box-background', background, (value) => `var(--br-${value})`),
    border ? 'border:1px solid var(--br-line)' : '',
    radius ? `border-radius:${['none', 'sm', 'md', 'lg'].includes(radius) ? `var(--br-radius-${radius})` : radius}` : '',
    style
  ].filter(Boolean).join(';'));
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(`br-box ${className}`.trim(), classes, 'root')} style={partStyle(responsiveStyle, styles, 'root')}>{@render children?.()}</svelte:element>

<style>
  .br-box {
    padding: var(--br-box-padding-base, initial);
    margin: var(--br-box-margin-base, initial);
    background: var(--br-box-background-base, initial);
  }
  @media (min-width: 30rem) {
    .br-box {
      padding: var(--br-box-padding-sm, var(--br-box-padding-base, initial));
      margin: var(--br-box-margin-sm, var(--br-box-margin-base, initial));
      background: var(--br-box-background-sm, var(--br-box-background-base, initial));
    }
  }
  @media (min-width: 48rem) {
    .br-box {
      padding: var(--br-box-padding-md, var(--br-box-padding-sm, var(--br-box-padding-base, initial)));
      margin: var(--br-box-margin-md, var(--br-box-margin-sm, var(--br-box-margin-base, initial)));
      background: var(--br-box-background-md, var(--br-box-background-sm, var(--br-box-background-base, initial)));
    }
  }
  @media (min-width: 64rem) {
    .br-box {
      padding: var(--br-box-padding-lg, var(--br-box-padding-md, var(--br-box-padding-sm, var(--br-box-padding-base, initial))));
      margin: var(--br-box-margin-lg, var(--br-box-margin-md, var(--br-box-margin-sm, var(--br-box-margin-base, initial))));
      background: var(--br-box-background-lg, var(--br-box-background-md, var(--br-box-background-sm, var(--br-box-background-base, initial))));
    }
  }
  @media (min-width: 80rem) {
    .br-box {
      padding: var(--br-box-padding-xl, var(--br-box-padding-lg, var(--br-box-padding-md, var(--br-box-padding-sm, var(--br-box-padding-base, initial)))));
      margin: var(--br-box-margin-xl, var(--br-box-margin-lg, var(--br-box-margin-md, var(--br-box-margin-sm, var(--br-box-margin-base, initial)))));
      background: var(--br-box-background-xl, var(--br-box-background-lg, var(--br-box-background-md, var(--br-box-background-sm, var(--br-box-background-base, initial)))));
    }
  }
</style>
