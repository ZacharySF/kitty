<script lang="ts">
  export interface NavigationMenuLink { label:string; href:string; description?:string }
  export interface NavigationMenuGroup { id:string; label:string; href?:string; links?:NavigationMenuLink[] }
  interface Props { groups:NavigationMenuGroup[]; label?:string }
  let { groups,label='Site navigation' }:Props=$props();let open=$state<string>();
</script>
<nav aria-label={label}><ul>{#each groups as group (group.id)}<li>{#if group.links?.length}<button type="button" aria-expanded={open===group.id} onclick={()=>open=open===group.id?undefined:group.id}>{group.label}</button>{:else}<a href={group.href}>{group.label}</a>{/if}{#if open===group.id&&group.links}<div class="panel">{#each group.links as link (link.href)}<a href={link.href}><strong>{link.label}</strong>{#if link.description}<small>{link.description}</small>{/if}</a>{/each}</div>{/if}</li>{/each}</ul></nav>
<style>ul{display:flex;gap:var(--br-space-1);margin:0;padding:0;list-style:none}li{position:relative}button,li>a{display:block;padding:var(--br-space-2) var(--br-space-3);border:0;background:transparent;color:var(--br-ink);text-decoration:none}.panel{position:absolute;z-index:var(--br-z-popover);display:grid;grid-template-columns:repeat(2,minmax(140px,1fr));gap:var(--br-space-1);min-width:320px;padding:var(--br-space-2);border:1px solid var(--br-lineHot);background:var(--br-panel);box-shadow:var(--br-shadow-lg)}.panel a{display:grid;padding:var(--br-space-2);color:var(--br-ink);text-decoration:none}.panel a:hover{background:var(--br-structure)}small{color:var(--br-mute)}</style>
