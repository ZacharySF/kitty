<script lang="ts">
  import Button from './Button.svelte';
  export interface SplitAction { id: string; label: string; disabled?: boolean }
  interface Props { label: string; actions: SplitAction[]; disabled?: boolean; onprimary?: () => void; onselect?: (id: string) => void }
  let { label, actions, disabled = false, onprimary, onselect }: Props = $props();
  let open = $state(false);
  function select(action: SplitAction) { if (action.disabled) return; onselect?.(action.id); open = false; }
</script>
<div class="split"><Button {disabled} onclick={onprimary}>{label}</Button><Button {disabled} aria-label="Related actions" aria-haspopup="menu" aria-expanded={open} onclick={() => (open = !open)}>▾</Button>{#if open}<div class="menu" role="menu" aria-label="Related actions">{#each actions as action (action.id)}<button type="button" role="menuitem" disabled={action.disabled} onclick={() => select(action)}>{action.label}</button>{/each}</div>{/if}</div>
<style>.split { position: relative; display: inline-flex; } .split > :global(.br-btn + .br-btn) { margin-inline-start: -1px; } .menu { position: absolute; inset-block-start: calc(100% + 4px); inset-inline-end: 0; z-index: var(--br-z-popover); display: grid; min-width: 10rem; border: 1px solid var(--br-line); background: var(--br-panel); } .menu button { padding: 6px 9px; border: 0; background: transparent; color: var(--br-ink); text-align: start; } .menu button:hover { background: var(--br-structure-wash); }</style>
