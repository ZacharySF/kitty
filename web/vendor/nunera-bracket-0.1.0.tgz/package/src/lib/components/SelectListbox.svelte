<script lang="ts">
  import type { Option } from '../types';

  interface Props { value?: string | string[]; options: Option<string>[]; placeholder?: string; label?: string; multiple?: boolean; disabled?: boolean; onchange?: (value: string | string[]) => void }
  let { value = $bindable(''), options, placeholder = 'Select an option', label = 'Select', multiple = false, disabled = false, onchange }: Props = $props();
  let open = $state(false);
  let active = $state(0);
  let typed = '';
  let timer: ReturnType<typeof setTimeout> | undefined;
  const instanceId = $props.id();
  const listboxId = `${instanceId}-listbox`;
  const selected = (item: string) => Array.isArray(value) ? value.includes(item) : value === item;
  const display = $derived(Array.isArray(value) ? options.filter((option) => value.includes(option.value)).map((option) => option.label).join(', ') : options.find((option) => option.value === value)?.label ?? placeholder);
  const groups = $derived([...new Set(options.map((option) => option.group).filter((group): group is string => Boolean(group)))]);

  function choose(option: Option<string>) {
    if (option.disabled) return;
    if (multiple) value = selected(option.value) ? (value as string[]).filter((item) => item !== option.value) : [...(Array.isArray(value) ? value : []), option.value];
    else { value = option.value; open = false; }
    onchange?.(value);
  }

  function move(direction: number) {
    for (let offset = 1; offset <= options.length; offset += 1) {
      const index = (active + direction * offset + options.length) % options.length;
      if (!options[index].disabled) { active = index; return; }
    }
  }

  function keydown(event: KeyboardEvent) {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); open = true; move(event.key === 'ArrowDown' ? 1 : -1); return; }
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); if (!open) open = true; else choose(options[active]); return; }
    if (event.key === 'Escape') { open = false; return; }
    if (event.key.length !== 1 || event.ctrlKey || event.metaKey || event.altKey) return;
    typed += event.key.toLowerCase();
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => (typed = ''), 500);
    const match = options.findIndex((option) => !option.disabled && option.label.toLowerCase().startsWith(typed));
    if (match >= 0) active = match;
  }
</script>

<div class="select-listbox">
  <button type="button" role="combobox" aria-label={label} aria-haspopup="listbox" aria-controls={listboxId} aria-expanded={open} {disabled} onkeydown={keydown} onclick={() => (open = !open)}>{display}</button>
  {#if open}
    <div id={listboxId} class="listbox" role="listbox" aria-label={`${label} options`} aria-multiselectable={multiple}>
      {#each groups as group (group)}
        <div role="group" aria-label={group}>
          {#each options.filter((option) => option.group === group) as option (option.value)}
            <button type="button" role="option" aria-selected={selected(option.value)} aria-disabled={option.disabled} data-active={options[active] === option} onclick={() => choose(option)}>{option.label}</button>
          {/each}
        </div>
      {/each}
      {#each options.filter((option) => !option.group) as option (option.value)}
        <button type="button" role="option" aria-selected={selected(option.value)} aria-disabled={option.disabled} data-active={options[active] === option} onclick={() => choose(option)}>{option.label}</button>
      {/each}
    </div>
  {/if}
</div>

<style>.select-listbox{position:relative}.select-listbox>button{width:100%;min-height:var(--br-control-h);border:1px solid var(--br-line);background:var(--br-inset);color:var(--br-ink);text-align:start}.listbox{position:absolute;z-index:var(--br-z-popover);inset-block-start:100%;width:100%;display:grid;border:1px solid var(--br-line);background:var(--br-panel)}.listbox [role='group']{display:grid}.listbox [role='group']::before{content:attr(aria-label);padding:4px;color:var(--br-mute);font-size:9px}.listbox button{padding:6px;border:0;background:transparent;color:var(--br-ink);text-align:start}.listbox button[data-active='true'],.listbox button:hover{background:var(--br-structure-wash)}.listbox button[aria-disabled='true']{opacity:.4}</style>
