<script lang="ts">
  import type { Snippet } from 'svelte';

  interface Props {
    legend: string;
    children: Snippet;
    disabled?: boolean;
    description?: string;
    class?: string;
  }

  let { legend, children, disabled = false, description, class: className = '' }: Props = $props();
</script>

<fieldset class={['br-fieldset', className]} {disabled}>
  <legend>{legend}</legend>
  {#if description}<p>{description}</p>{/if}
  <div class="controls">{@render children()}</div>
</fieldset>

<style>
  .br-fieldset { display: grid; gap: var(--br-space-2); min-width: 0; margin: 0; padding: var(--br-space-3); border: 1px solid var(--br-line); }
  legend { padding-inline: var(--br-space-1); color: var(--br-ink); font-weight: 700; }
  p { margin: 0; color: var(--br-mute); }
  .controls { display: grid; gap: var(--br-space-2); }
</style>
