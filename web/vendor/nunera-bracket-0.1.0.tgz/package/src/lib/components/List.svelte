<script lang="ts">
  import List from './List.svelte';
  export interface ListItem { label:string; children?:ListItem[] }
  interface Props { items:ListItem[]; ordered?:boolean; marker?:string }
  let { items,ordered=false,marker }:Props=$props();
</script>
<svelte:element this={ordered?'ol':'ul'} class="list" data-marker={marker?'custom':'default'} style:--marker={marker?`'${marker}'`:undefined}>{#each items as item,index (`${item.label}-${index}`)}<li><span>{item.label}</span>{#if item.children?.length}<List items={item.children} {ordered} {marker}/>{/if}</li>{/each}</svelte:element>
<style>.list{display:grid;gap:var(--br-space-1);margin:0;padding-inline-start:var(--br-space-5);color:var(--br-ink)}.list[data-marker='custom']{list-style:none}.list[data-marker='custom']>li{position:relative}.list[data-marker='custom']>li::before{content:var(--marker);position:absolute;inset-inline-end:calc(100% + var(--br-space-2));color:var(--br-signal)}</style>
