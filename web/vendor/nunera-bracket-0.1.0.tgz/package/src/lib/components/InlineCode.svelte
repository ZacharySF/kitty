<script lang="ts">import type { Snippet } from 'svelte'; import type { HTMLAttributes } from 'svelte/elements'; interface Props extends HTMLAttributes<HTMLElement> { children: Snippet } let { children, ...rest }: Props = $props();</script>
<code {...rest} class="inline-code">{@render children()}</code>
<style>.inline-code { padding: .1em .35em; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-caution); font-family: var(--br-font-ui); font-size: .9em; }</style>
