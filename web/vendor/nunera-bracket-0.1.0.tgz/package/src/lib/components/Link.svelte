<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAnchorAttributes } from 'svelte/elements';
  interface Props extends HTMLAnchorAttributes { href: string; children: Snippet; external?: boolean; standalone?: boolean; underline?: 'always' | 'hover' | 'none'; ref?: HTMLAnchorElement | null }
  let { href, children, external = false, standalone = false, underline = 'always', ref = $bindable(null), rel, target, ...rest }: Props = $props();
</script>
<a {...rest} bind:this={ref} {href} rel={external ? rel ?? 'noreferrer noopener' : rel} target={external ? target ?? '_blank' : target} data-external={external} data-standalone={standalone} data-underline={underline}>
  {@render children()}{#if external}<svg class="external" viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3H3v10h10v-3M9 3h4v4M13 3 7 9" /></svg>{/if}
</a>
<style>a { color: var(--br-reference); text-underline-offset: 3px; } a[data-standalone='true'] { display: inline-flex; align-items: center; gap: .35em; } a[data-underline='hover'] { text-decoration: none; } a[data-underline='hover']:hover { text-decoration: underline; } a[data-underline='none'] { text-decoration: none; } .external { width: 1em; height: 1em; fill: none; stroke: currentColor; stroke-width: 1.5; }</style>
