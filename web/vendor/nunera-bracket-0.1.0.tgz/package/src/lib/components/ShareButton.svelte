<script lang="ts">
  interface Props { title?: string; text?: string; url?: string; label?: string }
  let { title, text, url = typeof location === 'undefined' ? '' : location.href, label = 'Share' }: Props = $props();
  let fallback = $state(false);
  async function share() { if (typeof navigator !== 'undefined' && navigator.share) { await navigator.share({ title, text, url }); return; } fallback = !fallback; }
  const encoded = $derived(encodeURIComponent(`${title ?? ''} ${url}`.trim()));
</script>
<div class="share"><button type="button" class="br-btn" aria-haspopup="menu" aria-expanded={fallback} onclick={share}>{label}</button>{#if fallback}<div class="menu" role="menu" aria-label="Share options"><a role="menuitem" href={`mailto:?subject=${encodeURIComponent(title ?? '')}&body=${encoded}`}>Share by email</a><a role="menuitem" href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`} target="_blank" rel="noreferrer">Share on LinkedIn</a></div>{/if}</div>
<style>.share { position: relative; display: inline-block; } .menu { position: absolute; inset-block-start: calc(100% + 4px); inset-inline-end: 0; z-index: var(--br-z-popover); display: grid; min-width: 12rem; border: 1px solid var(--br-line); background: var(--br-panel); } .menu a { padding: 7px 9px; color: var(--br-ink); text-decoration: none; } .menu a:hover { background: var(--br-structure-wash); }</style>
