<script lang="ts">
  export interface Message {
    id: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    time?: string;
    status?: 'streaming' | 'sent' | 'error';
    author?: string;
    avatar?: string;
  }
  interface Props {
    messages: Message[];
    stickToBottom?: boolean;
    oncopy?: (message: Message) => void;
    onretry?: (message: Message) => void;
  }
  let { messages, stickToBottom = true, oncopy, onretry }: Props = $props();
  let list = $state<HTMLElement>();
  let atBottom = $state(true);
  $effect(() => {
    messages;
    if (stickToBottom && atBottom) queueMicrotask(() => list?.scrollTo?.({ top: list.scrollHeight, behavior: 'smooth' }));
  });
  function scroll() {
    if (!list) return;
    atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 36;
  }
  function name(message: Message) {
    return message.author ?? (message.role === 'assistant' ? 'Bracket AI' : message.role);
  }
</script>

<section class="chat" bind:this={list} onscroll={scroll} aria-label="Conversation" aria-live="polite">
  {#each messages as message (message.id)}
    <article data-role={message.role} data-status={message.status}>
      <header>
        {#if message.avatar}<img src={message.avatar} alt="" />{:else}<span class="avatar" aria-hidden="true">{name(message).slice(0, 2).toUpperCase()}</span>{/if}
        <b>{name(message)}</b>
        {#if message.time}<time>{message.time}</time>{/if}
      </header>
      <p>{message.content}{#if message.status === 'streaming'} <i>▌</i>{/if}</p>
      <footer><button aria-label="Copy message" onclick={() => oncopy?.(message)}>copy</button>{#if message.status === 'error'}<button onclick={() => onretry?.(message)}>retry</button>{/if}</footer>
    </article>
  {/each}
</section>
{#if !atBottom}<button class="jump" onclick={() => list?.scrollTo?.({ top: list.scrollHeight, behavior: 'smooth' })}>New messages ↓</button>{/if}
<style>
  .chat { position: relative; display: grid; align-content: start; gap: 10px; max-height: 420px; overflow: auto; padding: 10px; border: 1px solid var(--br-line); background: var(--br-inset); }
  article { display: grid; gap: 3px; max-width: 78%; padding: 7px 9px; border: 1px solid var(--br-line); background: var(--br-panel); }
  article[data-role='user'] { justify-self: end; border-color: color-mix(in srgb, var(--br-signal) 55%, var(--br-line)); }
  article[data-role='system'] { justify-self: center; max-width: 100%; background: transparent; color: var(--br-dim); }
  header { display: grid; grid-template-columns: auto 1fr auto; gap: 5px; align-items: center; color: var(--br-dim); font-size: 8px; }
  header b { color: var(--br-structure); font-weight: 400; }
  header img, .avatar { display: grid; place-items: center; width: 18px; height: 18px; border-radius: 50%; background: var(--br-raised); color: var(--br-signal); object-fit: cover; }
  p { margin: 0; color: var(--br-ink); font-size: 10.5px; white-space: pre-wrap; }
  p i { color: var(--br-signal); font-style: normal; animation: blink 1s steps(2) infinite; }
  footer { display: flex; gap: 6px; }
  footer button, .jump { border: 0; background: none; color: var(--br-mute); font-size: 8px; cursor: pointer; }
  .jump { padding: 4px; border: 1px solid var(--br-line); background: var(--br-panel); color: var(--br-signal); }
  @keyframes blink { 50% { opacity: 0; } }
  @media (prefers-reduced-motion: reduce) { p i { animation: none; } }
</style>
