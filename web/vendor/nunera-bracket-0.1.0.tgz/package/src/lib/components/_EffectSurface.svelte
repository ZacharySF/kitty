<script lang="ts">
  export type EffectMode = 'number-ticker-animated-number' | 'typewriter' | 'scramble-decrypt-text' | 'gradient-text' | 'shimmer-text' | 'word-rotate' | 'split-text-reveal' | 'blur-in-text' | 'morphing-text' | 'text-highlighter' | 'animated-border-border-beam' | 'spotlight-glow' | 'tilt-3d-card' | 'magnetic' | 'parallax' | 'scroll-reveal-blur-fade' | 'scroll-progress-bar' | 'shared-layout-morph-transitions' | 'animated-list' | 'confetti-fireworks' | 'particles-starfield-meteors-sparkles' | 'grid-dot-mesh-aurora-backgrounds' | 'ripple' | 'animated-beam' | 'orbiting-circles' | 'interactive-globe' | 'lens-magnifier' | 'custom-cursor-cursor-trail' | 'hover-image-reveal' | 'animated-icons';
  export interface EffectSurfaceProps { mode: EffectMode; text?: string; value?: number; locale?: string; duration?: number }
  let { mode, text = 'BRACKET ONLINE', value = 1284, locale = 'en-US', duration = 900 }: EffectSurfaceProps = $props();
  let visible = $state(true);
  let displayValue = $state(0);
  let progress = $state(42);
  let alternate = $state(false);
  let x = $state(50);
  let y = $state(50);
  let reduceMotion = $state(false);
  const words = ['RELIABLE', 'PRECISE', 'READY'];
  const letters = $derived(text.split(''));
  const formatted = $derived(new Intl.NumberFormat(locale).format(displayValue));
  const particles = Array.from({ length: 14 }, (_, index) => index);

  function observe(node: HTMLElement) {
    if (typeof IntersectionObserver === 'undefined') return;
    const observer = new IntersectionObserver(([entry]) => visible = entry.isIntersecting, { threshold: 0.05 });
    observer.observe(node);
    return { destroy: () => observer.disconnect() };
  }
  $effect(() => {
    if (typeof window === 'undefined') return;
    const media = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    const update = () => reduceMotion = media?.matches ?? false;
    update();
    media?.addEventListener?.('change', update);
    return () => media?.removeEventListener?.('change', update);
  });
  $effect(() => {
    if (mode !== 'number-ticker-animated-number' || !visible || reduceMotion || typeof requestAnimationFrame === 'undefined') {
      displayValue = value;
      return;
    }
    const start = performance.now();
    let frame = 0;
    const tick = (time: number) => {
      const elapsed = Math.min(1, (time - start) / duration);
      const spring = 1 - Math.exp(-7 * elapsed) * Math.cos(10 * elapsed);
      displayValue = Math.round(value * Math.min(1, spring));
      if (elapsed < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  });
  $effect(() => {
    if (mode !== 'scroll-progress-bar' || typeof window === 'undefined') return;
    const update = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      progress = total > 0 ? Math.round((window.scrollY / total) * 100) : 100;
    };
    update();
    window.addEventListener('scroll', update, { passive: true });
    return () => window.removeEventListener('scroll', update);
  });

  function pointer(event: PointerEvent) {
    const target = event.currentTarget as HTMLElement;
    const box = target.getBoundingClientRect();
    x = ((event.clientX - box.left) / box.width) * 100;
    y = ((event.clientY - box.top) / box.height) * 100;
    if (mode === 'tilt-3d-card') {
      target.style.setProperty('--rx', `${((0.5 - y / 100) * 20).toFixed(0)}deg`);
      target.style.setProperty('--ry', `${((x / 100 - 0.5) * 20).toFixed(0)}deg`);
    }
  }
  function reset(event: PointerEvent) {
    const target = event.currentTarget as HTMLElement;
    target.style.setProperty('--rx', '0deg');
    target.style.setProperty('--ry', '0deg');
    x = 50; y = 50;
  }
</script>

<section class="effect" data-module={mode} data-visible={visible} data-reduced-motion={reduceMotion} use:observe style:--x={`${x}%`} style:--y={`${y}%`}>
  {#if mode === 'number-ticker-animated-number'}
    <output aria-label={`${value} animated`}>{#each formatted as character, index (`${index}-${character}`)}<span class="rolling-digit">{character}</span>{/each}</output>
  {:else if mode === 'typewriter'}
    <span class="typewriter animated">{text}</span>
  {:else if mode === 'scramble-decrypt-text'}
    <span class="scramble animated" data-value={text}>{text}</span>
  {:else if mode === 'gradient-text'}
    <span class="gradient-text">{text}</span>
  {:else if mode === 'shimmer-text'}
    <span class="shimmer-text animated">{text}</span>
  {:else if mode === 'word-rotate'}
    <span class="word-rotate">{#each words as word, index (word)}<i class="animated" style:--index={index}>{word}</i>{/each}</span>
  {:else if mode === 'split-text-reveal'}
    <span class="split-text"><span class="sr-only">{text}</span>{#each letters as letter, index (index)}<i class="animated" aria-hidden="true" style:--index={index}>{letter === ' ' ? '\u00a0' : letter}</i>{/each}</span>
  {:else if mode === 'blur-in-text'}
    <span class="blur-in animated">{text}</span>
  {:else if mode === 'morphing-text'}
    <span class="morphing-text animated">{alternate ? 'CONNECTED' : text}</span><button type="button" onclick={() => alternate = !alternate}>MORPH</button>
  {:else if mode === 'text-highlighter'}
    <p>Signal remains <mark class="animated">within tolerance</mark>.</p>
  {:else if mode === 'animated-border-border-beam'}
    <div class="beam-border"><i class="animated"></i><b>SECURE CHANNEL</b></div>
  {:else if mode === 'spotlight-glow'}
    <div class="spotlight" role="group" aria-label="Cursor spotlight" onpointermove={pointer}><i></i><b>CURSOR SPOTLIGHT</b></div>
  {:else if mode === 'tilt-3d-card'}
    <div class="tilt-card" role="group" aria-label="3D telemetry card" onpointermove={pointer} onpointerleave={reset}><i></i><b>3D TELEMETRY CARD</b></div>
  {:else if mode === 'magnetic'}
    <button class="magnetic" type="button" onpointermove={pointer} onpointerleave={reset} style:--mx={`${(x - 50) / 5}px`} style:--my={`${(y - 50) / 5}px`}>MAGNETIC ACTION</button>
  {:else if mode === 'parallax'}
    <div class="parallax" role="group" aria-label="Parallax layers" onpointermove={pointer}><i class="parallax-layer back" style:transform={`translate(${(x - 50) / 8}px, ${(y - 50) / 8}px)`}></i><i class="parallax-layer middle" style:transform={`translate(${(x - 50) / 4}px, ${(y - 50) / 4}px)`}></i><b class="parallax-layer front" style:transform={`translate(${(x - 50) / 2}px, ${(y - 50) / 2}px)`}>PARALLAX</b></div>
  {:else if mode === 'scroll-reveal-blur-fade'}
    <div class="scroll-reveal animated">REVEALED IN VIEW</div>
  {:else if mode === 'scroll-progress-bar'}
    <div class="progress-track"><i role="progressbar" aria-label="Reading progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow={progress} style:--progress={progress / 100}></i></div><output>{progress}% READ</output>
  {:else if mode === 'shared-layout-morph-transitions'}
    <button type="button" class:alternate onclick={() => alternate = !alternate}><i class="morph-item"></i><span>{alternate ? 'DETAIL' : 'SUMMARY'}</span></button>
  {:else if mode === 'animated-list'}
    <ul>{#each ['Acquire signal', 'Decode packet', 'Verify source'] as item, index (item)}<li class="animated" style:--index={index}>{item}</li>{/each}</ul>
  {:else if mode === 'confetti-fireworks'}
    <div class="burst" aria-label="Celebration confetti">{#each particles as item (item)}<i class="confetti-piece animated" style:--index={item}></i>{/each}<b>SUCCESS</b></div>
  {:else if mode === 'particles-starfield-meteors-sparkles'}
    <div class="particle-field" aria-label="Starfield particles">{#each particles as item (item)}<i class="particle animated" style:--index={item} style:--px={`${(item - 7) * 11}px`} style:--py={`${(item % 4) * 16 - 30}px`}></i>{/each}<b>DEEP FIELD</b></div>
  {:else if mode === 'grid-dot-mesh-aurora-backgrounds'}
    <div class="motion-background"><i class="animated"></i><b>AURORA GRID</b></div>
  {:else if mode === 'ripple'}
    <div class="ripple"><b>SIGNAL</b>{#each [0, 1, 2] as item (item)}<i class="ring animated" style:--index={item}></i>{/each}</div>
  {:else if mode === 'animated-beam'}
    <span class="sr-only">Animated connector beam</span><svg viewBox="0 0 320 100" role="img" aria-label="Animated connector beam"><circle cx="35" cy="50" r="20"/><circle cx="285" cy="50" r="20"/><path class="connector animated" d="M55 50H265"/></svg>
  {:else if mode === 'orbiting-circles'}
    <div class="orbit-system"><b>CORE</b>{#each [0, 1, 2] as item (item)}<i class="orbit animated" style:--index={item}><span>{item + 1}</span></i>{/each}</div>
  {:else if mode === 'interactive-globe'}
    <span class="sr-only">Interactive globe</span><svg class="globe" viewBox="0 0 180 120" role="img" aria-label="Interactive globe" onpointermove={pointer}><ellipse cx="90" cy="60" rx="52" ry="52"/><ellipse cx="90" cy="60" rx="24" ry="52"/><path d="M40 60h100M50 32q40 22 80 0M50 88q40-22 80 0"/><path class="arc animated" d="M58 68Q90 12 125 48"/><circle cx="58" cy="68" r="3"/><circle cx="125" cy="48" r="3"/></svg>
  {:else if mode === 'lens-magnifier'}
    <div class="lens-scene" role="group" aria-label="Magnified telemetry map" onpointermove={pointer}><span>TELEMETRY MAP</span><i class="lens">×2</i></div>
  {:else if mode === 'custom-cursor-cursor-trail'}
    <div class="cursor-area" role="group" aria-label="Cursor trail field" onpointermove={pointer}><b>MOVE POINTER</b>{#each [0, 1, 2, 3] as item (item)}<i class="trail-dot" style:width={`${10 - item * 2}px`} style:height={`${10 - item * 2}px`} style:opacity={1 - item * .2} style:transform={`translate(calc(${x}% - ${item * 8}px), calc(${y}% - ${item * 8}px))`}></i>{/each}</div>
  {:else if mode === 'hover-image-reveal'}
    <div class="hover-list" role="group" aria-label="Image reveal list" onpointermove={pointer}><a href="#relay">Relay Alpha</a><a href="#relay">Relay Bravo</a><i class="hover-image">IMAGE</i></div>
  {:else}
    <button class="animated-icon" type="button" aria-label="Toggle animated icon" onclick={() => alternate = !alternate}><svg viewBox="0 0 48 48" aria-hidden="true"><path class="icon-path animated" d={alternate ? 'M10 24h28M24 10v28' : 'M10 14h28M10 24h28M10 34h28'}/></svg><span>{alternate ? 'ADD' : 'MENU'}</span></button>
  {/if}
</section>

<style>
  .effect { position: relative; display: grid; place-items: center; min-height: 118px; padding: 12px; overflow: hidden; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-text); font: 11px/1.4 var(--br-font-mono); isolation: isolate; }
  .effect[data-visible='false'] .animated, .effect[data-visible='false'] .typewriter::after, .effect[data-visible='false'] .shimmer-text::after { animation-play-state: paused !important; }
  button { border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; padding: 7px 10px; }
  output { font-size: 28px; color: var(--br-signal); }.rolling-digit { display: inline-block; animation: rise .5s both; }
  .typewriter { position: relative; width: 14ch; border-right: 2px solid var(--br-signal); white-space: nowrap; }.typewriter::after { position: absolute; inset: 0; content: ''; background: var(--br-inset); transform-origin: right; animation: type 2.2s steps(14) infinite alternate; }
  .scramble { letter-spacing: .18em; animation: jitter .18s steps(2) infinite; }.gradient-text, .shimmer-text { position: relative; overflow: hidden; color: var(--br-signal); font-size: 18px; font-weight: 700; }.gradient-text { background: linear-gradient(90deg, var(--br-signal), var(--br-warning)); background-clip: text; color: transparent; }.shimmer-text::after { position: absolute; inset: 0; content: ''; background: linear-gradient(100deg, transparent 20%, rgb(255 255 255 / .8), transparent 80%); transform: translateX(-120%); animation: sweep 1.8s infinite; }
  .word-rotate { position: relative; width: 10ch; height: 20px; overflow: hidden; }.word-rotate i { position: absolute; inset: 0; opacity: 0; animation: word 4.5s infinite; animation-delay: calc(var(--index) * 1.5s); font-style: normal; color: var(--br-signal); }.split-text i { display: inline-block; font-style: normal; animation: rise .5s both; animation-delay: calc(var(--index) * 35ms); }.blur-in { animation: blur .8s both; }.morphing-text { font-size: 18px; color: var(--br-signal); animation: morph 1.4s infinite alternate; }
  mark { position: relative; background: transparent; color: inherit; }.effect mark::after { position: absolute; z-index: -1; inset: 45% -3px 0; content: ''; background: color-mix(in srgb, var(--br-warning) 45%, transparent); transform-origin: left; animation: scale-x .8s both; }
  .beam-border { position: relative; padding: 26px; border: 1px solid var(--br-line); background: var(--br-surface); }.beam-border i { position: absolute; inset: -1px; border: 2px solid transparent; border-top-color: var(--br-signal); animation: spin 2s linear infinite; }
  .spotlight, .tilt-card, .parallax, .cursor-area { position: relative; display: grid; place-items: center; width: min(100%, 300px); min-height: 100px; border: 1px solid var(--br-line); background: var(--br-surface); }.spotlight i { position: absolute; width: 120px; height: 120px; border-radius: 50%; background: radial-gradient(circle, color-mix(in srgb, var(--br-signal) 35%, transparent), transparent 70%); transform: translate(calc(var(--x) - 50%), calc(var(--y) - 50%)); pointer-events: none; }.tilt-card { transform: perspective(500px) rotateX(var(--rx, 0deg)) rotateY(var(--ry, 0deg)); transition: transform .12s; }.tilt-card i { position: absolute; inset: 0; background: linear-gradient(120deg, transparent, rgb(255 255 255 / .16), transparent); transform: translateX(calc(var(--x) - 50%)); }.magnetic { transform: translate(var(--mx), var(--my)); transition: transform .12s; }
  .parallax-layer { position: absolute; border-radius: 50%; }.parallax .back { width: 90px; height: 90px; background: var(--br-raised); }.parallax .middle { width: 55px; height: 55px; background: var(--br-signal); }.parallax .front { z-index: 1; }
  .scroll-reveal { animation: blur .8s both; }.progress-track { width: 100%; height: 5px; background: var(--br-line); }.progress-track i { display: block; width: 100%; height: 100%; background: var(--br-signal); transform: scaleX(var(--progress)); transition: transform .1s; transform-origin: left; }.effect[data-module='shared-layout-morph-transitions'] button { display: flex; align-items: center; gap: 10px; width: 180px; }.morph-item { width: 28px; height: 28px; border-radius: 4px; background: var(--br-signal); transition: transform .35s; }.alternate .morph-item { border-radius: 50%; transform: translateX(120px) rotate(180deg); }
  ul { display: grid; gap: 5px; width: min(100%, 240px); margin: 0; padding: 0; list-style: none; }li { padding: 6px; border: 1px solid var(--br-line); background: var(--br-raised); animation: rise .5s both; animation-delay: calc(var(--index) * 90ms); }
  .burst, .particle-field, .ripple, .orbit-system { position: relative; display: grid; place-items: center; width: 170px; height: 100px; }.confetti-piece, .particle { position: absolute; width: 5px; height: 10px; background: hsl(calc(var(--index) * 27deg) 80% 60%); transform: rotate(calc(var(--index) * 27deg)) translateY(-38px); animation: burst 1.6s infinite; animation-delay: calc(var(--index) * -80ms); }.particle { width: 3px; height: 3px; border-radius: 50%; background: white; transform: translate(var(--px), var(--py)); animation: sparkle 1.5s infinite alternate; }.motion-background { position: relative; display: grid; place-items: center; width: 100%; min-height: 100px; background-image: radial-gradient(var(--br-line) 1px, transparent 1px); background-size: 12px 12px; }.motion-background i { position: absolute; width: 180px; height: 80px; border-radius: 50%; background: color-mix(in srgb, var(--br-signal) 30%, transparent); filter: blur(20px); animation: drift 3s infinite alternate; }
  .ring { position: absolute; width: 28px; height: 28px; border: 1px solid var(--br-signal); border-radius: 50%; animation: ripple 2s infinite; animation-delay: calc(var(--index) * .5s); }.effect svg { width: 100%; max-height: 110px; }.effect svg circle, .effect svg ellipse, .effect svg path { fill: none; stroke: var(--br-structure); stroke-width: 2; }.connector { stroke: var(--br-signal) !important; stroke-dasharray: 10 8; animation: dash 1s linear infinite; }.orbit { position: absolute; width: 90px; height: 90px; border: 1px solid var(--br-line); border-radius: 50%; animation: spin 4s linear infinite; animation-delay: calc(var(--index) * -.8s); }.orbit span { position: absolute; left: 50%; top: -8px; display: grid; place-items: center; width: 16px; height: 16px; border-radius: 50%; background: var(--br-signal); color: var(--br-on-signal); }.globe { cursor: grab; }.globe .arc { stroke: var(--br-signal); stroke-dasharray: 6 5; animation: dash 1s linear infinite; }
  .lens-scene { position: relative; display: grid; place-items: center; width: 260px; height: 100px; background: repeating-linear-gradient(45deg, var(--br-surface) 0 10px, var(--br-raised) 10px 20px); }.lens { position: absolute; left: 0; top: 0; display: grid; place-items: center; width: 56px; height: 56px; border: 2px solid var(--br-signal); border-radius: 50%; background: var(--br-raised); transform: translate(var(--x), var(--y)); }.trail-dot { position: absolute; left: 0; top: 0; border-radius: 50%; background: var(--br-signal); pointer-events: none; }.hover-list { position: relative; display: grid; gap: 5px; width: 220px; }.hover-list a { padding: 6px; border-bottom: 1px solid var(--br-line); color: inherit; }.hover-image { position: absolute; left: 0; top: 0; display: none; padding: 20px; background: var(--br-signal); color: var(--br-on-signal); transform: translate(var(--x), var(--y)); pointer-events: none; }.hover-list:hover .hover-image { display: block; }.animated-icon { display: flex; align-items: center; gap: 6px; }.animated-icon svg { width: 28px; }.icon-path { stroke: var(--br-signal) !important; stroke-linecap: round; transition: transform .3s; }
  @keyframes rise { from { opacity: 0; transform: translateY(12px); } } @keyframes type { from { transform: scaleX(1); } to { transform: scaleX(0); } } @keyframes jitter { 50% { transform: translateX(1px); opacity: .7; } } @keyframes sweep { to { transform: translateX(120%); } } @keyframes word { 0%, 100% { opacity: 0; transform: translateY(10px); } 12%, 28% { opacity: 1; transform: translateY(0); } } @keyframes blur { from { opacity: 0; transform: scale(.96); } } @keyframes morph { to { opacity: .45; transform: scale(1.04); } } @keyframes scale-x { from { transform: scaleX(0); } } @keyframes spin { to { transform: rotate(360deg); } } @keyframes burst { 50% { opacity: 1; } to { opacity: 0; transform: rotate(calc(var(--index) * 27deg)) translateY(-72px); } } @keyframes sparkle { to { opacity: .2; transform: translate(var(--px), calc(var(--py) - 4px)) scale(.5); } } @keyframes drift { to { transform: translateX(50px) scale(1.2); } } @keyframes ripple { from { opacity: .8; transform: scale(.5); } to { opacity: 0; transform: scale(3); } } @keyframes dash { to { stroke-dashoffset: -18; } }
  .word-rotate i { opacity: 1; visibility: hidden; }
  .parallax .front { color: var(--br-on-signal); }
  @keyframes rise { from { transform: translateY(12px); } }
  @keyframes jitter { 50% { transform: translateX(1px); } }
  @keyframes word { 0%, 100% { visibility: hidden; transform: translateY(10px); } 12%, 28% { visibility: visible; transform: translateY(0); } }
  @keyframes blur { from { filter: blur(8px); transform: scale(.96); } }
  @keyframes morph { to { transform: scale(1.04); } }
  .sr-only { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
  @media (prefers-reduced-motion: reduce) { .effect .animated, .effect .typewriter::after, .effect .shimmer-text::after { animation: none !important; transition: none !important; } .effect * { scroll-behavior: auto !important; } }
</style>
