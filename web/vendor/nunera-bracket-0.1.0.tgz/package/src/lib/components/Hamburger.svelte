<script lang="ts">
  interface Props { open?: boolean; label?: string; controls?: string; onclick?: () => void }
  let { open=false, label=open?'Close menu':'Open menu', controls, onclick }:Props=$props();
</script>
<button type="button" class="hamburger" aria-label={label} aria-expanded={open} aria-controls={controls} onclick={onclick}><span></span><span></span><span></span></button>
<style>.hamburger{display:grid;gap:4px;padding:var(--br-space-2);border:1px solid var(--br-line);background:var(--br-raised)}span{display:block;width:18px;height:2px;background:var(--br-ink);transition:transform var(--br-motion-fast)}button[aria-expanded='true'] span:first-child{transform:translateY(6px) rotate(45deg)}button[aria-expanded='true'] span:nth-child(2){opacity:0}button[aria-expanded='true'] span:last-child{transform:translateY(-6px) rotate(-45deg)}</style>
