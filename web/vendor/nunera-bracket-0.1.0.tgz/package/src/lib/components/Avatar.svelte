<script lang="ts">
  import type { HTMLAttributes } from 'svelte/elements';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type AvatarPart = 'root' | 'status';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    src?: string;
    alt?: string;
    name?: string;
    size?: number;
    icon?: string;
    status?: 'online' | 'away' | 'busy' | 'offline';
    square?: boolean;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<AvatarPart>;
    styles?: PartOverrides<AvatarPart>;
  }
  let { as = 'span', src, alt = '', name = '', icon = '○', size = 32, status, square = true, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
  const initials = $derived(name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join(''));
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(['br-avatar', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(`--br-avatar-size:${size}px`, styles, 'root')} data-square={square} title={name || undefined}>{#if src}<img {src} {alt}/>{:else if initials}{initials}{:else}<span aria-hidden="true">{icon}</span><span class="br-sr">Avatar</span>{/if}{#if status}<i class={partClass('br-avatar__status', classes, 'status')} style={partStyle(undefined, styles, 'status')} data-status={status}></i><span class="br-sr">{status}</span>{/if}</svelte:element>
<style>.br-avatar__status[data-status='away']{background:var(--br-caution)}.br-avatar__status[data-status='busy']{background:var(--br-danger)}.br-avatar__status[data-status='offline']{background:var(--br-dim)}</style>
