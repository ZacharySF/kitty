<script lang="ts">
  export interface TimeSlotDay { date:string; slots:{time:string;available?:boolean}[] }
  interface Props { days:TimeSlotDay[]; value?:string; onchange?:(value:string)=>void }
  let { days,value=$bindable(''),onchange }:Props=$props();function select(date:string,time:string){value=`${date}T${time}`;onchange?.(value);}
</script>
<div class="booking">{#each days as day (day.date)}<section><h3><time datetime={day.date}>{day.date}</time></h3><div>{#each day.slots as slot (slot.time)}<button type="button" disabled={slot.available===false} aria-pressed={value===`${day.date}T${slot.time}`} onclick={()=>select(day.date,slot.time)}>{slot.time}</button>{/each}</div></section>{/each}</div>
<style>.booking{display:grid;gap:var(--br-space-3)}section{display:grid;gap:var(--br-space-1)}h3{margin:0;color:var(--br-ink);font-size:var(--br-text-sm)}section div{display:flex;flex-wrap:wrap;gap:var(--br-space-1)}button{padding:var(--br-space-2);border:1px solid var(--br-line);background:var(--br-raised);color:var(--br-ink)}button[aria-pressed='true']{background:var(--br-signal);color:var(--br-on-signal)}button:disabled{opacity:.35}</style>
