<script lang="ts">
  import type { HTMLButtonAttributes } from 'svelte/elements';

  interface Props extends Omit<HTMLButtonAttributes, 'onclick' | 'onchange'> {
    label: string;
    icon?: string;
    pressed?: boolean;
    onpressedchange?: (pressed: boolean) => void;
    onclick?: HTMLButtonAttributes['onclick'];
  }

  let {
    label,
    icon,
    pressed = $bindable(false),
    onpressedchange,
    onclick,
    type = 'button',
    ...rest
  }: Props = $props();

  function toggle(event: MouseEvent & { currentTarget: EventTarget & HTMLButtonElement }) {
    onclick?.(event);
    if (event.defaultPrevented) return;
    pressed = !pressed;
    onpressedchange?.(pressed);
  }
</script>

<button {...rest} class="br-btn" data-variant="outline" aria-label={label} aria-pressed={pressed} {type} onclick={toggle}>
  {#if icon}<span aria-hidden="true">{icon}</span>{/if}
  <span>{label}</span>
</button>
