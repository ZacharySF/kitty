<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  interface Props extends HTMLAttributes<HTMLDivElement> { children: Snippet; columns?: number; gap?: string; ref?: HTMLDivElement | null }
  let { children, columns = 3, gap = 'var(--br-gap)', ref = $bindable(null), style = '', ...rest }: Props = $props();
</script>

<div {...rest} bind:this={ref} class="masonry" style={`column-count:${columns};column-gap:${gap};${style}`}>{@render children()}</div>

<style>.masonry :global(> *) { display: inline-block; width: 100%; margin-block-end: var(--br-gap); break-inside: avoid; }</style>
