<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { Snippet } from 'svelte';
  import { createPresence, type PresenceState } from '../headless/presence';

  interface Item { value: string; label: string; content: Snippet; disabled?: boolean }
  interface Props { items: Item[]; value?: string[]; multiple?: boolean; collapsible?: boolean }

  let { items, value = $bindable([]), multiple = false, collapsible = true }: Props = $props();
  let root: HTMLDivElement;

  const EXIT_DURATION = 120; // matches --br-motion-fast
  const presences = new Map<string, ReturnType<typeof createPresence>>();
  let panelState = $state<Record<string, PresenceState>>({});

  function presenceFor(itemValue: string) {
    let presence = presences.get(itemValue);
    if (presence) return presence;
    presence = createPresence(value.includes(itemValue), { exitDuration: EXIT_DURATION });
    presences.set(itemValue, presence);
    panelState[itemValue] = presence.state;
    presence.subscribe(() => {
      panelState[itemValue] = presence!.state;
      if (presence!.state === 'exited') {
        const next = { ...panelState };
        delete next[itemValue];
        panelState = next;
      }
    });
    return presence;
  }

  $effect(() => {
    for (const item of items) presenceFor(item.value).set(value.includes(item.value));
  });

  onDestroy(() => { for (const presence of presences.values()) presence.destroy(); });

  function mountedFor(itemValue: string) {
    const state = panelState[itemValue];
    return state !== undefined && state !== 'exited';
  }

  function toggle(item: Item) {
    if (item.disabled) return;
    const open = value.includes(item.value);
    if (open) {
      if (collapsible || value.length > 1) value = value.filter((v) => v !== item.value);
    } else {
      value = multiple ? [...value, item.value] : [item.value];
    }
  }
  function keydown(event: KeyboardEvent) {
    if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
    const buttons = [...root.querySelectorAll<HTMLButtonElement>('.br-accordion__trigger:not(:disabled)')];
    const current = buttons.indexOf(event.currentTarget as HTMLButtonElement);
    const index = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (current + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
    event.preventDefault();
    buttons[index]?.focus();
  }
</script>

<div class="br-accordion" bind:this={root}>
  {#each items as item (item.value)}
    <section class="br-accordion__item">
      <h3 style:margin="0">
        <button
          class="br-accordion__trigger"
          aria-expanded={value.includes(item.value)}
          disabled={item.disabled}
          onclick={() => toggle(item)}
          onkeydown={keydown}
        >
          <span>{item.label}</span>
          <span class="br-accordion__chevron" data-open={value.includes(item.value)} aria-hidden="true">›</span>
        </button>
      </h3>
      {#if mountedFor(item.value)}
        <div class="br-accordion__content" data-state={panelState[item.value]}>
          {@render item.content()}
        </div>
      {/if}
    </section>
  {/each}
</div>

<style>
  .br-accordion__chevron { transition: transform var(--br-motion-fast); }
  .br-accordion__chevron[data-open='true'] { transform: rotate(90deg); }
  .br-accordion__content[data-state='entered'] { animation: br-accordion-in var(--br-motion-fast) var(--br-ease-entrance); }
  .br-accordion__content[data-state='exiting'] { animation: br-accordion-in var(--br-motion-fast) var(--br-ease-exit) reverse; }
  @keyframes br-accordion-in {
    from { opacity: 0; }
    to { opacity: 1; }
  }
</style>
