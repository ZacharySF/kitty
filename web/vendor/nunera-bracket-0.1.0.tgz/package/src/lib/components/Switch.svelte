<script lang="ts">
  import type { Size } from '../types';
  import { getMessages } from '../headless/messages';
  interface Props { checked?: boolean; label?: string; disabled?: boolean; loading?: boolean; size?: Size; name?: string; onchange?: (checked: boolean) => void | Promise<void> }
  let { checked = $bindable(false), label, disabled = false, loading = false, size = 'md', name, onchange }: Props = $props();
  let pending = $state(false);
  const messages = $derived(getMessages());
  async function toggle() { if (disabled || loading || pending) return; const before = checked; checked = !checked; try { const result = onchange?.(checked); if (result instanceof Promise) { pending = true; await result; } } catch { checked = before; } finally { pending = false; } }
</script>
<button type="button" class="br-switch" role="switch" aria-checked={checked} aria-busy={loading || pending} data-size={size} {disabled} onclick={toggle}><span class="br-switch__track"><i class="br-switch__thumb"></i></span>{#if label}<span>{label}{#if loading || pending} · {messages.syncing}{/if}</span>{/if}</button>{#if name}<input type="hidden" {name} value={checked ? 'true' : 'false'} />{/if}
<style>.br-switch[data-size='xs']{font-size:9px;scale:.85;transform-origin:left center}.br-switch[data-size='sm']{font-size:10px}.br-switch[data-size='lg']{font-size:14px}.br-switch[data-size='lg'] .br-switch__track{width:52px;height:26px}</style>
