<script lang="ts">
  export type CollaborationMode = 'comments-thread' | 'presence-and-live-cursors' | 'reactions' | 'activity-feed' | 'notification-center-inbox' | 'user-profile-card' | 'share-dialog-permissions';
  export interface CollaborationSurfaceProps { mode: CollaborationMode; oninvite?: (email: string, role: string) => void }
  let { mode, oninvite }: CollaborationSurfaceProps = $props();
  let replying = $state(false);
  let editing = $state(false);
  let deleted = $state(false);
  let reaction = $state(false);
  let read = $state(false);
  let email = $state('operator@example.com');
  let role = $state('viewer');
  let copied = $state(false);
</script>

<section class="collaboration-surface" data-module={mode}>
  {#if mode === 'comments-thread'}
    {#if !deleted}<article><header><b>Michael K.</b><time datetime="2026-10-08T14:30:00Z">2m ago</time></header>{#if editing}<textarea aria-label="Edit comment">Verify relay four.</textarea>{:else}<p>Verify relay four.</p>{/if}<footer><button type="button" aria-label="Reply" onclick={() => replying = !replying}>REPLY</button><button type="button" aria-label="Edit comment" onclick={() => editing = !editing}>EDIT</button><button type="button" aria-label="Delete comment" onclick={() => deleted = true}>DELETE</button></footer>{#if replying}<textarea aria-label="Reply text"></textarea>{/if}</article>{/if}
  {:else if mode === 'presence-and-live-cursors'}
    <div class="presence"><span class="avatar" title="Michael K.">MK</span><span class="avatar" title="Alex R.">AR</span><span class="cursor first">MK</span><span class="cursor second">AR</span></div>
  {:else if mode === 'reactions'}
    <button type="button" aria-pressed={reaction} onclick={() => reaction = !reaction}>👍 {reaction ? 4 : 3}</button><button type="button" aria-pressed="false">🎯 2</button>
  {:else if mode === 'activity-feed'}
    {#each [['Michael','deployed','relay firmware'],['Alex','commented on','route plan']] as item, index (item[0])}<article><span class="avatar">{item[0][0]}</span><p><b>{item[0]}</b> {item[1]} <a href="#activity">{item[2]}</a></p><time datetime={`2026-10-08T1${index}:00:00Z`}>{index + 1}h</time></article>{/each}
  {:else if mode === 'notification-center-inbox'}
    <header><b>NOTIFICATIONS</b>{#if !read}<span class="unread-badge">1 unread</span>{/if}</header><article class:read><p>Calibration completed</p><time datetime="2026-10-08T14:30:00Z">Now</time><button type="button" aria-label="Mark as read" onclick={() => read = true}>READ</button></article>
  {:else if mode === 'user-profile-card'}
    <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect width='80' height='80' fill='%23182736'/%3E%3Ctext x='20' y='48' fill='%2338bdf8'%3EMK%3C/text%3E%3C/svg%3E" alt="Michael Kryvonis"/><div><h3>Michael Kryvonis</h3><p class="role">SYSTEM OPERATOR</p></div><div class="actions"><button type="button">MESSAGE</button><button type="button">FOLLOW</button></div>
  {:else}
    <form onsubmit={(event) => { event.preventDefault(); oninvite?.(email, role); }}><label>Email<input type="email" bind:value={email}/></label><label>Role<select bind:value={role}><option value="viewer">Viewer</option><option value="editor">Editor</option></select></label><button type="submit">INVITE</button></form><button type="button" aria-label="Copy link" onclick={() => copied = true}>{copied ? 'COPIED' : 'COPY LINK'}</button>
  {/if}
</section>
<style>
  .collaboration-surface { position: relative; display: flex; flex-wrap: wrap; gap: 7px; min-height: 90px; padding: 8px; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-text); font: 10px/1.4 var(--br-font-mono); }.collaboration-surface > article { flex: 1 1 220px; padding: 7px; border: 1px solid var(--br-line); background: var(--br-raised); }.collaboration-surface header, footer, .actions { display: flex; align-items: center; gap: 6px; justify-content: space-between; }button, input, textarea, select { border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; }button { padding: 4px 7px; }.avatar { display: grid; place-items: center; width: 30px; height: 30px; border: 1px solid var(--br-signal); border-radius: 50%; background: var(--br-raised); color: var(--br-signal); }.presence { position: relative; flex: 1; min-height: 100px; }.cursor { position: absolute; padding: 2px 4px; background: var(--br-signal); color: var(--br-on-signal); clip-path: polygon(0 0, 100% 30%, 45% 45%, 25% 100%); }.cursor.first { left: 40%; top: 25%; }.cursor.second { left: 72%; top: 62%; background: var(--br-warning); }.unread-badge { padding: 2px 5px; background: var(--br-signal); color: var(--br-on-signal); }.read { opacity: .65; }.collaboration-surface > img { width: 64px; height: 64px; border-radius: 50%; }.role { color: var(--br-structure); letter-spacing: .1em; }form { display: flex; flex-wrap: wrap; gap: 6px; }label { display: grid; gap: 2px; }
  .cursor.second { background: var(--br-caution); color: var(--br-on-caution); }
</style>
