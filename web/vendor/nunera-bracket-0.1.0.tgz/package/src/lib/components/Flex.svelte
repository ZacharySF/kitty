<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import type { Align, Justify } from '../types';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    children: Snippet;
    direction?: 'row' | 'row-reverse' | 'column' | 'column-reverse';
    wrap?: 'nowrap' | 'wrap' | 'wrap-reverse';
    align?: Align;
    justify?: Justify;
    grow?: number;
    shrink?: number;
    basis?: string;
    gap?: string;
    ref?: HTMLElement | null;
  }
  let { as = 'div', children, direction = 'row', wrap = 'nowrap', align = 'stretch', justify = 'start', grow, shrink, basis, gap = 'var(--br-gap)', ref = $bindable(null), style = '', ...rest }: Props = $props();
  const alignValue = $derived(align === 'start' ? 'flex-start' : align === 'end' ? 'flex-end' : align);
  const justifyValue = $derived(({ start: 'flex-start', center: 'center', end: 'flex-end', between: 'space-between', around: 'space-around', evenly: 'space-evenly' } as const)[justify]);
  const layoutStyle = $derived(`display:flex;flex-direction:${direction};flex-wrap:${wrap};align-items:${alignValue};justify-content:${justifyValue};${grow === undefined ? '' : `flex-grow:${grow};`}${shrink === undefined ? '' : `flex-shrink:${shrink};`}${basis === undefined ? '' : `flex-basis:${basis};`}gap:${gap};${style}`);
</script>

<svelte:element this={as} {...rest} bind:this={ref} style={layoutStyle}>{@render children()}</svelte:element>
