<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';
  import { responsiveVariables, type ResponsiveValue } from '../responsive';

  export type GridPart = 'root';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    children: Snippet;
    columns?: ResponsiveValue<number>;
    rows?: string;
    min?: string;
    mode?: 'auto-fit' | 'auto-fill';
    gap?: string;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<GridPart>;
    styles?: PartOverrides<GridPart>;
  }
  let { as = 'div', children, columns, rows, min = '240px', mode = 'auto-fit', gap = 'var(--br-gap)', class: className = '', ref = $bindable(null), classes, styles, style = '', ...rest }: Props = $props();
  const columnStyle = $derived(columns
    ? responsiveVariables('grid-columns', columns, (value) => `repeat(${value},minmax(0,1fr))`)
    : `--br-grid-columns-base:repeat(${mode},minmax(min(100%,${min}),1fr))`);
  const baseStyle = $derived(`${columnStyle};display:grid;grid-template-columns:var(--br-grid-columns-base);${rows ? `grid-template-rows:${rows};` : ''}gap:${gap};${style}`);
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(`br-grid-responsive ${className}`.trim(), classes, 'root')} style={partStyle(baseStyle, styles, 'root')}>{@render children()}</svelte:element>

<style>
  @media (min-width: 30rem) { .br-grid-responsive { grid-template-columns: var(--br-grid-columns-sm, var(--br-grid-columns-base)); } }
  @media (min-width: 48rem) { .br-grid-responsive { grid-template-columns: var(--br-grid-columns-md, var(--br-grid-columns-sm, var(--br-grid-columns-base))); } }
  @media (min-width: 64rem) { .br-grid-responsive { grid-template-columns: var(--br-grid-columns-lg, var(--br-grid-columns-md, var(--br-grid-columns-sm, var(--br-grid-columns-base)))); } }
  @media (min-width: 80rem) { .br-grid-responsive { grid-template-columns: var(--br-grid-columns-xl, var(--br-grid-columns-lg, var(--br-grid-columns-md, var(--br-grid-columns-sm, var(--br-grid-columns-base))))); } }
</style>
