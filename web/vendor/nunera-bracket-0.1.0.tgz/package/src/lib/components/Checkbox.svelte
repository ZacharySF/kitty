<script lang="ts">
  import type { Size } from '../types';
  interface Props { checked?: boolean | 'indeterminate'; label?: string; description?: string; disabled?: boolean; size?: Size; name?: string; value?: string; onchange?: (checked: boolean) => void }
  let { checked = $bindable(false), label, description, disabled = false, size = 'md', name, value = 'on', onchange }: Props = $props();
  function toggle() { if (disabled) return; checked = checked === 'indeterminate' ? true : !checked; onchange?.(checked === true); }
</script>
<button type="button" class="br-check" data-state={checked === 'indeterminate' ? 'indeterminate' : checked ? 'checked' : 'unchecked'} data-size={size} role="checkbox" aria-checked={checked === 'indeterminate' ? 'mixed' : checked} {disabled} onclick={toggle}><span class="br-check__box" aria-hidden="true">{#if checked}<i class="br-check__mark"></i>{/if}</span><span>{label}{#if description}<small>{description}</small>{/if}</span></button>
{#if name}<input type="hidden" {name} value={checked === true ? value : ''} />{/if}
<style>.br-check[data-size='xs']{font-size:9px}.br-check[data-size='sm']{font-size:10px}.br-check[data-size='lg']{font-size:14px}.br-check span:last-child{display:grid}.br-check small{color:var(--br-mute)}</style>
