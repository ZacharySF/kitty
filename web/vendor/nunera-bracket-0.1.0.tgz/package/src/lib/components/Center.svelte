<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';

  interface Props extends HTMLAttributes<HTMLElement> { as?: string; children: Snippet; shape?: 'none' | 'square' | 'circle'; size?: string; inline?: boolean; ref?: HTMLElement | null }
  let { as = 'div', children, shape = 'none', size, inline = false, ref = $bindable(null), style = '', ...rest }: Props = $props();
  const layoutStyle = $derived(`display:${inline ? 'inline-grid' : 'grid'};place-items:center;${shape === 'none' || !size ? '' : `width:${size};height:${size};`}${shape === 'circle' ? 'border-radius:50%;' : ''}${style}`);
</script>

<svelte:element this={as} {...rest} bind:this={ref} data-shape={shape} style={layoutStyle}>{@render children()}</svelte:element>
