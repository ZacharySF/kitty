<script lang="ts">
  import type { HTMLTextareaAttributes } from 'svelte/elements';

  interface Props extends Omit<HTMLTextareaAttributes, 'value'> {
    value?: string;
    maxLength?: number;
    autoGrow?: boolean;
    invalid?: boolean;
    resize?: 'none' | 'vertical' | 'horizontal' | 'both';
  }

  let { value = $bindable(''), maxLength, autoGrow = false, invalid = false, resize = 'vertical', rows = 3, oninput, ...rest }: Props = $props();

  function input(event: Event & { currentTarget: EventTarget & HTMLTextAreaElement }) {
    if (autoGrow) {
      event.currentTarget.style.height = 'auto';
      event.currentTarget.style.height = `${event.currentTarget.scrollHeight}px`;
    }
    oninput?.(event);
  }
</script>

<div class="wrap">
  <div class="br-control" data-invalid={invalid}>
    <textarea {...rest} bind:value {rows} maxlength={maxLength} aria-invalid={invalid} style:resize oninput={input}></textarea>
  </div>
  {#if maxLength !== undefined}<span class="count">{value.length}/{maxLength}</span>{/if}
</div>

<style>
  .wrap { display: grid; gap: 3px; }
  .count { justify-self: end; color: var(--br-dim); font-size: 9px; }
</style>
