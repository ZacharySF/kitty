<script lang="ts">
  export interface BulkAction { id: string; label: string; icon?: string; disabled?: boolean; action: () => void }
  interface Props { count: number; actions: BulkAction[]; label?: string }
  let { count, actions, label='selected' }:Props=$props();
</script>
{#if count>0}<div class="bar" role="toolbar" aria-label="Bulk actions"><strong>{count} {label}</strong><span class="actions">{#each actions as action (action.id)}<button type="button" disabled={action.disabled} onclick={action.action}>{#if action.icon}<span aria-hidden="true">{action.icon}</span>{/if}{action.label}</button>{/each}</span></div>{/if}
<style>.bar{display:flex;align-items:center;justify-content:space-between;gap:var(--br-space-3);padding:var(--br-space-2) var(--br-space-3);border:1px solid var(--br-lineHot);background:var(--br-panel);box-shadow:var(--br-shadow-md)}strong{color:var(--br-signal)}.actions{display:flex;gap:var(--br-space-1)}button{display:flex;gap:var(--br-space-1);padding:var(--br-space-2);border:1px solid var(--br-line);background:var(--br-raised);color:var(--br-ink)}button:disabled{opacity:.45}</style>
