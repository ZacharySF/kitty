<script lang="ts">
  import { tick } from 'svelte';

  interface Props {
    value?: string;
    label?: string;
    disabled?: boolean;
    placeholder?: string;
    oncommit?: (value: string) => void;
  }

  let { value = $bindable(''), label = 'value', disabled = false, placeholder = 'Click to edit', oncommit }: Props = $props();
  let editing = $state(false);
  let draft = $state('');
  let input = $state<HTMLInputElement>();

  async function edit() {
    if (disabled) return;
    draft = value;
    editing = true;
    await tick();
    input?.focus();
    input?.select();
  }

  function commit() {
    value = draft;
    editing = false;
    oncommit?.(value);
  }

  function cancel() {
    draft = value;
    editing = false;
  }

  function keydown(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      event.preventDefault();
      commit();
    } else if (event.key === 'Escape') {
      event.preventDefault();
      cancel();
    }
  }
</script>

<div class="editable" data-editing={editing}>
  {#if editing}
    <input bind:this={input} bind:value={draft} aria-label={label} onkeydown={keydown} />
  {:else}
    <button type="button" {disabled} aria-label={`Edit ${label}`} onclick={edit}>{value || placeholder}</button>
  {/if}
</div>

<style>
  .editable { display: inline-grid; min-width: 8ch; }
  button, input { min-height: var(--br-control-h); padding: var(--br-space-2); border: 1px solid transparent; background: transparent; color: var(--br-ink); font: inherit; text-align: start; }
  button:hover:not(:disabled) { border-color: var(--br-line); background: var(--br-structure-wash); }
  input { border-color: var(--br-signal); background: var(--br-inset); outline: 0; }
</style>
