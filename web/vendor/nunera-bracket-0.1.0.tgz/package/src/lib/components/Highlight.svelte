<script lang="ts">
  interface Props { text: string; query: string; caseSensitive?: boolean }
  let { text, query, caseSensitive = false }: Props = $props();
  const segments = $derived.by(() => {
    if (!query) return [{ value: text, match: false }];
    const source = caseSensitive ? text : text.toLocaleLowerCase();
    const needle = caseSensitive ? query : query.toLocaleLowerCase();
    const result: Array<{ value: string; match: boolean }> = [];
    let start = 0;
    for (let index = source.indexOf(needle); index >= 0; index = source.indexOf(needle, start)) {
      if (index > start) result.push({ value: text.slice(start, index), match: false });
      result.push({ value: text.slice(index, index + query.length), match: true });
      start = index + query.length;
    }
    if (start < text.length) result.push({ value: text.slice(start), match: false });
    return result;
  });
</script>
<span>{#each segments as segment, index (index)}{#if segment.match}<mark>{segment.value}</mark>{:else}{segment.value}{/if}{/each}</span>
<style>mark { padding-inline: .1em; background: color-mix(in srgb, var(--br-caution) 38%, transparent); color: var(--br-ink); }</style>
