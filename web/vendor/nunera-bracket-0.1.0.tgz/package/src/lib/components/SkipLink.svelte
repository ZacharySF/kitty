<script lang="ts">interface Props{href?:string;label?:string}let{href='#main-content',label='Skip to content'}:Props=$props();</script>
<a {href}>{label}</a>
<style>a{position:fixed;z-index:var(--br-z-toast);inset-block-start:var(--br-space-2);inset-inline-start:var(--br-space-2);padding:var(--br-space-2) var(--br-space-3);background:var(--br-signal);color:var(--br-on-signal);transform:translateY(-200%)}a:focus{transform:none}</style>
