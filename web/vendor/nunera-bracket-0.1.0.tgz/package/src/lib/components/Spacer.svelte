<script lang="ts">
  import type { HTMLAttributes } from 'svelte/elements';
  interface Props extends HTMLAttributes<HTMLSpanElement> { axis?: 'horizontal' | 'vertical'; size?: string; flexible?: boolean; ref?: HTMLSpanElement | null }
  let { axis = 'horizontal', size, flexible = size === undefined, ref = $bindable(null), style = '', ...rest }: Props = $props();
  const layoutStyle = $derived(flexible ? `flex:1 1 auto;${style}` : axis === 'horizontal' ? `display:block;width:${size};flex:0 0 ${size};${style}` : `display:block;height:${size};flex:0 0 ${size};${style}`);
</script>

<span {...rest} bind:this={ref} aria-hidden="true" data-axis={axis} data-flexible={flexible} style={layoutStyle}></span>
