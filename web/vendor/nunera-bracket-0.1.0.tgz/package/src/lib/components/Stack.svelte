<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import type { Align, Justify, Orientation } from '../types';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';
  import { responsiveVariables, type ResponsiveValue } from '../responsive';

  export type StackPart = 'root';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    children: Snippet;
    direction?: ResponsiveValue<Orientation>;
    gap?: string;
    align?: Align;
    justify?: Justify;
    wrap?: boolean;
    dividers?: boolean;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<StackPart>;
    styles?: PartOverrides<StackPart>;
  }
  let { as = 'div', children, direction = 'vertical', gap = 'var(--br-gap)', align = 'stretch', justify = 'start', wrap = false, dividers = false, class: className = '', ref = $bindable(null), classes, styles, style = '', ...rest }: Props = $props();
  const justifyValue = $derived(({start:'flex-start',center:'center',end:'flex-end',between:'space-between',around:'space-around',evenly:'space-evenly'} as const)[justify]);
  const directionStyle = $derived(responsiveVariables('stack-direction', direction, (value) => value === 'vertical' ? 'column' : 'row'));
  const baseStyle = $derived(`${directionStyle};display:flex;flex-direction:var(--br-stack-direction-base);gap:${gap};align-items:${align === 'start' ? 'flex-start' : align === 'end' ? 'flex-end' : align};justify-content:${justifyValue};flex-wrap:${wrap ? 'wrap' : 'nowrap'};${style}`);
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(`br-stack-responsive ${className}`.trim(), classes, 'root')} data-dividers={dividers} style={partStyle(baseStyle, styles, 'root')}>{@render children()}</svelte:element>

<style>
  .br-stack-responsive[data-dividers='true'] :global(> * + *) { border-block-start: 1px solid var(--br-line); }
  @media (min-width: 30rem) { .br-stack-responsive { flex-direction: var(--br-stack-direction-sm, var(--br-stack-direction-base)); } }
  @media (min-width: 48rem) { .br-stack-responsive { flex-direction: var(--br-stack-direction-md, var(--br-stack-direction-sm, var(--br-stack-direction-base))); } }
  @media (min-width: 64rem) { .br-stack-responsive { flex-direction: var(--br-stack-direction-lg, var(--br-stack-direction-md, var(--br-stack-direction-sm, var(--br-stack-direction-base)))); } }
  @media (min-width: 80rem) { .br-stack-responsive { flex-direction: var(--br-stack-direction-xl, var(--br-stack-direction-lg, var(--br-stack-direction-md, var(--br-stack-direction-sm, var(--br-stack-direction-base))))); } }
</style>
