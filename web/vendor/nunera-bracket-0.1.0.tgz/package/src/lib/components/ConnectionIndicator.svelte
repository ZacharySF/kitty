<script lang="ts">
  import { onMount } from 'svelte';
  interface Props { offlineMessage?: string; onlineMessage?: string; showOnlineFor?: number }
  let { offlineMessage = 'You are offline', onlineMessage = 'Back online', showOnlineFor = 2000 }: Props = $props();
  let status = $state<'hidden' | 'offline' | 'online'>('hidden');
  let timer: ReturnType<typeof setTimeout> | undefined;
  onMount(() => {
    const offline = () => { if (timer) clearTimeout(timer); status = 'offline'; };
    const online = () => { status = 'online'; timer = setTimeout(() => (status = 'hidden'), showOnlineFor); };
    if (!navigator.onLine) offline();
    window.addEventListener('offline', offline); window.addEventListener('online', online);
    return () => { if (timer) clearTimeout(timer); window.removeEventListener('offline', offline); window.removeEventListener('online', online); };
  });
</script>
{#if status !== 'hidden'}<div class="connection" role="status" data-status={status}>{status === 'offline' ? offlineMessage : onlineMessage}</div>{/if}
<style>.connection{padding:var(--br-space-2);border:1px solid var(--br-caution);background:var(--br-inset);color:var(--br-caution);text-align:center}.connection[data-status='online']{border-color:var(--br-go);color:var(--br-go)}</style>
