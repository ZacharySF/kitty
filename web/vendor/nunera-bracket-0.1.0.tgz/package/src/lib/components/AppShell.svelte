<script lang="ts">
  import type { Snippet } from 'svelte';

  interface Props { header: Snippet; navigation: Snippet; children: Snippet; footer?: Snippet; inspector?: Snippet; collapsed?: boolean; navigationOpen?: boolean; onnavigationchange?: (open: boolean) => void; railWidth?: string; inspectorWidth?: string }
  let { header, navigation, children, footer, inspector, collapsed = false, navigationOpen = $bindable(false), onnavigationchange, railWidth = '220px', inspectorWidth = '340px' }: Props = $props();
  const uid = $props.id();
  const navigationId = `${uid}-navigation`;
  function setNavigation(open: boolean) { navigationOpen = open; onnavigationchange?.(open); }
  function keydown(event: KeyboardEvent) { if (event.key === 'Escape' && navigationOpen) setNavigation(false); }
</script>
<svelte:window onkeydown={keydown} />

<div class="shell" data-collapsed={collapsed} data-has-inspector={Boolean(inspector)} data-navigation-open={navigationOpen} style:--rail={railWidth} style:--inspector={inspectorWidth}>
  <header>{@render header()}<button class="nav-toggle" type="button" aria-label="Open navigation" aria-controls={navigationId} aria-expanded={navigationOpen} onclick={() => setNavigation(true)}>☰</button></header>
  <button class="nav-backdrop" type="button" aria-label="Close navigation" tabindex={navigationOpen ? 0 : -1} onclick={() => setNavigation(false)}></button>
  <nav id={navigationId} aria-label="Primary navigation" data-open={navigationOpen}>{@render navigation()}</nav>
  <main id="main" tabindex="-1">{@render children()}</main>
  {#if inspector}<aside>{@render inspector()}</aside>{/if}
  {#if footer}<footer>{@render footer()}</footer>{/if}
</div>

<style>
  .shell { height: 100dvh; display: grid; grid-template-columns: var(--rail) minmax(0, 1fr); grid-template-rows: auto minmax(0, 1fr) auto; grid-template-areas: 'header header' 'nav main' 'footer footer'; background: var(--br-void); }
  .shell[data-has-inspector='true'] { grid-template-columns: var(--rail) minmax(0, 1fr) var(--inspector); grid-template-areas: 'header header header' 'nav main inspector' 'footer footer footer'; }
  .shell > header { grid-area: header; display: flex; align-items: center; border-bottom: 1px solid var(--br-line); }
  .shell > nav { grid-area: nav; min-height: 0; overflow: auto; border-inline-end: 1px solid var(--br-line); }
  .shell > main { grid-area: main; min-width: 0; min-height: 0; overflow: auto; }
  .shell > aside { grid-area: inspector; min-height: 0; overflow: auto; border-inline-start: 1px solid var(--br-line); }
  .shell > footer { grid-area: footer; border-top: 1px solid var(--br-line); }
  .nav-toggle { margin-inline-start: auto; }
  .nav-backdrop { display: none; }
  .shell[data-collapsed='true'] { --rail: 64px; }
  @media (max-width: 1100px) {
    .shell, .shell[data-has-inspector='true'] { grid-template-columns: var(--rail) minmax(0, 1fr); grid-template-rows: auto minmax(0, 1fr) auto auto; grid-template-areas: 'header header' 'nav main' 'nav inspector' 'footer footer'; }
    .shell[data-has-inspector='false'] { grid-template-rows: auto minmax(0, 1fr) auto; grid-template-areas: 'header header' 'nav main' 'footer footer'; }
    .shell > aside { border-top: 1px solid var(--br-line); border-left: 0; }
  }
  @media (max-width: 700px) {
    .shell, .shell[data-has-inspector='true'] { grid-template-columns: 1fr; grid-template-rows: auto minmax(0, 1fr) auto auto; grid-template-areas: 'header' 'main' 'inspector' 'footer'; }
    .shell[data-has-inspector='false'] { grid-template-rows: auto minmax(0, 1fr) auto; grid-template-areas: 'header' 'main' 'footer'; }
    .shell > nav { position: fixed; inset-block: 0; inset-inline-start: 0; z-index: var(--br-z-popover); width: min(var(--rail), 85vw); border-inline-end: 1px solid var(--br-line); background: var(--br-panel); transform: translateX(-105%); transition: transform var(--br-motion-medium) var(--br-ease-standard); }
    .shell > nav[data-open='true'] { transform: translateX(0); }
    .nav-backdrop { position: fixed; inset: 0; z-index: var(--br-z-overlay); display: block; border: 0; background: color-mix(in srgb, var(--br-void) 72%, transparent); opacity: 0; pointer-events: none; transition: opacity var(--br-motion-medium); }
    .shell[data-navigation-open='true'] .nav-backdrop { opacity: 1; pointer-events: auto; }
    .shell > aside { border-block-start: 1px solid var(--br-line); border-inline-start: 0; }
  }
  @media (min-width: 701px) { .nav-toggle, .nav-backdrop { display: none; } }
</style>
