<script lang="ts">import type { HTMLAttributes } from 'svelte/elements'; interface Props extends HTMLAttributes<HTMLElement> { keys: string | string[]; separator?: string } let { keys, separator = '+', ...rest }: Props = $props(); const values = $derived(Array.isArray(keys) ? keys : [keys]);</script>
<span {...rest} class="keys" aria-label={values.join(' plus ')}>{#each values as key, index (key)}{#if index > 0}<span aria-hidden="true">{separator}</span>{/if}<kbd>{key}</kbd>{/each}</span>
<style>.keys { display: inline-flex; align-items: center; gap: .25em; }</style>
