<script lang="ts">
  import MediaSurface, { type MediaSurfaceProps } from './_MediaSurface.svelte';
  let props: Omit<MediaSurfaceProps, 'mode'> = $props();
</script>

<MediaSurface mode="waveform-audio-visualizer" {...props} />
