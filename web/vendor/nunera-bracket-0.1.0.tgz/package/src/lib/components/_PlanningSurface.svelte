<script lang="ts">
  export type PlanningMode = 'event-calendar-scheduler' | 'gantt-chart';
  export interface PlanningSurfaceProps { mode: PlanningMode; oncreate?: (day: string) => void }
  let { mode, oncreate }: PlanningSurfaceProps = $props();
  let view = $state<'month' | 'week' | 'day' | 'agenda'>('week');
  const events = [{ time: '09:00', title: 'Field briefing' }, { time: '11:30', title: 'Calibration' }];
  const tasks = [{ name: 'Source', start: 4, duration: 4 }, { name: 'Calibrate', start: 7, duration: 3 }, { name: 'Verify', start: 9, duration: 5 }];
</script>

<section class="planning-surface" data-module={mode}>
  {#if mode === 'event-calendar-scheduler'}
    <div class="toolbar"><label>View <select aria-label="Calendar view" bind:value={view}><option value="month">Month</option><option value="week">Week</option><option value="day">Day</option><option value="agenda">Agenda</option></select></label><button type="button" aria-label="Create event" onclick={() => oncreate?.('2026-10-08')}>+ EVENT</button></div>
    <div class="scheduler" data-view={view}>{#each events as event (event.time)}<article class="event"><time>{event.time}</time><b>{event.title}</b></article>{/each}</div>
  {:else}
    <div class="timeline" aria-label="Task timeline"><header><span>TASK</span>{#each [6, 7, 8, 9, 10, 11, 12] as day (day)}<time datetime={`2026-10-${day}`}>{day}</time>{/each}</header>{#each tasks as task (task.name)}<div class="task"><b>{task.name}</b><i class="duration" style={`--start:${task.start};--duration:${task.duration}`} title={`${task.duration} days`}></i></div>{/each}</div>
  {/if}
</section>
<style>
  .planning-surface { display: grid; gap: 6px; min-height: 120px; padding: 7px; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-text); font: 10px/1.4 var(--br-font-mono); }.toolbar { display: flex; justify-content: space-between; gap: 6px; }button, select { border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; }.scheduler { display: grid; grid-template-columns: repeat(2, 1fr); gap: 5px; }.event { display: grid; padding: 8px; border-left: 3px solid var(--br-signal); background: var(--br-raised); }.event time { color: var(--br-mute); }.timeline { display: grid; min-width: 310px; }.timeline header, .task { display: grid; grid-template-columns: 80px repeat(7, 1fr); min-height: 26px; border-bottom: 1px solid var(--br-line); align-items: center; }.timeline header time { text-align: center; color: var(--br-mute); }.duration { grid-column: calc(var(--start) - 4) / span var(--duration); height: 10px; background: var(--br-signal); }
</style>
