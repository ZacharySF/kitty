<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type CardPart = 'root' | 'media' | 'header' | 'body' | 'footer';

  interface Props extends Omit<HTMLAttributes<HTMLElement>, 'onclick'> {
    as?: string;
    title?: string;
    description?: string;
    children: Snippet;
    media?: Snippet;
    header?: Snippet;
    footer?: Snippet;
    variant?: 'elevated' | 'outlined' | 'filled';
    href?: string;
    interactive?: boolean;
    selected?: boolean;
    onclick?: () => void;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<CardPart>;
    styles?: PartOverrides<CardPart>;
  }
  let { as = 'article', title, description, children, media, header, footer, variant = 'outlined', href, interactive = false, selected = false, onclick, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
</script>

{#snippet content()}
  {#if media}<div class={partClass('br-card__media', classes, 'media')} style={partStyle(undefined, styles, 'media')}>{@render media()}</div>{/if}
  {#if header || title}<header class={partClass('br-card__header', classes, 'header')} style={partStyle(undefined, styles, 'header')}>{#if header}{@render header()}{:else}<h3 class="br-card__title">{title}</h3>{/if}</header>{/if}
  {#if description}<div class="br-card__description">{description}</div>{/if}
  <div class={partClass('', classes, 'body')} style={partStyle('display:contents', styles, 'body')}>{@render children()}</div>
  {#if footer}<footer class={partClass('br-card__footer', classes, 'footer')} style={partStyle(undefined, styles, 'footer')}>{@render footer()}</footer>{/if}
{/snippet}

{#if href}
  <a {...rest} bind:this={ref} class={partClass(['br-card', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} data-variant={variant} data-selected={selected} {href}>{@render content()}</a>
{:else if interactive}
  <button type="button" {...rest} bind:this={ref} class={partClass(['br-card', 'interactive', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} data-variant={variant} data-interactive="true" data-selected={selected} aria-pressed={selected} {onclick}>{@render content()}</button>
{:else}
  <svelte:element this={as} {...rest} bind:this={ref} class={partClass(['br-card', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} data-variant={variant} data-selected={selected}>{@render content()}</svelte:element>
{/if}

<style>
  .interactive { width: 100%; color: inherit; font: inherit; text-align: left; }
  .br-card[data-variant='elevated'] { border-color: transparent; box-shadow: var(--br-shadow-md); }
  .br-card[data-variant='filled'] { background: var(--br-raised); }
  .br-card__media { overflow: hidden; }
  a.br-card { display: block; color: inherit; text-decoration: none; }
</style>
