<script lang="ts">
  export type CommerceMode = 'product-card' | 'price-display' | 'quantity-selector' | 'variant-selector-swatches' | 'cart-mini-cart' | 'checkout-payment-form' | 'pricing-table' | 'coupon-promo-code' | 'reviews';
  export interface CommerceSurfaceProps { mode: CommerceMode; value?: number; min?: number; max?: number; currency?: string; locale?: string; onchange?: (value: number) => void; onadd?: () => void }
  let { mode, value = $bindable(1), min = 1, max = 10, currency = 'USD', locale = 'en-US', onchange, onadd }: CommerceSurfaceProps = $props();
  let color = $state('blue');
  let size = $state('M');
  let coupon = $state('');
  let couponState = $state<'idle' | 'success' | 'error'>('idle');
  const image = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="320" height="180"%3E%3Crect width="320" height="180" fill="%23121e29"/%3E%3Cpath d="M80 130h160l-25-80H105z" fill="%2338bdf8"/%3E%3C/svg%3E';
  const money = (amount: number) => new Intl.NumberFormat(locale, { style: 'currency', currency }).format(amount);
  function setQuantity(next: number) { value = Math.min(max, Math.max(min, next)); onchange?.(value); }
  function applyCoupon() { couponState = coupon.trim().toUpperCase() === 'BRACKET10' ? 'success' : 'error'; }
</script>

<section class="commerce-surface" data-module={mode}>
  {#if mode === 'product-card'}
    <img src={image} alt="Telemetry pack"/><div><h3>Telemetry pack</h3><span class="rating" aria-label="4.8 out of 5 stars">★★★★★ 4.8</span><strong class="price">{money(129)}</strong></div><button type="button" aria-label="Add to cart" onclick={onadd}>ADD TO CART</button>
  {:else if mode === 'price-display'}
    <div class="price"><span class="sale">{money(79)}</span><del>{money(99)}</del></div>
  {:else if mode === 'quantity-selector'}
    <div class="quantity"><button type="button" aria-label="Decrease quantity" disabled={value <= min} onclick={() => setQuantity(value - 1)}>−</button><output aria-label="Quantity">{value}</output><button type="button" aria-label="Increase quantity" disabled={value >= max} onclick={() => setQuantity(value + 1)}>+</button></div>
  {:else if mode === 'variant-selector-swatches'}
    <fieldset><legend>Color</legend>{#each ['blue', 'orange', 'green'] as option (option)}<button class:selected={color === option} type="button" aria-label={`Color ${option}`} aria-pressed={color === option} style={`--swatch:${option}`} onclick={() => color = option}></button>{/each}</fieldset><fieldset><legend>Size</legend>{#each ['S', 'M', 'L'] as option (option)}<button class:selected={size === option} type="button" aria-label={`Size ${option}`} aria-pressed={size === option} disabled={option === 'L'} onclick={() => size = option}>{option}</button>{/each}</fieldset>
  {:else if mode === 'cart-mini-cart'}
    <article class="line-item"><img src={image} alt="Telemetry pack"/><div><b>Telemetry pack</b><span>{money(129)}</span></div><input type="number" aria-label="Item quantity" min="1" value="1"/></article><footer><span class="subtotal">Subtotal <b>{money(129)}</b></span><button type="button" aria-label="Checkout">CHECKOUT</button></footer>
  {:else if mode === 'checkout-payment-form'}
    <form><fieldset><legend>Shipping address</legend><input aria-label="Name" autocomplete="name" placeholder="Name"/><input aria-label="Street address" autocomplete="street-address" placeholder="Street"/><input aria-label="Postal code" autocomplete="postal-code" placeholder="Postal code"/></fieldset><fieldset><legend>Payment</legend><input aria-label="Card number" autocomplete="cc-number" inputmode="numeric" placeholder="Card number"/><input aria-label="Expiration" autocomplete="cc-exp" placeholder="MM/YY"/><input aria-label="Security code" autocomplete="cc-csc" inputmode="numeric" placeholder="CVC"/></fieldset><aside class="summary">Order total <b>{money(129)}</b></aside><button type="submit">PLACE ORDER</button></form>
  {:else if mode === 'pricing-table'}
    {#each [{name:'Scout',price:0,features:['1 project','Community']},{name:'Operator',price:19,features:['Unlimited projects','Exports'],highlighted:true},{name:'Fleet',price:49,features:['Teams','Priority support']}] as plan (plan.name)}<article class:highlighted={plan.highlighted} class="plan"><h3>{plan.name}</h3><strong>{money(plan.price)}</strong><ul class="features">{#each plan.features as feature (feature)}<li>{feature}</li>{/each}</ul><button type="button">CHOOSE {plan.name.toUpperCase()}</button></article>{/each}
  {:else if mode === 'coupon-promo-code'}
    <form onsubmit={(event) => { event.preventDefault(); applyCoupon(); }}><input aria-label="Coupon code" bind:value={coupon} placeholder="BRACKET10"/><button type="submit" aria-label="Apply coupon">APPLY</button></form><p role="status" class:success={couponState === 'success'} class:error={couponState === 'error'}>{couponState === 'success' ? 'Coupon applied' : couponState === 'error' ? 'Invalid coupon' : 'Enter a promo code'}</p>
  {:else}
    <header class="summary"><strong>4.7</strong><span aria-label="4.7 out of 5 stars">★★★★★</span><small>128 reviews</small></header>{#each [{author:'Michael',text:'Fast and precise.'},{author:'Alex',text:'Clear telemetry display.'}] as review (review.author)}<article><b>{review.author}</b><span aria-label="5 out of 5 stars">★★★★★</span><p>{review.text}</p></article>{/each}
  {/if}
</section>
<style>
  .commerce-surface { display: flex; flex-wrap: wrap; gap: 7px; min-height: 85px; padding: 8px; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-text); font: 10px/1.4 var(--br-font-mono); }.commerce-surface > img { width: 120px; object-fit: cover; }.commerce-surface > div { display: grid; align-content: center; gap: 4px; flex: 1; }h3, p { margin: 0; }.price, .rating { color: var(--br-signal); }.sale { font-size: 18px; }button, input { border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; padding: 5px 8px; }button:disabled { opacity: .45; }.quantity { display: grid !important; grid-template-columns: auto 42px auto; flex: 0 !important; }.quantity output { display: grid; place-items: center; border-block: 1px solid var(--br-line); }fieldset { display: flex; flex-wrap: wrap; gap: 5px; border: 1px solid var(--br-line); }fieldset button[aria-label^='Color'] { width: 25px; height: 25px; border-radius: 50%; background: var(--swatch); }.selected { outline: 2px solid var(--br-signal); }.line-item { display: grid; grid-template-columns: 60px 1fr 50px; gap: 7px; flex-basis: 100%; }.line-item img { width: 60px; }.line-item div { display: grid; }.line-item input { width: 48px; }.commerce-surface > footer { display: flex; justify-content: space-between; align-items: center; flex-basis: 100%; }.commerce-surface > form { display: flex; flex-wrap: wrap; gap: 6px; flex-basis: 100%; }.commerce-surface > form fieldset { flex: 1 1 180px; display: grid; }.commerce-surface > form .summary { flex-basis: 100%; padding: 7px; background: var(--br-raised); }.plan { flex: 1 1 120px; padding: 8px; border: 1px solid var(--br-line); }.plan.highlighted { border-color: var(--br-signal); box-shadow: inset 0 3px var(--br-signal); }.features { padding-left: 16px; }.success { color: var(--br-success); }.error { color: var(--br-danger); }header.summary { display: grid; flex: 0 0 90px; }.summary strong { font-size: 18px; }.commerce-surface[data-module='reviews'] article { flex: 1 1 160px; padding: 7px; border-left: 2px solid var(--br-line); }
</style>
