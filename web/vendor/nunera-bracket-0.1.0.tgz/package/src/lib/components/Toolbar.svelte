<script lang="ts">
  export interface ToolbarItem { id: string; label: string; disabled?: boolean; toggle?: boolean }
  interface Props { groups: ToolbarItem[][]; label?: string; onselect?: (id: string, pressed: boolean) => void }
  let { groups, label = 'Toolbar', onselect }: Props = $props();
  let root: HTMLDivElement;
  let pressed = $state<string[]>([]);
  function activate(item: ToolbarItem) { const next = Boolean(item.toggle && !pressed.includes(item.id)); if (item.toggle) pressed = next ? [...pressed, item.id] : pressed.filter((id) => id !== item.id); onselect?.(item.id, next); }
  function keydown(event: KeyboardEvent) { if (!['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp', 'Home', 'End'].includes(event.key)) return; const buttons=[...root.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')]; if(!buttons.length)return; event.preventDefault(); const current=buttons.indexOf(document.activeElement as HTMLButtonElement); const next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(current+(['ArrowRight','ArrowDown'].includes(event.key)?1:-1)+buttons.length)%buttons.length; buttons[next].focus(); }
</script>
<div class="toolbar" bind:this={root} role="toolbar" aria-label={label} tabindex="-1" onkeydown={keydown}>{#each groups as group, groupIndex (groupIndex)}{#if groupIndex > 0}<span role="separator" aria-orientation="vertical"></span>{/if}<div role="group">{#each group as item (item.id)}<button type="button" aria-label={item.label} aria-pressed={item.toggle ? pressed.includes(item.id) : undefined} disabled={item.disabled} onclick={() => activate(item)}>{item.label}</button>{/each}</div>{/each}</div>
<style>.toolbar { display: inline-flex; align-items: center; gap: 4px; padding: 3px; border: 1px solid var(--br-line); } [role='group'] { display: inline-flex; gap: 2px; } [role='separator'] { align-self: stretch; border-inline-start: 1px solid var(--br-line); } button { min-height: 28px; padding-inline: 7px; border: 1px solid transparent; background: transparent; color: var(--br-ink); } button[aria-pressed='true'] { border-color: var(--br-signal); color: var(--br-signal); }</style>
