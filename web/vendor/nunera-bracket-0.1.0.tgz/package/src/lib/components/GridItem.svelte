<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  interface Props extends HTMLAttributes<HTMLElement> { as?: string; children: Snippet; columnSpan?: number; columnStart?: number; rowSpan?: number; rowStart?: number; ref?: HTMLElement | null }
  let { as = 'div', children, columnSpan = 1, columnStart, rowSpan = 1, rowStart, ref = $bindable(null), style = '', ...rest }: Props = $props();
  const layoutStyle = $derived(`grid-column:${columnStart ? `${columnStart} / ` : ''}span ${columnSpan};grid-row:${rowStart ? `${rowStart} / ` : ''}span ${rowSpan};${style}`);
</script>

<svelte:element this={as} {...rest} bind:this={ref} style={layoutStyle}>{@render children()}</svelte:element>
