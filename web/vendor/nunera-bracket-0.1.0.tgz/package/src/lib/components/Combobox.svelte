<script lang="ts">
  import type { Option } from '../types';
  import { getMessages } from '../headless/messages';

  interface Props { value?: string; options: Option<string>[]; label?: string; placeholder?: string; freeText?: boolean; clearable?: boolean; disabled?: boolean; emptyText?: string; onchange?: (value: string) => void }
  let { value = $bindable(''), options, label = 'Combobox', placeholder = '', freeText = false, clearable = false, disabled = false, emptyText = 'No results', onchange }: Props = $props();
  let query = $state('');
  let open = $state(false);
  let active = $state(0);
  const messages = $derived(getMessages());
  const filtered = $derived(options.filter((option) => option.label.toLowerCase().includes(query.toLowerCase())));

  function choose(option: Option<string>) { if (option.disabled) return; value = option.value; query = option.label; open = false; onchange?.(value); }
  function input(event: Event & { currentTarget: EventTarget & HTMLInputElement }) { query = event.currentTarget.value; open = true; active = 0; if (freeText) { value = query; onchange?.(value); } }
  function keydown(event: KeyboardEvent) {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); open = true; if (filtered.length) active = (active + (event.key === 'ArrowDown' ? 1 : -1) + filtered.length) % filtered.length; }
    else if (event.key === 'Enter') { event.preventDefault(); const option = filtered[active]; if (option) choose(option); else if (freeText) { value = query; onchange?.(value); open = false; } }
    else if (event.key === 'Escape') open = false;
  }
  function clear() { value = ''; query = ''; open = false; onchange?.(''); }
</script>

<div class="combobox">
  <input role="combobox" aria-label={label} aria-expanded={open} aria-controls="combobox-options" aria-autocomplete="list" {placeholder} {disabled} value={query} oninput={input} onfocus={() => (open = true)} onkeydown={keydown} />
  {#if clearable && query}<button type="button" aria-label={messages.clearInput} onclick={clear}>×</button>{/if}
  {#if open}
    <div id="combobox-options" role="listbox" aria-label={`${label} options`}>
      {#if filtered.length}
        {#each filtered as option, index (option.value)}<button type="button" role="option" aria-selected={value === option.value} aria-disabled={option.disabled} data-active={active === index} onclick={() => choose(option)}>{option.label}</button>{/each}
      {:else}<span>{emptyText}</span>{/if}
    </div>
  {/if}
</div>

<style>.combobox{position:relative}.combobox>input{width:100%;min-height:var(--br-control-h);border:1px solid var(--br-line);background:var(--br-inset);color:var(--br-ink)}.combobox>button{position:absolute;inset-inline-end:4px;top:3px;border:0;background:transparent;color:var(--br-mute)}[role='listbox']{position:absolute;z-index:var(--br-z-popover);width:100%;display:grid;border:1px solid var(--br-line);background:var(--br-panel)}[role='option']{padding:6px;border:0;background:transparent;color:var(--br-ink);text-align:start}[role='option'][data-active='true']{background:var(--br-structure-wash)}[role='option'][aria-disabled='true']{opacity:.4}[role='listbox']>span{padding:8px;color:var(--br-mute)}</style>
