<script lang="ts">interface Props { open?: boolean; label?: string; opacity?: number; onclick?: () => void } let { open = false, label = 'Close overlay', opacity = .7, onclick }: Props = $props();</script>
{#if open}<button type="button" class="backdrop" aria-label={label} style:--opacity={opacity} onclick={() => onclick?.()}></button>{/if}
<style>.backdrop{position:fixed;inset:0;z-index:var(--br-z-overlay);width:100%;height:100%;padding:0;border:0;background:rgb(0 0 0 / var(--opacity));cursor:default}</style>
