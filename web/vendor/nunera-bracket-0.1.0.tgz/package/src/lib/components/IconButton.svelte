<script lang="ts">
  import type { HTMLButtonAttributes } from 'svelte/elements';
  import type { Intent, Size, Variant } from '../types';
  interface Props extends HTMLButtonAttributes { label: string; icon: string; pressed?: boolean; badge?: string | number; size?: Size; variant?: Variant; intent?: Intent; shape?: 'square' | 'circle'; ref?: HTMLButtonElement | null }
  let { label, icon, pressed, badge, size = 'md', variant = 'outline', intent = 'neutral', shape = 'square', ref = $bindable(null), type = 'button', ...rest }: Props = $props();
</script>
<button {...rest} bind:this={ref} class="br-icon-btn" aria-label={label} aria-pressed={pressed} data-size={size} data-variant={variant} data-intent={intent} data-shape={shape} {type}>
  <span class="glyph" aria-hidden="true">{icon}</span>
  {#if badge !== undefined}<span class="badge">{badge}</span>{/if}
</button>
<style>
  .br-icon-btn { position: relative; display: grid; width: var(--br-control-h); height: var(--br-control-h); place-items: center; }
  .glyph { color: currentColor; font-family: var(--br-font-icon); font-size: 1.15em; font-style: normal; font-weight: 400; font-variant-ligatures: none; line-height: 1; }
  .br-icon-btn[data-size='xs'] { width: 22px; height: 22px; } .br-icon-btn[data-size='sm'] { width: 26px; height: 26px; } .br-icon-btn[data-size='lg'] { width: 38px; height: 38px; }
  .br-icon-btn[data-shape='circle'] { border-radius: 50%; }
  .br-icon-btn[data-variant='soft'] { background: color-mix(in srgb, var(--br-signal) 12%, transparent); } .br-icon-btn[data-variant='ghost'] { border-color: transparent; } .br-icon-btn[data-variant='solid'] { background: var(--br-signal); color: var(--br-on-signal); }
  .br-icon-btn[data-intent='danger'] { color: var(--br-danger); }
  .badge { position: absolute; inset-inline-end: -5px; inset-block-start: -5px; display: grid; place-items: center; min-width: 15px; height: 15px; padding: 0 3px; border: 1px solid var(--br-panel); background: var(--br-danger); color: var(--br-on-danger); font-family: var(--br-font-ui); font-size: 8px; }
</style>
