<script lang="ts">
  import type { Snippet } from 'svelte';
  import Show from './Show.svelte';

  interface Props {
    children: Snippet;
    /** Media query; parentheses are added when omitted. Takes precedence over `above`/`below`. */
    query?: string;
    /** Hide at or above this width, e.g. `48rem`. */
    above?: string;
    /** Hide below this width, e.g. `48rem`. */
    below?: string;
    /** Value used during SSR and before the first client match. */
    ssr?: boolean;
    fallback?: Snippet;
  }

  let { children, query, above, below, ssr = true, fallback }: Props = $props();

  const inverted = $derived(
    query
      ? `not ${query.trim().startsWith('(') ? query.trim() : `(${query.trim()})`}`
      : [above && `(max-width: calc(${above} - 0.02px))`, below && `(min-width: ${below})`].filter(Boolean).join(' and ')
  );
</script>

<Show query={inverted} {ssr} {children} {fallback} />
