<script lang="ts">
  export interface CascaderOption { value: string; label: string; disabled?: boolean; children?: CascaderOption[] }
  interface Props { value?: string[]; options: CascaderOption[]; label?: string; placeholder?: string; disabled?: boolean; onchange?: (path: string[]) => void }
  let { value = $bindable([]), options, label = 'Cascader', placeholder = 'Select', disabled = false, onchange }: Props = $props();
  const levels = $derived.by(() => {
    const result: CascaderOption[][] = [options];
    let current = options;
    for (const selected of value) {
      const match = current.find((option) => option.value === selected);
      if (!match?.children?.length) break;
      current = match.children;
      result.push(current);
    }
    return result;
  });
  const labels = $derived.by(() => {
    const result: string[] = [];
    let current = options;
    for (const selected of value) {
      const match = current.find((option) => option.value === selected);
      if (!match) break;
      result.push(match.label);
      current = match.children ?? [];
    }
    return result;
  });
  function change(depth: number, event: Event & { currentTarget: EventTarget & HTMLSelectElement }) { value = [...value.slice(0, depth), event.currentTarget.value]; onchange?.(value); }
</script>

<div class="cascader" role="group" aria-label={label}>
  <div class="levels">{#each levels as items, depth (depth)}<select aria-label={`${label} level ${depth + 1}`} value={value[depth] ?? ''} {disabled} onchange={(event) => change(depth, event)}><option value="" disabled>{placeholder}</option>{#each items as item (item.value)}<option value={item.value} disabled={item.disabled}>{item.label}</option>{/each}</select>{/each}</div>
  {#if labels.length}<output>{labels.join(' / ')}</output>{/if}
</div>
<style>.cascader{display:grid;gap:var(--br-space-2)}.levels{display:flex}.levels select{min-height:var(--br-control-h);border:1px solid var(--br-line);background:var(--br-inset);color:var(--br-ink)}.levels select+select{margin-inline-start:-1px}output{color:var(--br-mute);font-size:10px}</style>
