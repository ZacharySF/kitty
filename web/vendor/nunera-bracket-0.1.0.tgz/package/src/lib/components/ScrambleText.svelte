<script lang="ts">
  import EffectSurface, { type EffectSurfaceProps } from './_EffectSurface.svelte';
  let props: Omit<EffectSurfaceProps, 'mode'> = $props();
</script>

<EffectSurface mode="scramble-decrypt-text" {...props} />
