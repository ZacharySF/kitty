<script lang="ts">
  import Button from './Button.svelte';
  import type { Intent, Size, Variant } from '../types';
  export interface ButtonGroupItem { id: string; label: string; disabled?: boolean; intent?: Intent }
  interface Props { items: ButtonGroupItem[]; orientation?: 'horizontal' | 'vertical'; size?: Size; variant?: Variant; intent?: Intent; label?: string; onselect?: (id: string) => void }
  let { items, orientation = 'horizontal', size = 'md', variant = 'outline', intent = 'neutral', label = 'Button group', onselect }: Props = $props();
</script>
<div class="group" role="group" aria-label={label} data-orientation={orientation}>{#each items as item (item.id)}<Button {size} {variant} intent={item.intent ?? intent} disabled={item.disabled} onclick={() => onselect?.(item.id)}>{item.label}</Button>{/each}</div>
<style>.group { display: inline-flex; } .group[data-orientation='vertical'] { flex-direction: column; } .group :global(.br-btn + .br-btn) { margin-inline-start: -1px; } .group[data-orientation='vertical'] :global(.br-btn + .br-btn) { margin-block-start: -1px; margin-inline-start: 0; }</style>
