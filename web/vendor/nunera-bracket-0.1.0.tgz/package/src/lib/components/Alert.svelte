<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import type { Intent } from '../types';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type AlertPart = 'root' | 'icon' | 'title' | 'body';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    title: string;
    description?: string;
    intent?: Intent | 'info' | 'error';
    icon?: string;
    dismissible?: boolean;
    actions?: Snippet;
    ondismiss?: () => void;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<AlertPart>;
    styles?: PartOverrides<AlertPart>;
  }
  let { as = 'div', title, description, intent = 'primary', icon, dismissible = false, actions, ondismiss, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
  let visible = $state(true);
</script>
{#if visible}
  <svelte:element this={as} {...rest} bind:this={ref} class={partClass(['br-alert', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} data-intent={intent} role={intent === 'danger' || intent === 'error' ? 'alert' : 'status'}>
    {#if icon}<i class={partClass('', classes, 'icon')} style={partStyle(undefined, styles, 'icon')} aria-hidden="true">{icon}</i>{/if}
    <div class={partClass('', classes, 'body')} style={partStyle(undefined, styles, 'body')}>
      <strong class={partClass('br-alert__title', classes, 'title')} style={partStyle(undefined, styles, 'title')}>{title}</strong>
      {#if description}<span>{description}</span>{/if}
      {#if actions}<div>{@render actions()}</div>{/if}
    </div>
    {#if dismissible}<button class="br-alert__close" aria-label="Dismiss" onclick={() => { visible = false; ondismiss?.(); }}>×</button>{/if}
  </svelte:element>
{/if}
<style>.br-alert[data-intent='info']{border-color:var(--br-signal)}.br-alert[data-intent='error']{border-color:var(--br-danger);color:var(--br-danger)}</style>
