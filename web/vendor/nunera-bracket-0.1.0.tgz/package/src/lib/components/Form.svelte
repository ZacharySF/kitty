<script lang="ts">
  import type { Snippet } from 'svelte';

  interface Props {
    children: Snippet;
    label?: string;
    class?: string;
    onsubmit?: (data: FormData, event: SubmitEvent) => void | Promise<void>;
    onreset?: (event: Event) => void;
  }

  let { children, label = 'Form', class: className = '', onsubmit, onreset }: Props = $props();
  let submitting = $state(false);
  let errors = $state<Record<string, string>>({});

  function invalid(event: Event) {
    const control = event.target as HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
    const key = control.id || control.name || String(Object.keys(errors).length);
    const labelText = control.labels?.[0]?.textContent?.replace('*', '').trim();
    const name = labelText || control.name || 'Field';
    errors = { ...errors, [key]: `${name}: ${control.validationMessage}` };
  }

  function input(event: Event) {
    const control = event.target as HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
    if (!control.validity?.valid) return;
    const key = control.id || control.name;
    if (!key || !(key in errors)) return;
    const { [key]: removed, ...remaining } = errors;
    void removed;
    errors = remaining;
  }
  function validation(node: HTMLFormElement) {
    node.addEventListener('invalid', invalid, true);
    node.addEventListener('input', input);
    return {
      destroy() {
        node.removeEventListener('invalid', invalid, true);
        node.removeEventListener('input', input);
      }
    };
  }

  async function submit(event: SubmitEvent) {
    event.preventDefault();
    errors = {};
    submitting = true;
    try {
      await onsubmit?.(new FormData(event.currentTarget as HTMLFormElement), event);
    } finally {
      submitting = false;
    }
  }

  function reset(event: Event) {
    errors = {};
    onreset?.(event);
  }
</script>

<form class={['br-form', className]} aria-label={label} aria-busy={submitting} use:validation onsubmit={submit} onreset={reset}>
  {#if Object.keys(errors).length}
    <div class="br-form__errors" role="alert">
      <ul>{#each Object.values(errors) as error (error)}<li>{error}</li>{/each}</ul>
    </div>
  {/if}
  <fieldset class="br-form__fields" aria-label="Form fields" disabled={submitting}>
    {@render children()}
  </fieldset>
</form>

<style>
  .br-form { display: grid; gap: var(--br-space-3); }
  .br-form__fields { display: grid; gap: var(--br-space-3); min-width: 0; margin: 0; padding: 0; border: 0; }
  .br-form__errors { padding: var(--br-space-2) var(--br-space-3); border: 1px solid var(--br-danger); color: var(--br-danger); }
  .br-form__errors ul { margin: 0; padding-inline-start: 1.25rem; }
</style>
