<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { Snippet } from 'svelte';
  import { createPresence } from '../headless/presence';

  interface Props { open?: boolean; title: string; children: Snippet; footer?: Snippet; side?: 'left' | 'right' | 'top' | 'bottom'; modal?: boolean; size?: string; onclose?: () => void }

  let { open = $bindable(false), title, children, footer, side = 'right', modal = true, size = 'min(420px,92vw)', onclose }: Props = $props();
  let drawer = $state<HTMLElement>();
  let layer = $state<HTMLElement>();
  let trigger: HTMLElement | null = null;
  let inerted: HTMLElement[] = [];
  let previousOverflow = '';

  const EXIT_DURATION = 220; // matches --br-motion-medium
  const presence = createPresence(open, { exitDuration: EXIT_DURATION });
  let mounted = $state(presence.mounted);
  let dataState = $state(presence.state);

  $effect(() => presence.subscribe(() => {
    mounted = presence.mounted;
    dataState = presence.state;
  }));
  $effect(() => { presence.set(open); });
  onDestroy(() => presence.destroy());

  function restorePage() {
    if (typeof document === 'undefined') return;
    document.body.style.overflow = previousOverflow;
    for (const element of inerted) element.inert = false;
    inerted = [];
  }

  function close() {
    open = false;
    restorePage();
    onclose?.();
    queueMicrotask(() => trigger?.focus());
  }

  function keydown(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      event.preventDefault();
      close();
      return;
    }
    if (event.key !== 'Tab' || !drawer) return;
    const focusable = [...drawer.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex]:not([tabindex="-1"])')];
    if (!focusable.length) {
      event.preventDefault();
      drawer.focus();
      return;
    }
    const first = focusable[0];
    const last = focusable.at(-1)!;
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  $effect(() => {
    if (!open || !drawer || !layer) return;
    trigger = document.activeElement as HTMLElement;
    if (modal) {
      previousOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      inerted = [...(layer.parentElement?.children ?? [])]
        .filter((element): element is HTMLElement => element instanceof HTMLElement && element !== layer);
      for (const element of inerted) element.inert = true;
    }
    queueMicrotask(() => {
      const initial = drawer?.querySelector<HTMLElement>('button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href]');
      (initial ?? drawer)?.focus();
    });
  });

  onDestroy(restorePage);
</script>

{#if mounted}
  <div bind:this={layer} class="layer" data-modal={modal} data-state={dataState}>
    <button class="backdrop" aria-label="Close drawer" onclick={close}></button>
    <div bind:this={drawer} class="drawer" data-side={side} data-state={dataState} style:--size={size} role="dialog" aria-modal={modal || undefined} aria-label={title} tabindex="-1" onkeydown={keydown}>
      <header><b>{title}</b><button aria-label="Close drawer" onclick={close}>×</button></header>
      <div class="body">{@render children()}</div>
      {#if footer}<footer>{@render footer()}</footer>{/if}
    </div>
  </div>
{/if}

<style>
  .layer { position: fixed; inset: 0; z-index: 82; pointer-events: none; }
  .backdrop { position: absolute; inset: 0; border: 0; background: color-mix(in srgb, var(--br-void) 74%, transparent); pointer-events: auto; transition: opacity var(--br-motion-medium) var(--br-ease-standard); }
  .layer[data-modal='false'] .backdrop { display: none; }
  .layer[data-state='exiting'] .backdrop { opacity: 0; }
  .drawer { position: absolute; display: flex; flex-direction: column; max-width: 100vw; max-height: 100dvh; border: 1px solid var(--br-lineHot); background: var(--br-panel); pointer-events: auto; }
  .drawer[data-side='right'] { inset: 0 0 0 auto; width: var(--size); }
  .drawer[data-side='left'] { inset: 0 auto 0 0; width: var(--size); }
  .drawer[data-side='top'] { inset: 0 0 auto; height: var(--size); }
  .drawer[data-side='bottom'] { inset: auto 0 0; height: var(--size); }
  .drawer[data-side='right'][data-state='entered'] { animation: br-drawer-x var(--br-motion-medium) var(--br-ease-entrance); }
  .drawer[data-side='right'][data-state='exiting'] { animation: br-drawer-x var(--br-motion-medium) var(--br-ease-exit) reverse; }
  .drawer[data-side='left'][data-state='entered'] { animation: br-drawer-neg-x var(--br-motion-medium) var(--br-ease-entrance); }
  .drawer[data-side='left'][data-state='exiting'] { animation: br-drawer-neg-x var(--br-motion-medium) var(--br-ease-exit) reverse; }
  .drawer[data-side='top'][data-state='entered'] { animation: br-drawer-neg-y var(--br-motion-medium) var(--br-ease-entrance); }
  .drawer[data-side='top'][data-state='exiting'] { animation: br-drawer-neg-y var(--br-motion-medium) var(--br-ease-exit) reverse; }
  .drawer[data-side='bottom'][data-state='entered'] { animation: br-drawer-y var(--br-motion-medium) var(--br-ease-entrance); }
  .drawer[data-side='bottom'][data-state='exiting'] { animation: br-drawer-y var(--br-motion-medium) var(--br-ease-exit) reverse; }
  @keyframes br-drawer-x { from { transform: translateX(100%); } to { transform: translateX(0); } }
  @keyframes br-drawer-neg-x { from { transform: translateX(-100%); } to { transform: translateX(0); } }
  @keyframes br-drawer-y { from { transform: translateY(100%); } to { transform: translateY(0); } }
  @keyframes br-drawer-neg-y { from { transform: translateY(-100%); } to { transform: translateY(0); } }
  header { display: flex; justify-content: space-between; padding: 8px 10px; border-bottom: 1px solid var(--br-line); }
  header b { font-size: 10px; letter-spacing: .16em; }
  header button { min-width: 24px; min-height: 24px; border: 0; background: none; color: var(--br-mute); }
  .body { flex: 1; overflow: auto; padding: 10px; }
  footer { display: flex; justify-content: flex-end; gap: 6px; padding: 8px 10px; border-top: 1px solid var(--br-line); }
</style>
