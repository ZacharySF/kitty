<script lang="ts">
  import Calendar from './Calendar.svelte';
  interface Range { start:string; end:string }
  interface Props { value?:Range; min?:string; max?:string; onchange?:(range:Range)=>void }
  let { value=$bindable({start:'',end:''}),min,max,onchange }:Props=$props();let month=$state(new Date());const nextMonth=$derived(new Date(month.getFullYear(),month.getMonth()+1,1));
  function select(date:string){if(!value.start||value.end)value={start:date,end:''};else value=date<value.start?{start:date,end:value.start}:{start:value.start,end:date};onchange?.(value);}
</script>
<div class="range"><div><span>Start</span><output>{value.start||'—'}</output></div><div><span>End</span><output>{value.end||'—'}</output></div><div class="calendars"><Calendar value={value.start} bind:month {min} {max} rangeStart={value.start} rangeEnd={value.end} onchange={select}/><Calendar value={value.end} month={nextMonth} {min} {max} rangeStart={value.start} rangeEnd={value.end} onchange={select}/></div></div>
<style>.range>div:not(.calendars){display:inline-grid;gap:2px;margin-inline-end:var(--br-space-4)}span{color:var(--br-mute);font-size:var(--br-text-xs)}output{color:var(--br-ink)}.calendars{display:grid;grid-template-columns:repeat(2,minmax(260px,310px));gap:var(--br-space-2);margin-block-start:var(--br-space-2)}@media(max-width:640px){.calendars{grid-template-columns:1fr}}</style>
