<script lang="ts">import JsonViewerNode from './JsonViewerNode.svelte';interface Props{value:unknown;label?:string}let{value,label='JSON viewer'}:Props=$props();</script>
<div class="viewer" role="region" aria-label={label}><JsonViewerNode {value}/></div>
<style>.viewer{max-height:360px;overflow:auto;padding:var(--br-space-2);border:1px solid var(--br-line);background:var(--br-inset)}</style>
