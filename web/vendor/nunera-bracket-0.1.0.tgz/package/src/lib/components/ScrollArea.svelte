<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  interface Props extends HTMLAttributes<HTMLDivElement> { children: Snippet; orientation?: 'horizontal' | 'vertical' | 'both'; maxSize?: string; label?: string; ref?: HTMLDivElement | null }
  let { children, orientation = 'vertical', maxSize, label = 'Scrollable content', ref = $bindable(null), style = '', ...rest }: Props = $props();
  const overflowX = $derived(orientation === 'vertical' ? 'hidden' : 'auto');
  const overflowY = $derived(orientation === 'horizontal' ? 'hidden' : 'auto');
  const layoutStyle = $derived(`overflow-x:${overflowX};overflow-y:${overflowY};${maxSize ? orientation === 'horizontal' ? `max-width:${maxSize};` : `max-height:${maxSize};` : ''}${style}`);
</script>

<div {...rest} bind:this={ref} class="scroll-area" role="region" aria-label={label} data-orientation={orientation} style={layoutStyle}>{@render children()}</div>

<style>.scroll-area { scrollbar-width: thin; scrollbar-color: var(--br-structure) var(--br-inset); overscroll-behavior: contain; }</style>
