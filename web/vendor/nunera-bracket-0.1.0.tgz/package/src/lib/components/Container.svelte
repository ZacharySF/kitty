<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';

  type ContainerSize = 'sm' | 'md' | 'lg' | 'xl';
  interface Props extends HTMLAttributes<HTMLElement> { as?: string; children: Snippet; size?: ContainerSize; fluid?: boolean; padding?: string; ref?: HTMLElement | null }
  let { as = 'div', children, size = 'lg', fluid = false, padding = 'var(--br-space-6)', ref = $bindable(null), style = '', ...rest }: Props = $props();
  const widths: Record<ContainerSize, string> = { sm: '40rem', md: '48rem', lg: '64rem', xl: '80rem' };
  const layoutStyle = $derived(`width:100%;max-width:${fluid ? 'none' : widths[size]};margin-inline:auto;padding-inline:${padding};${style}`);
</script>

<svelte:element this={as} {...rest} bind:this={ref} data-fluid={fluid} style={layoutStyle}>{@render children()}</svelte:element>
