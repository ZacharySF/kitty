<script lang="ts">
  import type { HTMLAttributes } from 'svelte/elements';
  import { icons, type IconName } from '../icons';

  interface Props extends HTMLAttributes<HTMLSpanElement> {
    name: IconName;
    size?: number | string;
    label?: string;
  }

  let { name, size = 16, label, class: className = '', style = '', ...rest }: Props = $props();
  const dimension = $derived(typeof size === 'number' ? `${size}px` : size);
  const css = $derived(`--br-icon-size:${dimension};${style}`);
</script>

<span
  {...rest}
  class={`br-icon ${className}`}
  role={label ? 'img' : undefined}
  aria-label={label}
  aria-hidden={label ? undefined : 'true'}
  style={css}
>{icons[name]}</span>

<style>
  .br-icon {
    display: inline-grid;
    flex: 0 0 auto;
    width: var(--br-icon-size);
    height: var(--br-icon-size);
    place-items: center;
    color: currentColor;
    font-family: var(--br-font-icon);
    font-size: var(--br-icon-size);
    font-style: normal;
    font-weight: 400;
    font-variant-ligatures: none;
    line-height: 1;
    text-rendering: auto;
    vertical-align: middle;
  }
</style>
