<script lang="ts">
  import type { HTMLInputAttributes } from 'svelte/elements';
  import TextInput from './TextInput.svelte';
  import { getMessages } from '../headless/messages';

  export interface PasswordRequirement { label: string; met: (value: string) => boolean }

  interface Props extends Omit<HTMLInputAttributes, 'value' | 'type' | 'prefix' | 'size'> {
    value?: string;
    autocomplete?: 'current-password' | 'new-password';
    showStrength?: boolean;
    requirements?: PasswordRequirement[];
  }

  const defaults: PasswordRequirement[] = [
    { label: '8+ characters', met: (value) => value.length >= 8 },
    { label: 'uppercase letter', met: (value) => /[A-Z]/.test(value) },
    { label: 'number', met: (value) => /\d/.test(value) }
  ];

  let {
    value = $bindable(''),
    autocomplete = 'current-password',
    showStrength = false,
    requirements = defaults,
    ...rest
  }: Props = $props();

  let visible = $state(false);
  const messages = $derived(getMessages());
  const score = $derived(
    [value.length >= 8, /[A-Z]/.test(value), /\d/.test(value), /[^A-Za-z0-9]/.test(value)].filter(Boolean).length
  );
  const label = $derived(['empty', 'weak', 'fair', 'good', 'strong'][score]);
</script>

<div class="password">
  <div class="input">
    <TextInput {...rest} bind:value type={visible ? 'text' : 'password'} {autocomplete} />
    <button type="button" aria-label={visible ? messages.hidePassword : messages.showPassword} onclick={() => (visible = !visible)}>
      {visible ? messages.hidePassword : messages.showPassword}
    </button>
  </div>

  {#if showStrength}
    <div class="strength" role="meter" aria-valuemin={0} aria-valuemax={4} aria-valuenow={score} aria-valuetext={label} aria-label={messages.passwordStrength}>
      {#each [0, 1, 2, 3] as index (index)}<i class:on={index < score}></i>{/each}
      <span>{label}</span>
    </div>
    <ul>
      {#each requirements as requirement (requirement.label)}
        {@const met = requirement.met(value)}
        <li class:met>{met ? '✓' : '○'} {requirement.label}</li>
      {/each}
    </ul>
  {/if}
</div>

<style>
  .password, .strength { display: grid; gap: 4px; }
  .input { position: relative; }
  .input button { position: absolute; inset-inline-end: 5px; top: 50%; transform: translateY(-50%); border: 0; background: none; color: var(--br-signal); font-size: 8px; text-transform: uppercase; }
  .strength { grid-template-columns: repeat(4, 1fr) auto; align-items: center; }
  .strength i { height: 3px; background: var(--br-line); }
  .strength i.on { background: var(--br-go); }
  .strength span { color: var(--br-mute); font-size: 8px; text-transform: uppercase; }
  ul { display: flex; gap: 8px; flex-wrap: wrap; margin: 0; padding: 0; list-style: none; color: var(--br-dim); font-size: 8px; }
  li.met { color: var(--br-go); }
</style>
