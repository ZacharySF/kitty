<script lang="ts">
  import CollaborationSurface, { type CollaborationSurfaceProps } from './_CollaborationSurface.svelte';
  let props: Omit<CollaborationSurfaceProps, 'mode'> = $props();
</script>

<CollaborationSurface mode="notification-center-inbox" {...props} />
