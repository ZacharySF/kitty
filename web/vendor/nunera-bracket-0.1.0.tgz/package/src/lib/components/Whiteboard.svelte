<script lang="ts">
  import EditorSurface, { type EditorSurfaceProps } from './_EditorSurface.svelte';
  let props: Omit<EditorSurfaceProps, 'mode'> = $props();
</script>

<EditorSurface mode="whiteboard-infinite-canvas" {...props} />
