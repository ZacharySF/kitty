<script lang="ts">
  import { getMessages } from '../headless/messages';
  interface Props { value?: string[]; placeholder?: string; max?: number; allowDuplicates?: boolean; validate?: (tag: string) => boolean; onchange?: (tags: string[]) => void }

  let { value = $bindable([]), placeholder, max = Infinity, allowDuplicates = false, validate, onchange }: Props = $props();
  const messages = $derived(getMessages());
  const effectivePlaceholder = $derived(placeholder ?? messages.addTagPlaceholder);
  let input = $state('');

  function add(raw = input) {
    for (const part of raw.split(/[,\n]+/)) {
      const tag = part.trim();
      if (!tag || value.length >= max || (!allowDuplicates && value.includes(tag)) || validate?.(tag) === false) continue;
      value = [...value, tag];
    }
    input = '';
    onchange?.(value);
  }

  function remove(index: number) {
    value = value.filter((_, itemIndex) => itemIndex !== index);
    onchange?.(value);
  }

  function keydown(event: KeyboardEvent) {
    if (event.key === 'Enter' || event.key === ',') {
      event.preventDefault();
      add();
    } else if (event.key === 'Backspace' && !input && value.length) {
      remove(value.length - 1);
    }
  }
</script>

<div class="tags">
  {#each value as tag, index (`${tag}-${index}`)}
    <span>
      <button type="button" ondblclick={() => { input = tag; remove(index); }}>{tag}</button>
      <button type="button" aria-label={messages.removeTag({ tag })} onclick={() => remove(index)}>×</button>
    </span>
  {/each}
  <input
    bind:value={input}
    placeholder={effectivePlaceholder}
    onkeydown={keydown}
    onpaste={(event) => {
      const text = event.clipboardData?.getData('text');
      if (text?.includes(',')) {
        event.preventDefault();
        add(text);
      }
    }}
  />
  {#if max < Infinity}<small>{value.length}/{max}</small>{/if}
</div>

<style>
  .tags { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; min-height: var(--br-control-h); padding: 3px; border: 1px solid var(--br-line); background: var(--br-inset); }
  .tags:focus-within { border-color: var(--br-signal); }
  span { display: flex; border: 1px solid var(--br-lineHot); background: var(--br-raised); }
  span button { min-width: 24px; min-height: 24px; padding: 2px 5px; border: 0; background: none; color: var(--br-ink); font-size: 10px; }
  span button:last-child { color: var(--br-danger); }
  input { flex: 1; min-width: 9ch; padding: 3px; border: 0; background: transparent; outline: 0; color: var(--br-ink); }
  small { color: var(--br-dim); font-size: 10px; }
</style>
