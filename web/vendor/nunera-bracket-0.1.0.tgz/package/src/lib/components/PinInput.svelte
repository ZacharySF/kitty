<script lang="ts">
  interface Props {
    value?: string;
    length?: number;
    mode?: 'numeric' | 'alphanumeric';
    label?: string;
    disabled?: boolean;
    onchange?: (value: string) => void;
    oncomplete?: (value: string) => void;
  }

  let { value = $bindable(''), length = 6, mode = 'numeric', label = 'Verification code', disabled = false, onchange, oncomplete }: Props = $props();
  let root: HTMLDivElement;
  const cells = $derived(Array.from({ length }, (_, index) => value[index] ?? ''));

  function sanitize(input: string) {
    const allowed = mode === 'numeric' ? /\D/g : /[^a-z0-9]/gi;
    return input.replace(allowed, '').slice(0, length);
  }

  function focus(index: number) {
    root.querySelectorAll<HTMLInputElement>('input')[Math.max(0, Math.min(length - 1, index))]?.focus();
  }

  function update(index: number, raw: string) {
    const character = sanitize(raw).slice(-1);
    const next = value.split('');
    next[index] = character;
    value = next.join('').slice(0, length);
    onchange?.(value);
    if (character && index < length - 1) focus(index + 1);
    if (value.length === length) oncomplete?.(value);
  }

  function keydown(event: KeyboardEvent, index: number) {
    if (event.key !== 'Backspace') return;
    event.preventDefault();
    const next = value.split('');
    next[index] = '';
    value = next.join('');
    onchange?.(value);
    if (index > 0) focus(index - 1);
  }

  function paste(event: ClipboardEvent) {
    const pasted = sanitize(event.clipboardData?.getData('text') ?? '');
    if (!pasted) return;
    event.preventDefault();
    value = pasted;
    onchange?.(value);
    if (value.length === length) oncomplete?.(value);
    focus(Math.min(value.length, length - 1));
  }
</script>

<div class="pin" bind:this={root} role="group" aria-label={label} data-mode={mode}>
  {#each cells as cell, index (index)}
    <input
      type="text"
      inputmode={mode === 'numeric' ? 'numeric' : 'text'}
      autocomplete={index === 0 ? 'one-time-code' : 'off'}
      aria-label={`${label} ${index + 1} of ${length}`}
      value={cell}
      maxlength="1"
      {disabled}
      oninput={(event) => update(index, event.currentTarget.value)}
      onkeydown={(event) => keydown(event, index)}
      onpaste={paste}
    />
  {/each}
</div>

<style>
  .pin { display: inline-flex; gap: var(--br-space-2); }
  input { width: var(--br-control-h); height: var(--br-control-h); border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-ink); font: 700 14px var(--br-font-display); text-align: center; outline: 0; }
  input:focus { border-color: var(--br-signal); box-shadow: 0 0 0 2px color-mix(in srgb, var(--br-signal) 25%, transparent); }
</style>
