<script lang="ts">
  interface Props { value?: number; min?: number; max?: number; step?: number; label?: string; disabled?: boolean; onchange?: (value: number) => void }
  let { value = $bindable(0), min = 0, max = 100, step = 1, label = 'Knob', disabled = false, onchange }: Props = $props();
  let dragging = false; let startY = 0; let startValue = 0;
  const angle = $derived(-135 + ((value - min) / (max - min)) * 270);
  function set(next: number) { value = Math.min(max, Math.max(min, Math.round(next / step) * step)); onchange?.(value); }
  function down(event: PointerEvent & { currentTarget: EventTarget & HTMLDivElement }) { if (disabled) return; dragging = true; startY = event.clientY; startValue = value; event.currentTarget.setPointerCapture?.(event.pointerId); }
  function move(event: PointerEvent) { if (!dragging) return; set(startValue + ((startY - event.clientY) / 100) * (max - min)); }
  function up() { dragging = false; }
  function keydown(event: KeyboardEvent) { if (event.key === 'ArrowUp' || event.key === 'ArrowRight') { event.preventDefault(); set(value + step); } else if (event.key === 'ArrowDown' || event.key === 'ArrowLeft') { event.preventDefault(); set(value - step); } }
</script>

<div class="knob" role="slider" aria-label={label} aria-valuemin={min} aria-valuemax={max} aria-valuenow={value} aria-disabled={disabled} tabindex={disabled ? -1 : 0} onpointerdown={down} onpointermove={move} onpointerup={up} onpointercancel={up} onkeydown={keydown}>
  <span class="dial" style:--angle={`${angle}deg`}><i></i></span><output>{value}</output>
</div>
<style>.knob{display:inline-grid;place-items:center;gap:4px;touch-action:none;user-select:none}.dial{position:relative;width:52px;height:52px;border:2px solid var(--br-line);border-radius:50%;background:var(--br-inset);rotate:var(--angle)}.dial i{position:absolute;inset-block-start:4px;inset-inline-start:50%;width:2px;height:14px;background:var(--br-signal)}output{color:var(--br-ink);font-family:var(--br-font-display)}</style>
