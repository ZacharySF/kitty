<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { Snippet } from 'svelte';
  import { createPresence } from '../headless/presence';

  export interface PopoverTriggerProps {
    'data-trigger': true;
    'aria-haspopup': 'dialog';
    'aria-expanded': boolean;
    onclick: () => void;
    onkeydown: (event: KeyboardEvent) => void;
  }

  interface Props {
    open?: boolean;
    /** Receives the trigger attributes; spread them onto your own interactive element. */
    trigger: Snippet<[props: PopoverTriggerProps]>;
    children: Snippet;
    placement?: 'top' | 'top-start' | 'top-end' | 'bottom' | 'bottom-start' | 'bottom-end' | 'left' | 'left-start' | 'left-end' | 'right' | 'right-start' | 'right-end';
    arrow?: boolean;
    modal?: boolean;
  }

  let { open = $bindable(false), trigger, children, placement = 'bottom', arrow = true, modal = false }: Props = $props();
  let root = $state<HTMLElement>();

  const EXIT_DURATION = 120; // matches --br-motion-fast
  const presence = createPresence(open, { exitDuration: EXIT_DURATION });
  let mounted = $state(presence.mounted);
  let dataState = $state(presence.state);

  $effect(() => presence.subscribe(() => {
    mounted = presence.mounted;
    dataState = presence.state;
  }));
  $effect(() => { presence.set(open); });
  onDestroy(() => presence.destroy());

  function keydown(event: KeyboardEvent) {
    if (event.key !== 'Escape') return;
    open = false;
    root?.querySelector<HTMLElement>('[data-trigger]')?.focus();
  }

  function outside(event: MouseEvent) {
    if (open && !root?.contains(event.target as Node)) open = false;
  }

  const triggerProps = $derived<PopoverTriggerProps>({
    'data-trigger': true,
    'aria-haspopup': 'dialog',
    'aria-expanded': open,
    onclick: () => (open = !open),
    onkeydown: keydown
  });

  $effect(() => {
    if (typeof document === 'undefined') return;
    document.addEventListener('pointerdown', outside);
    return () => document.removeEventListener('pointerdown', outside);
  });
</script>

<span class="root" role="group" bind:this={root} data-placement={placement}>
  {@render trigger(triggerProps)}
  {#if mounted}
    <div class="content" data-state={dataState} role="dialog" aria-modal={modal}>{#if arrow}<span class="arrow" aria-hidden="true"></span>{/if}{@render children()}</div>
  {/if}
</span>

<style>
  .root { position: relative; display: inline-flex; }
  .content { position: absolute; z-index: 50; width: max-content; max-width: min(320px, calc(100vw - 20px)); padding: 8px; border: 1px solid var(--br-lineHot); background: var(--br-panel); box-shadow: 0 4px 14px #0005; }
  .root[data-placement^='bottom'] .content { top: calc(100% + 7px); }
  .root[data-placement^='top'] .content { bottom: calc(100% + 7px); }
  .root[data-placement^='right'] .content { left: calc(100% + 7px); }
  .root[data-placement^='left'] .content { right: calc(100% + 7px); }
  .root[data-placement$='-start'] .content { left: 0; top: 0; }
  .root[data-placement$='-end'] .content { right: 0; bottom: 0; }
  .root[data-placement='top'] .content, .root[data-placement='bottom'] .content { left: 50%; translate: -50% 0; }
  .root[data-placement='left'] .content, .root[data-placement='right'] .content { top: 50%; translate: 0 -50%; }
  .arrow { position: absolute; width: 8px; height: 8px; border: 1px solid var(--br-lineHot); background: var(--br-panel); rotate: 45deg; }
  .content[data-state='entered'] { animation: br-popover-in var(--br-motion-fast) var(--br-ease-entrance); }
  .content[data-state='exiting'] { animation: br-popover-in var(--br-motion-fast) var(--br-ease-exit) reverse; }
  @keyframes br-popover-in {
    from { opacity: 0; transform: translateY(-2px) scale(.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }
</style>
