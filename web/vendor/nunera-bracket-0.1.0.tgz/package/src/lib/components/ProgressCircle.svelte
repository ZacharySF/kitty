<script lang="ts">
  interface Props { value?: number; max?: number; label?: string; indeterminate?: boolean; thickness?: number; size?: number; showValue?: boolean }
  let { value = 0, max = 100, label = 'Progress', indeterminate = false, thickness = 6, size = 80, showValue = true }: Props = $props();
  const percent = $derived(Math.max(0, Math.min(100, (value / max) * 100)));
  const radius = $derived((size - thickness) / 2);
  const circumference = $derived(2 * Math.PI * radius);
</script>
<div class="circle" role="progressbar" aria-label={label} aria-valuemin="0" aria-valuemax={max} aria-valuenow={indeterminate ? undefined : value} data-indeterminate={indeterminate} style:--size={`${size}px`} style:--thickness={`${thickness}px`}><svg viewBox={`0 0 ${size} ${size}`} aria-hidden="true"><circle class="track" cx={size / 2} cy={size / 2} r={radius}></circle><circle class="value" cx={size / 2} cy={size / 2} r={radius} stroke-dasharray={circumference} stroke-dashoffset={circumference * (1 - percent / 100)}></circle></svg>{#if showValue && !indeterminate}<span>{Math.round(percent)}%</span>{/if}</div>
<style>.circle{position:relative;display:inline-grid;place-items:center;width:var(--size);height:var(--size)}svg{position:absolute;width:100%;height:100%;rotate:-90deg}circle{fill:none;stroke-width:var(--thickness)}.track{stroke:var(--br-line)}.value{stroke:var(--br-signal);transition:stroke-dashoffset var(--br-motion-fast)}.circle[data-indeterminate='true'] svg{animation:spin 1s linear infinite}.circle[data-indeterminate='true'] .value{stroke-dashoffset:75%}.circle span{color:var(--br-ink);font-family:var(--br-font-display)}@keyframes spin{to{rotate:270deg}}</style>
