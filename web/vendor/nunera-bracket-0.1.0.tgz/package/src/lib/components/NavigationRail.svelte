<script lang="ts">
  export interface NavigationRailItem { id:string; label:string; icon:string; href:string }
  interface Props { items:NavigationRailItem[]; active?:string; label?:string }
  let { items,active,label='Navigation rail' }:Props=$props();
</script>
<nav aria-label={label}>{#each items as item (item.id)}<a href={item.href} aria-label={item.label} aria-current={active===item.id?'page':undefined}><span aria-hidden="true">{item.icon}</span><small>{item.label}</small></a>{/each}</nav>
<style>nav{display:grid;align-content:start;width:72px;padding:var(--br-space-2);border-inline-end:1px solid var(--br-line);background:var(--br-panel)}a{display:grid;place-items:center;gap:2px;padding:var(--br-space-2);color:var(--br-mute);text-decoration:none}a[aria-current='page']{color:var(--br-signal);background:var(--br-structure-wash)}small{font-size:var(--br-text-xs)}</style>
