<script lang="ts">
  import type { HTMLInputAttributes } from 'svelte/elements';
  import { getMessages } from '../headless/messages';

  interface Props extends Omit<HTMLInputAttributes, 'value' | 'min' | 'max' | 'step' | 'onchange' | 'onkeydown'> {
    value?: number;
    min?: number;
    max?: number;
    step?: number;
    precision?: number;
    unit?: string;
    onchange?: (value: number) => void;
    onkeydown?: HTMLInputAttributes['onkeydown'];
  }

  let { value = $bindable(0), min = -Infinity, max = Infinity, step = 1, precision, unit, onchange, onkeydown, ...rest }: Props = $props();
  const messages = $derived(getMessages());
  const finiteMin = $derived(Number.isFinite(min) ? min : undefined);
  const finiteMax = $derived(Number.isFinite(max) ? max : undefined);

  function decimalPlaces(number: number): number {
    const valueText = number.toString().toLowerCase();
    if (valueText.includes('e-')) return Number(valueText.split('e-')[1]);
    return valueText.includes('.') ? valueText.length - valueText.indexOf('.') - 1 : 0;
  }

  function set(next: number) {
    const digits = precision ?? decimalPlaces(step);
    value = Math.min(max, Math.max(min, Number(next.toFixed(digits))));
    onchange?.(value);
  }

  function keydown(event: KeyboardEvent & { currentTarget: EventTarget & HTMLInputElement }) {
    onkeydown?.(event);
    if (event.defaultPrevented || !['ArrowUp', 'ArrowDown'].includes(event.key)) return;
    event.preventDefault();
    set(value + (event.key === 'ArrowUp' ? step : -step));
  }
</script>

<div class="number">
  <button type="button" aria-label={messages.decrease} disabled={value <= min} onclick={() => set(value - step)}>−</button>
  <input {...rest} type="number" bind:value min={finiteMin} max={finiteMax} {step} onkeydown={keydown} onchange={() => set(value)} />
  {#if unit}<span>{unit}</span>{/if}
  <button type="button" aria-label={messages.increase} disabled={value >= max} onclick={() => set(value + step)}>+</button>
</div>

<style>
  .number { display: inline-flex; min-height: var(--br-control-h); border: 1px solid var(--br-line); background: var(--br-inset); }
  button { width: 28px; min-height: 28px; border: 0; background: transparent; color: var(--br-mute); cursor: pointer; }
  button:first-child { border-inline-end: 1px solid var(--br-line); }
  button:last-child { border-inline-start: 1px solid var(--br-line); }
  button:hover:not(:disabled) { color: var(--br-ink); }
  button:disabled { opacity: .35; }
  input { width: 74px; border: 0; background: transparent; color: var(--br-ink); font-family: var(--br-font-display); text-align: center; outline: 0; }
  span { display: grid; place-items: center; padding-inline-end: 5px; color: var(--br-dim); font-size: 10px; }
</style>
