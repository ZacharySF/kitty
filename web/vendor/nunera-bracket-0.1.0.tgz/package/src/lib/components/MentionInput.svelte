<script lang="ts">
  export interface MentionSuggestion { value: string; label: string }
  interface Props { value?: string; suggestions: MentionSuggestion[]; trigger?: '@' | '#'; label?: string; placeholder?: string; onchange?: (value: string) => void; onmention?: (suggestion: MentionSuggestion) => void }
  let { value = $bindable(''), suggestions, trigger = '@', label = 'Mention input', placeholder = '', onchange, onmention }: Props = $props();
  let query = $state('');
  let triggerIndex = $state(-1);
  const filtered = $derived(suggestions.filter((item) => item.label.toLowerCase().startsWith(query.toLowerCase())));
  const open = $derived(triggerIndex >= 0 && filtered.length > 0);

  function input(event: Event & { currentTarget: EventTarget & HTMLInputElement }) {
    value = event.currentTarget.value;
    const cursor = event.currentTarget.selectionStart ?? value.length;
    triggerIndex = value.lastIndexOf(trigger, cursor - 1);
    const tail = triggerIndex >= 0 ? value.slice(triggerIndex + 1, cursor) : '';
    if (triggerIndex < 0 || /\s/.test(tail)) triggerIndex = -1;
    else query = tail;
    onchange?.(value);
  }

  function select(item: MentionSuggestion) {
    value = `${value.slice(0, triggerIndex)}${trigger}${item.value} `;
    triggerIndex = -1;
    query = '';
    onchange?.(value);
    onmention?.(item);
  }
</script>

<div class="mention">
  <input type="text" aria-label={label} {placeholder} bind:value oninput={input} />
  {#if open}<div role="listbox" aria-label={`${trigger} suggestions`}>{#each filtered as item (item.value)}<button type="button" role="option" aria-selected="false" onclick={() => select(item)}>{item.label}</button>{/each}</div>{/if}
</div>
<style>.mention{position:relative}.mention>input{width:100%;min-height:var(--br-control-h);border:1px solid var(--br-line);background:var(--br-inset);color:var(--br-ink)}[role='listbox']{position:absolute;z-index:var(--br-z-popover);display:grid;width:100%;border:1px solid var(--br-line);background:var(--br-panel)}[role='option']{padding:6px;border:0;background:transparent;color:var(--br-ink);text-align:start}</style>
