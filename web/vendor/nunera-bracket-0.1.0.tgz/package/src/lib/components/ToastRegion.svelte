<script lang="ts">
  import { onDestroy } from 'svelte';
  import type { Intent } from '../types';
  import { createPresence, type PresenceState } from '../headless/presence';

  export interface ToastItem { id: string; title: string; message?: string; intent?: Intent; duration?: number; actionLabel?: string; onaction?: () => void }
  type ToastPosition = 'top-left' | 'top-center' | 'top-right' | 'bottom-left' | 'bottom-center' | 'bottom-right';
  interface Props { toasts?: ToastItem[]; position?: ToastPosition; ondismiss?: (id: string) => void }

  let { toasts = $bindable([]), position = 'bottom-right', ondismiss }: Props = $props();
  const timers = new Map<string, ReturnType<typeof setTimeout>>();

  const EXIT_DURATION = 220; // matches --br-motion-medium
  interface Tracked { toast: ToastItem; presence: ReturnType<typeof createPresence>; unsubscribe: () => void }
  const toastMap = new Map<string, Tracked>();
  let order: string[] = [];
  let view = $state<{ id: string; toast: ToastItem; state: PresenceState }[]>([]);

  function syncView() {
    view = order.map((id) => {
      const entry = toastMap.get(id)!;
      return { id, toast: entry.toast, state: entry.presence.state };
    });
  }

  function dismiss(id: string) {
    const timer = timers.get(id);
    if (timer) clearTimeout(timer);
    timers.delete(id);
    if (!toasts.some((toast) => toast.id === id)) return;
    toasts = toasts.filter((toast) => toast.id !== id);
    ondismiss?.(id);
  }

  $effect(() => {
    const currentIds = new Set(toasts.map((toast) => toast.id));

    for (const toast of toasts) {
      const existing = toastMap.get(toast.id);
      if (existing) {
        existing.toast = toast;
        continue;
      }
      const presence = createPresence(true, { exitDuration: EXIT_DURATION });
      const unsubscribe = presence.subscribe(() => {
        if (presence.state === 'exited') {
          toastMap.delete(toast.id);
          order = order.filter((id) => id !== toast.id);
        }
        syncView();
      });
      toastMap.set(toast.id, { toast, presence, unsubscribe });
      order = [...order, toast.id];
    }

    for (const [id, entry] of toastMap) {
      if (!currentIds.has(id)) entry.presence.set(false);
    }

    syncView();
  });

  $effect(() => {
    const activeIds = new Set(toasts.map((toast) => toast.id));
    for (const [id, timer] of timers) {
      if (activeIds.has(id)) continue;
      clearTimeout(timer);
      timers.delete(id);
    }
    for (const toast of toasts) {
      if (toast.duration === 0 || timers.has(toast.id)) continue;
      timers.set(toast.id, setTimeout(() => dismiss(toast.id), toast.duration ?? 4_500));
    }
  });

  onDestroy(() => {
    for (const timer of timers.values()) clearTimeout(timer);
    timers.clear();
    for (const entry of toastMap.values()) {
      entry.unsubscribe();
      entry.presence.destroy();
    }
    toastMap.clear();
  });
</script>

<section class="br-toast-region" aria-label="Notifications" aria-live="polite" data-position={position}>
  {#each view as entry (entry.id)}
    <article class="br-toast" data-intent={entry.toast.intent} data-state={entry.state}>
      <div>
        <div class="br-toast__title">{entry.toast.title}</div>
        {#if entry.toast.message}<div class="br-toast__message">{entry.toast.message}</div>{/if}
        {#if entry.toast.actionLabel}<button class="action" onclick={() => entry.toast.onaction?.()}>{entry.toast.actionLabel}</button>{/if}
      </div>
      <button aria-label={`Dismiss ${entry.toast.title}`} onclick={() => dismiss(entry.toast.id)}>×</button>
    </article>
  {/each}
</section>

<style>
  .br-toast[data-state='entered'] { animation: br-toast-in var(--br-motion-medium) var(--br-ease-entrance); }
  .br-toast[data-state='exiting'] { animation: br-toast-in var(--br-motion-medium) var(--br-ease-exit) reverse; }
  .br-toast-region[data-position^='top'] { top: 16px; bottom: auto; }
  .br-toast-region[data-position$='left'] { right: auto; left: 16px; }
  .br-toast-region[data-position$='center'] { right: auto; left: 50%; translate: -50% 0; }
  .action { color: var(--br-signal); }
  @keyframes br-toast-in {
    from { opacity: 0; transform: translateX(16px); }
    to { opacity: 1; transform: translateX(0); }
  }
</style>
