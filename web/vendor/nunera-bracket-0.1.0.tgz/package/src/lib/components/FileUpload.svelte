<script lang="ts">
  import { getMessages } from '../headless/messages';
  interface Props { files?: File[]; accept?: string; multiple?: boolean; maxSize?: number; maxFiles?: number; disabled?: boolean; onchange?: (files: File[]) => void; onreject?: (file: File, reason: string) => void }

  let { files = $bindable([]), accept, multiple = true, maxSize = 25 * 1024 * 1024, maxFiles = 10, disabled = false, onchange, onreject }: Props = $props();
  const messages = $derived(getMessages());
  let dragging = $state(false);
  let input = $state<HTMLInputElement>();

  function accepts(file: File): boolean {
    if (!accept) return true;
    return accept.split(',').some((raw) => {
      const rule = raw.trim().toLocaleLowerCase();
      const name = file.name.toLocaleLowerCase();
      const type = file.type.toLocaleLowerCase();
      if (rule.startsWith('.')) return name.endsWith(rule);
      if (rule.endsWith('/*')) return type.startsWith(rule.slice(0, -1));
      return type === rule;
    });
  }

  function receive(list: FileList | File[] | null) {
    if (disabled || !list) return;
    const next = [...files];
    for (const file of Array.from(list)) {
      if (!accepts(file)) {
        onreject?.(file, 'File type is not accepted');
        continue;
      }
      if (file.size > maxSize) {
        onreject?.(file, 'File exceeds size limit');
        continue;
      }
      if (next.length >= maxFiles) {
        onreject?.(file, 'File count limit reached');
        continue;
      }
      if (!multiple) next.length = 0;
      next.push(file);
      if (!multiple) break;
    }
    files = next;
    onchange?.(files);
  }

  function remove(index: number) {
    if (disabled) return;
    files = files.filter((_, itemIndex) => itemIndex !== index);
    onchange?.(files);
  }
</script>

<div
  class="upload"
  role="region"
  aria-label={messages.fileUploadRegion}
  class:dragging
  data-disabled={disabled}
  ondragover={(event) => { if (!disabled) { event.preventDefault(); dragging = true; } }}
  ondragleave={() => dragging = false}
  ondrop={(event) => { event.preventDefault(); dragging = false; receive(event.dataTransfer?.files ?? null); }}
>
  <input class="br-sr" bind:this={input} type="file" aria-label={messages.chooseFiles} {accept} {multiple} {disabled} onchange={(event) => receive(event.currentTarget.files)} />
  <button type="button" {disabled} onclick={() => input?.click()}>
    <b>{messages.dropFilesHere}</b>
    <span>{messages.browseHint({ maxSizeMiB: Math.round(maxSize / 1024 / 1024), maxFiles })}</span>
  </button>
  {#if files.length}
    <ul>
      {#each files as file, index (`${file.name}-${index}`)}
        <li><span>{file.name}</span><small>{(file.size / 1024).toFixed(1)} KiB</small><button aria-label={messages.removeFile({ name: file.name })} disabled={disabled} onclick={() => remove(index)}>×</button></li>
      {/each}
    </ul>
  {/if}
</div>

<style>
  .upload { border: 1px dashed var(--br-line); background: var(--br-inset); }
  .upload.dragging { border-color: var(--br-go); background: color-mix(in srgb, var(--br-go) 8%, var(--br-inset)); }
  .upload[data-disabled='true'] { opacity: .55; }
  .upload > button { display: grid; place-items: center; width: 100%; min-height: 94px; border: 0; background: none; color: var(--br-mute); }
  .upload b { color: var(--br-signal); font-size: 10px; letter-spacing: .12em; text-transform: uppercase; }
  .upload span { font-size: 10px; }
  ul { margin: 0; padding: 0; border-top: 1px solid var(--br-line); list-style: none; }
  li { display: grid; grid-template-columns: 1fr auto auto; gap: 8px; padding: 4px 7px; border-bottom: 1px solid color-mix(in srgb, var(--br-line) 60%, transparent); color: var(--br-ink); font-size: 10px; }
  li small { color: var(--br-dim); }
  li button { min-width: 24px; min-height: 24px; border: 0; background: none; color: var(--br-danger); }
</style>
