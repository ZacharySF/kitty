<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  interface Props extends HTMLAttributes<HTMLElement> { as?: 'p' | 'span' | 'label' | 'div'; children: Snippet; size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'; weight?: number; color?: 'ink' | 'mute' | 'dim' | 'structure' | 'signal' | 'go' | 'reference' | 'caution' | 'alternate' | 'danger'; align?: 'start' | 'center' | 'end' | 'justify'; truncate?: boolean; clamp?: number; ref?: HTMLElement | null }
  let { as = 'p', children, size = 'md', weight = 400, color = 'ink', align = 'start', truncate = false, clamp, ref = $bindable(null), style = '', ...rest }: Props = $props();
  const textStyle = $derived(`font-size:var(--br-text-${size});font-weight:${weight};color:var(--br-${color});text-align:${align};${clamp ? `display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:${clamp};overflow:hidden;` : ''}${truncate ? 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;' : ''}${style}`);
</script>
<svelte:element this={as} {...rest} bind:this={ref} data-truncate={truncate} data-clamp={clamp} style={textStyle}>{@render children()}</svelte:element>
