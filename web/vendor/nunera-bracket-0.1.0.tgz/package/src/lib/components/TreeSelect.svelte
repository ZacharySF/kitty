<script lang="ts">
  export interface TreeSelectNode { value: string; label: string; disabled?: boolean; children?: TreeSelectNode[] }
  interface FlatNode extends TreeSelectNode { depth: number }
  interface Props { value?: string | string[]; nodes: TreeSelectNode[]; label?: string; placeholder?: string; multiple?: boolean; disabled?: boolean; onchange?: (value: string | string[]) => void }
  let { value = $bindable(''), nodes, label = 'Tree select', placeholder = 'Select', multiple = false, disabled = false, onchange }: Props = $props();
  let open = $state(false);
  let expanded = $state<string[]>([]);
  const instanceId = $props.id();
  const treeId = `${instanceId}-tree`;
  const selected = (item: string) => Array.isArray(value) ? value.includes(item) : value === item;
  function flatten(items: TreeSelectNode[], depth = 0): FlatNode[] { const result: FlatNode[] = []; for (const node of items) { result.push({ ...node, depth }); if (node.children && expanded.includes(node.value)) result.push(...flatten(node.children, depth + 1)); } return result; }
  function all(items: TreeSelectNode[]): TreeSelectNode[] { return items.flatMap((node) => [node, ...all(node.children ?? [])]); }
  const visible = $derived(flatten(nodes));
  const display = $derived(all(nodes).filter((node) => selected(node.value)).map((node) => node.label).join(', ') || placeholder);
  function expand(node: TreeSelectNode) { expanded = expanded.includes(node.value) ? expanded.filter((item) => item !== node.value) : [...expanded, node.value]; }
  function choose(node: TreeSelectNode) { if (node.disabled) return; if (multiple) value = selected(node.value) ? (value as string[]).filter((item) => item !== node.value) : [...(Array.isArray(value) ? value : []), node.value]; else { value = node.value; open = false; } onchange?.(value); }
</script>

<div class="tree-select">
  <button type="button" role="combobox" aria-label={label} aria-controls={treeId} aria-expanded={open} {disabled} onclick={() => (open = !open)}>{display}</button>
  {#if open}<div id={treeId} class="tree" role="tree" aria-multiselectable={multiple}>{#each visible as node (node.value)}<div role="treeitem" aria-selected={selected(node.value)} aria-expanded={node.children ? expanded.includes(node.value) : undefined} style:padding-inline-start={`${node.depth * 16}px`}>{#if node.children}<button type="button" aria-label={`${expanded.includes(node.value) ? 'Collapse' : 'Expand'} ${node.label}`} onclick={() => expand(node)}>{expanded.includes(node.value) ? '−' : '+'}</button>{/if}<label><input type={multiple ? 'checkbox' : 'radio'} name={multiple ? undefined : `${label}-tree`} checked={selected(node.value)} disabled={node.disabled} onchange={() => choose(node)} />{node.label}</label></div>{/each}</div>{/if}
</div>
<style>.tree-select{position:relative}.tree-select>button{width:100%;min-height:var(--br-control-h);border:1px solid var(--br-line);background:var(--br-inset);color:var(--br-ink);text-align:start}.tree{position:absolute;z-index:var(--br-z-popover);width:100%;padding:4px;border:1px solid var(--br-line);background:var(--br-panel)}[role='treeitem']{display:flex;align-items:center;min-height:26px}[role='treeitem']>button{width:22px;border:0;background:transparent;color:var(--br-signal)}label{display:flex;gap:5px;color:var(--br-ink)}</style>
