<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  interface Props extends HTMLAttributes<HTMLHeadingElement> { level?: 1 | 2 | 3 | 4 | 5 | 6; size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl'; id: string; anchorLabel?: string; anchor?: boolean; children: Snippet; ref?: HTMLHeadingElement | null }
  let { level = 2, size = 'xl', id, anchorLabel = 'Link to heading', anchor = true, children, ref = $bindable(null), style = '', ...rest }: Props = $props();
  const tag = $derived(`h${level}`);
</script>
<svelte:element this={tag} {...rest} bind:this={ref} {id} class="heading" style={`font-size:var(--br-text-${size});${style}`}>
  {@render children()}
  {#if anchor}<a class="anchor" href={`#${id}`} aria-label={anchorLabel}>#</a>{/if}
</svelte:element>
<style>.heading { position: relative; margin-block: .75em .35em; color: var(--br-ink); line-height: 1.2; } .anchor { margin-inline-start: .4em; color: var(--br-signal); text-decoration: none; opacity: 0; } .heading:hover .anchor, .anchor:focus-visible { opacity: 1; }</style>
