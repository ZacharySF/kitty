<script lang="ts">
  import CommerceSurface, { type CommerceSurfaceProps } from './_CommerceSurface.svelte';
  let props: Omit<CommerceSurfaceProps, 'mode'> = $props();
</script>

<CommerceSurface mode="reviews" {...props} />
