<script lang="ts">import BlockSurface,{type BlockSurfaceProps}from'../blocks/_BlockSurface.svelte';let props:Omit<BlockSurfaceProps,'mode'>=$props();</script><BlockSurface {...props} mode="sign-up"/>
