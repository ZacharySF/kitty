<script lang="ts">
  interface Props { value?: string; label?: string; swatches?: string[]; alpha?: number; onchange?: (value: string) => void; onalphachange?: (alpha: number) => void }
  let { value = $bindable('#6fd3c0'), label = 'Color', swatches = [], alpha = $bindable(1), onchange, onalphachange }: Props = $props();
  let hue = $state(170); let saturation = $state(47); let brightness = $state(83);

  function hsvToHex(h: number, s: number, v: number) { const c = (v / 100) * (s / 100); const x = c * (1 - Math.abs(((h / 60) % 2) - 1)); const m = v / 100 - c; let rgb = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x]; return `#${rgb.map((channel) => Math.round((channel + m) * 255).toString(16).padStart(2, '0')).join('')}`; }
  function updateColor() { value = hsvToHex(hue, saturation, brightness); onchange?.(value); }
  function saturationPointer(event: PointerEvent & { currentTarget: EventTarget & HTMLDivElement }) { const rect = event.currentTarget.getBoundingClientRect(); if (!rect.width || !rect.height) return; saturation = Math.round(((event.clientX - rect.left) / rect.width) * 100); brightness = Math.round((1 - (event.clientY - rect.top) / rect.height) * 100); saturation = Math.min(100, Math.max(0, saturation)); brightness = Math.min(100, Math.max(0, brightness)); updateColor(); }
  function hex(event: Event & { currentTarget: EventTarget & HTMLInputElement }) { const next = event.currentTarget.value; if (!/^#[0-9a-f]{6}$/i.test(next)) return; value = next.toLowerCase(); onchange?.(value); }
  function choose(color: string) { value = color.toLowerCase(); onchange?.(value); }
</script>

<div class="picker" aria-label={label}>
  <div class="saturation" role="slider" aria-label="Saturation and brightness" aria-valuemin="0" aria-valuemax="100" aria-valuenow={saturation} aria-valuetext={`${saturation}% saturation, ${brightness}% brightness`} tabindex="0" style:--hue={`${hue}`} onpointerdown={saturationPointer} onpointermove={(event) => { if (event.buttons) saturationPointer(event); }}><i style:left={`${saturation}%`} style:top={`${100 - brightness}%`}></i></div>
  <label>Hue<input type="range" aria-label="Hue" min="0" max="360" bind:value={hue} oninput={updateColor} /></label>
  <label>Alpha<input type="range" aria-label="Alpha" min="0" max="1" step="0.01" bind:value={alpha} oninput={() => onalphachange?.(alpha)} /></label>
  <label>Hex<input type="text" aria-label="Hex color" value={value} pattern="#[0-9A-Fa-f]{6}" onchange={hex} /></label>
  {#if swatches.length}<div class="swatches" aria-label="Color swatches">{#each swatches as color (color)}<button type="button" aria-label={`Use color ${color}`} style:background={color} onclick={() => choose(color)}></button>{/each}</div>{/if}
</div>
<style>.picker{display:grid;gap:6px}.saturation{position:relative;width:180px;height:100px;background:linear-gradient(to top,#000,transparent),linear-gradient(to right,#fff,hsla(var(--hue),100%,50%,1));border:1px solid var(--br-line);touch-action:none}.saturation i{position:absolute;width:10px;height:10px;border:2px solid white;border-radius:50%;translate:-50% -50%;box-shadow:0 0 0 1px #000}.picker label{display:grid;grid-template-columns:40px 1fr;align-items:center;color:var(--br-mute)}.picker input[type='text']{min-height:28px;border:1px solid var(--br-line);background:var(--br-inset);color:var(--br-ink)}.swatches{display:flex;gap:4px}.swatches button{width:24px;height:24px;border:1px solid var(--br-line)}</style>
