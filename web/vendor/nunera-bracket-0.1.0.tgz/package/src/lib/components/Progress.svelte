<script lang="ts">
  import type { Intent, Size } from '../types';
  import { getMessages } from '../headless/messages';
  interface Props { value?: number; max?: number; label?: string; indeterminate?: boolean; showValue?: boolean; size?: Size; color?: Intent; segments?: { value: number; color?: string }[] }
  let { value = 0, max = 100, label, indeterminate = false, showValue = true, size = 'md', color = 'primary', segments }: Props = $props();
  const messages = $derived(getMessages());
  const percent = $derived(Math.max(0, Math.min(100, (value / max) * 100)));
  const accessibleLabel = $derived(label ?? messages.progressLabel({ percent: Math.round(percent) }));
</script>
<div class="br-progress" data-indeterminate={indeterminate} data-size={size} data-color={color} aria-label={accessibleLabel} role="progressbar" aria-valuemin="0" aria-valuemax={max} aria-valuenow={indeterminate ? undefined : value}>{#if label || showValue}<div class="br-progress__meta"><span>{label}</span>{#if showValue && !indeterminate}<span>{Math.round(percent)}%</span>{/if}</div>{/if}<div class="br-progress__track">{#if segments}<div class="segments">{#each segments as segment, index (index)}<i style:flex={segment.value} style:background={segment.color ?? 'var(--br-progress-color)'}></i>{/each}</div>{:else}<div class="br-progress__value" style:width={`${percent}%`}></div>{/if}</div></div>
<style>.br-progress{--br-progress-color:var(--br-signal)}.br-progress[data-color='success']{--br-progress-color:var(--br-go)}.br-progress[data-color='warning']{--br-progress-color:var(--br-caution)}.br-progress[data-color='danger']{--br-progress-color:var(--br-danger)}.br-progress__value{background:var(--br-progress-color)}.br-progress[data-size='xs'] .br-progress__track{height:2px}.br-progress[data-size='sm'] .br-progress__track{height:4px}.br-progress[data-size='lg'] .br-progress__track{height:10px}.segments{display:flex;height:100%;gap:1px}.segments i{display:block;opacity:.65}</style>
