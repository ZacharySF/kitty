<script lang="ts">
  import PlanningSurface, { type PlanningSurfaceProps } from './_PlanningSurface.svelte';
  let props: Omit<PlanningSurfaceProps, 'mode'> = $props();
</script>

<PlanningSurface mode="gantt-chart" {...props} />
