<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type EmptyStatePart = 'root' | 'glyph' | 'title' | 'description';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    title: string;
    description?: string;
    glyph?: string;
    actions?: Snippet;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<EmptyStatePart>;
    styles?: PartOverrides<EmptyStatePart>;
  }
  let { as = 'div', title, description, glyph = '◇', actions, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(['br-empty', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')}><div><div class={partClass('br-empty__glyph', classes, 'glyph')} style={partStyle(undefined, styles, 'glyph')} aria-hidden="true">{glyph}</div><div class={partClass('br-empty__title', classes, 'title')} style={partStyle(undefined, styles, 'title')}>{title}</div>{#if description}<p class={partClass('br-empty__description', classes, 'description')} style={partStyle(undefined, styles, 'description')}>{description}</p>{/if}{#if actions}<div class="br-cluster" style:justify-content="center">{@render actions()}</div>{/if}</div></svelte:element>
