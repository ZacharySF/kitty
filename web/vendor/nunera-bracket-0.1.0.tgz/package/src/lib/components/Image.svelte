<script lang="ts">
  import type { HTMLImgAttributes } from 'svelte/elements';
  interface Props extends HTMLImgAttributes { src: string; alt: string; fallback?: string; fit?: 'cover' | 'contain' | 'fill' | 'none' | 'scale-down'; rounded?: 'none' | 'sm' | 'md' | 'lg' | 'full'; ratio?: '16/9' | '4/3' | '1/1' | 'auto' }
  let { src, alt, fallback, fit = 'cover', rounded = 'none', ratio = 'auto', loading = 'lazy', style = '', onerror, ...rest }: Props = $props();
  let current = $derived(src);
  function error(event: Event) { onerror?.(event as never); if (fallback && current !== fallback) current = fallback; }
  const radius = $derived(rounded === 'full' ? '50%' : `var(--br-radius-${rounded})`);
</script>
<img {...rest} src={current} {alt} {loading} onerror={error} style={`display:block;max-width:100%;object-fit:${fit};border-radius:${radius};aspect-ratio:${ratio};${style}`} />
