<script lang="ts">
  import { onDestroy, onMount } from 'svelte';
  import { createPresence } from '../headless/presence';

  interface Command {
    id: string;
    label: string;
    group?: string;
    keywords?: string[];
    shortcut?: string;
    disabled?: boolean;
    run: () => void | Promise<void>;
  }

  interface Props { open?: boolean; commands: Command[]; placeholder?: string; onclose?: () => void }

  let { open = $bindable(false), commands, placeholder = 'Type a command…', onclose }: Props = $props();
  let query = $state('');
  let selected = $state(0);
  let input = $state<HTMLInputElement>();

  const results = $derived(
    commands.filter((command) =>
      [command.label, ...(command.keywords ?? [])].join(' ').toLocaleLowerCase().includes(query.toLocaleLowerCase())
    )
  );

  const EXIT_DURATION = 220; // matches --br-motion-medium
  const presence = createPresence(open, { exitDuration: EXIT_DURATION });
  let mounted = $state(presence.mounted);
  let dataState = $state(presence.state);

  $effect(() => presence.subscribe(() => {
    mounted = presence.mounted;
    dataState = presence.state;
  }));
  $effect(() => { presence.set(open); });
  onDestroy(() => presence.destroy());

  $effect(() => {
    if (open) queueMicrotask(() => input?.focus());
    selected = 0;
  });
  onMount(() => {
    const shortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLocaleLowerCase() === 'k') {
        event.preventDefault();
        open = !open;
      }
    };
    window.addEventListener('keydown', shortcut);
    return () => window.removeEventListener('keydown', shortcut);
  });


  function close() {
    open = false;
    query = '';
    onclose?.();
  }

  async function run(command: Command) {
    if (command.disabled) return;
    await command.run();
    close();
  }

  function keydown(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      close();
    } else if (event.key === 'ArrowDown') {
      event.preventDefault();
      selected = Math.min(results.length - 1, selected + 1);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      selected = Math.max(0, selected - 1);
    } else if (event.key === 'Enter' && results[selected]) {
      event.preventDefault();
      void run(results[selected]);
    }
  }
</script>

{#if mounted}
  <div class="layer" data-state={dataState}>
    <button class="backdrop" aria-label="Close command palette" onclick={close}></button>
    <div class="palette" role="dialog" aria-modal="true" tabindex="-1" aria-label="Command palette" onkeydown={keydown}>
      <label>
        <span>⌕</span>
        <input bind:this={input} bind:value={query} {placeholder} />
        <kbd>ESC</kbd>
      </label>
      <div role="listbox" aria-label="Commands">
        {#each results as command, index (command.id)}
          <button
            role="option"
            aria-selected={index === selected}
            disabled={command.disabled}
            onmouseenter={() => (selected = index)}
            onclick={() => run(command)}
          >
            <span>{command.label}</span>
            {#if command.group}<small>{command.group}</small>{/if}
            {#if command.shortcut}<kbd>{command.shortcut}</kbd>{/if}
          </button>
        {:else}
          <p>No commands match “{query}”.</p>
        {/each}
      </div>
    </div>
  </div>
{/if}

<style>
  .layer { position: fixed; inset: 0; z-index: 90; display: grid; place-items: start center; padding-top: min(18vh, 150px); }
  .backdrop { position: absolute; inset: 0; border: 0; background: color-mix(in srgb, var(--br-void) 80%, transparent); transition: opacity var(--br-motion-medium) var(--br-ease-standard); }
  .layer[data-state='exiting'] .backdrop { opacity: 0; }
  .palette { position: relative; width: min(580px, calc(100vw - 20px)); border: 1px solid var(--br-lineHot); background: var(--br-panel); box-shadow: 0 12px 40px #0008; }
  label { display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 8px; padding: 8px 10px; border-bottom: 1px solid var(--br-line); }
  label span { color: var(--br-signal); }
  input { border: 0; background: none; color: var(--br-ink); outline: 0; }
  .palette > div { max-height: 360px; overflow: auto; padding: 5px; }
  .palette > div button { display: grid; grid-template-columns: 1fr auto auto; gap: 8px; width: 100%; padding: 6px 7px; border: 0; background: none; color: var(--br-ink); text-align: left; }
  .palette > div button[aria-selected='true'] { background: var(--br-structure); color: var(--br-on-structure); }
  small { color: var(--br-dim); }
  p { padding: 10px; font-size: 10px; }
  .layer[data-state='entered'] .palette { animation: br-palette-in var(--br-motion-medium) var(--br-ease-entrance); }
  .layer[data-state='exiting'] .palette { animation: br-palette-in var(--br-motion-medium) var(--br-ease-exit) reverse; }
  @keyframes br-palette-in {
    from { opacity: 0; transform: translateY(-8px) scale(.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }
</style>
