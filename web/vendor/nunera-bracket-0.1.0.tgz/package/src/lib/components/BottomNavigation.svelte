<script lang="ts">
  export interface BottomNavigationItem { id:string; label:string; icon:string; href?:string }
  interface Props { items:BottomNavigationItem[]; value?:string; onchange?:(id:string)=>void }
  let { items,value=$bindable(),onchange }:Props=$props();function select(id:string){value=id;onchange?.(id);}
</script>
<nav aria-label="Bottom navigation">{#each items as item,index (item.id)}{#if index<5}<a href={item.href??`#${item.id}`} aria-current={value===item.id?'page':undefined} onclick={()=>select(item.id)}><span aria-hidden="true">{item.icon}</span><small>{item.label}</small></a>{/if}{/each}</nav>
<style>nav{display:grid;grid-template-columns:repeat(var(--count,5),1fr);border-top:1px solid var(--br-line);background:var(--br-panel)}a{display:grid;place-items:center;gap:2px;padding:var(--br-space-2);color:var(--br-mute);text-decoration:none}a[aria-current='page']{color:var(--br-signal);background:var(--br-structure-wash)}small{font-size:var(--br-text-xs)}</style>
