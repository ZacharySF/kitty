<script lang="ts">
  import type { Snippet } from 'svelte';

  interface Props {
    children: Snippet;
    pending?: Snippet;
    failed?: Snippet<[error: unknown, reset: () => void]>;
    onerror?: (error: unknown, reset: () => void) => void;
  }

  let { children, pending, failed, onerror }: Props = $props();
</script>

<svelte:boundary {pending} {failed} {onerror}>
  {@render children()}
</svelte:boundary>
