<script lang="ts">
  import { getMessages } from '../headless/messages';
  import { tokenizeLine } from '../headless/highlight';
  import { writeClipboard } from '../headless/clipboard';

  interface Props { code: string; language?: string; filename?: string; lineNumbers?: boolean; highlight?: number[] }
  let { code, language = 'text', filename, lineNumbers = true, highlight = [] }: Props = $props();
  let copied = $state(false);
  const messages = getMessages();
  const lines = $derived(code.split('\n').map((line) => tokenizeLine(line, language)));
  async function copy() {
    await writeClipboard(code);
    copied = true;
    setTimeout(() => (copied = false), 1500);
  }
</script>

<figure class="wrap">
  <figcaption><span>{filename ?? language}</span><button type="button" aria-label={messages.copyCode} onclick={copy}>{copied ? messages.copied : messages.copyCode.replace(/ code$/i, '')}</button></figcaption>
  <pre class="br-code"><code>{#each lines as tokens, index (index)}<span class:highlight={highlight.includes(index + 1)}>{#if lineNumbers}<i aria-hidden="true">{index + 1}</i>{/if}<b>{#each tokens as token, tokenIndex (tokenIndex)}<span class={`token-${token.type}`}>{token.value}</span>{/each}</b></span>{/each}</code></pre>
  <span class="br-sr" aria-live="polite">{copied ? messages.copied : ''}</span>
</figure>

<style>
  .wrap { margin: 0; }
  figcaption { display: flex; justify-content: space-between; padding: 5px 8px; border: 1px solid var(--br-line); border-bottom: 0; background: var(--br-raised); color: var(--br-mute); font-size: 10px; }
  button { border: 0; background: transparent; color: var(--br-signal); cursor: pointer; }
  code { display: block; }
  code > span { display: grid; grid-template-columns: auto 1fr; min-height: 1.55em; }
  code > span.highlight { background: color-mix(in srgb, var(--br-caution) 12%, transparent); }
  i { min-width: 3ch; margin-inline-end: 1ch; color: var(--br-dim); font-style: normal; text-align: end; user-select: none; }
  b { color: var(--br-mute); font-weight: 400; white-space: pre; }
  .token-keyword { color: var(--br-alternate); }
  .token-string { color: var(--br-go); }
  .token-number { color: var(--br-caution); }
  .token-comment { color: var(--br-dim); font-style: italic; }
</style>
