<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import type { Density } from '../types';
  import { ROLES, luminance, onFill, type Theme } from '../theme';
  interface Props extends HTMLAttributes<HTMLDivElement> { theme: Theme; density?: Density; children: Snippet; ref?: HTMLDivElement | null }
  let { theme, density = 'comfortable', children, class: className = '', style = '', ref = $bindable(null), ...rest }: Props = $props();
  const densityCss: Record<Density, string[]> = {
    compact: ['--br-control-h:26px', '--br-row-py:2px', '--br-panel-p:8px', '--br-gap:6px'],
    comfortable: ['--br-control-h:30px', '--br-row-py:4px', '--br-panel-p:10px', '--br-gap:8px'],
    spacious: ['--br-control-h:38px', '--br-row-py:7px', '--br-panel-p:14px', '--br-gap:12px']
  };
  const css = $derived([
    ...ROLES.map((role) => `--br-${role}:${theme[role]}`),
    `--br-structure-wash:${theme.structure}24`,
    `--br-on-structure:${onFill(theme.structure)}`, `--br-on-signal:${onFill(theme.signal)}`,
    `--br-on-go:${onFill(theme.go)}`, `--br-on-reference:${onFill(theme.reference)}`,
    `--br-on-caution:${onFill(theme.caution)}`, `--br-on-danger:${onFill(theme.danger)}`,
    `color-scheme:${luminance(theme.panel) > 0.4 ? 'light' : 'dark'}`,
    ...densityCss[density],
    style
  ].filter(Boolean).join(';'));
</script>
<div {...rest} bind:this={ref} class={className} style={css} data-br-theme={theme.name} data-br-density={density}>{@render children()}</div>
