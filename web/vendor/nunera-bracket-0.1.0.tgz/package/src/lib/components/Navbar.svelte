<script lang="ts">
  import type { Snippet } from 'svelte';
  import Hamburger from './Hamburger.svelte';
  export interface NavbarLink { label:string; href:string; active?:boolean }
  interface Props { brand:string; links:NavbarLink[]; logo?:Snippet; actions?:Snippet; menuOpen?:boolean }
  let { brand,links,logo,actions,menuOpen=$bindable(false) }:Props=$props();
  const menuId=$props.id();
</script>
<header><a class="brand" href="/" aria-label={brand}>{#if logo}{@render logo()}{:else}<span aria-hidden="true">◇</span>{/if}<strong>{brand}</strong></a><nav id={menuId} aria-label="Primary" data-open={menuOpen}>{#each links as link (link.href)}<a href={link.href} aria-current={link.active?'page':undefined}>{link.label}</a>{/each}</nav>{#if actions}<div class="actions">{@render actions()}</div>{/if}<Hamburger open={menuOpen} controls={menuId} onclick={()=>menuOpen=!menuOpen}/></header>
<style>header{display:flex;align-items:center;gap:var(--br-space-4);padding:var(--br-space-2) var(--br-space-3);border-bottom:1px solid var(--br-line);background:var(--br-panel)}.brand{display:flex;align-items:center;gap:var(--br-space-2);color:var(--br-ink);text-decoration:none}nav{display:flex;gap:var(--br-space-3);margin-inline:auto}nav a{color:var(--br-mute);text-decoration:none}nav a[aria-current='page']{color:var(--br-signal)}.actions{display:flex;gap:var(--br-space-1)}header :global(.hamburger){display:none}@media(max-width:640px){header :global(.hamburger){display:grid}nav{display:none;position:absolute;inset:var(--br-control-h) 0 auto;padding:var(--br-space-3);background:var(--br-panel)}nav[data-open='true']{display:grid}.actions{margin-inline-start:auto}}</style>
