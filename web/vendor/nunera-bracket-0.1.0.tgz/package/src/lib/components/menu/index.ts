import Root from './MenuRoot.svelte';
import Trigger from './MenuTrigger.svelte';
import Content from './MenuContent.svelte';
import Item from './MenuItem.svelte';
import Group from './MenuGroup.svelte';
import Separator from './MenuSeparator.svelte';

/** Compound menu: `<Menu.Root>` with `Menu.Trigger`, `Menu.Content`, `Menu.Item`, `Menu.Group`, and `Menu.Separator`. */
export const Menu = { Root, Trigger, Content, Item, Group, Separator };

export type { MenuContext, MenuItemRegistration } from './context';
