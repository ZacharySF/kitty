<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLButtonAttributes } from 'svelte/elements';
  import { getMenuContext } from './context';

  interface Props extends HTMLButtonAttributes {
    children: Snippet;
    ref?: HTMLButtonElement | null;
  }

  let { children, ref = $bindable(null), ...rest }: Props = $props();
  const menu = getMenuContext();

  function keydown(event: KeyboardEvent) {
    if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      menu.setOpen(true, { focus: 'first' });
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      menu.setOpen(true, { focus: 'last' });
    }
  }

  $effect(() => {
    menu.setTrigger(ref);
    return () => menu.setTrigger(null);
  });
</script>

<button
  {...rest}
  bind:this={ref}
  type="button"
  class="menu-trigger"
  aria-haspopup="menu"
  aria-expanded={menu.open}
  aria-controls={`${menu.id}-content`}
  onclick={() => menu.toggle()}
  onkeydown={keydown}
>
  {@render children()}
</button>

<style>
  .menu-trigger {
    display: inline-flex;
    align-items: center;
    gap: 1ch;
    min-height: var(--br-control-h);
    padding: 5px 10px;
    border: 1px solid var(--br-line);
    background: transparent;
    color: var(--br-ink);
    cursor: pointer;
  }
  .menu-trigger[aria-expanded='true'] { border-color: var(--br-signal); color: var(--br-signal); }
</style>
