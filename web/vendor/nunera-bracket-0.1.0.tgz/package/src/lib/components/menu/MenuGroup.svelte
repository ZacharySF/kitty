<script lang="ts">
  import type { Snippet } from 'svelte';

  interface Props { label?: string; children: Snippet }
  let { label, children }: Props = $props();
  const id = $props.id();
</script>

<div class="menu-group" role="group" aria-labelledby={label ? id : undefined}>
  {#if label}<p class="menu-group__label" {id}>{label}</p>{/if}
  {@render children()}
</div>

<style>
  .menu-group { display: grid; }
  .menu-group__label {
    margin: 0;
    padding: var(--br-space-2) var(--br-space-3);
    color: var(--br-mute);
    font-size: var(--br-text-xs);
    letter-spacing: .12em;
    text-transform: uppercase;
  }
</style>
