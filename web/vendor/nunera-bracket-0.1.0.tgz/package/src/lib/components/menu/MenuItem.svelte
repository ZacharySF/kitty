<script lang="ts">
  import type { Snippet } from 'svelte';
  import { getMenuContext } from './context';

  interface Props {
    /** Plain-text label used for typeahead matching and as the accessible name. */
    label: string;
    disabled?: boolean;
    shortcut?: string;
    icon?: Snippet;
    onselect?: () => void;
    ref?: HTMLButtonElement | null;
  }

  let { label, disabled = false, shortcut, icon, onselect, ref = $bindable(null) }: Props = $props();
  const menu = getMenuContext();
  const id = $props.id();

  $effect(() => {
    if (!ref) return;
    return menu.register({ id, label, disabled, node: ref });
  });

  function select() {
    if (disabled) return;
    onselect?.();
    menu.select(id);
  }
</script>

<button
  bind:this={ref}
  type="button"
  class="menu-item"
  role="menuitem"
  {disabled}
  data-active={menu.activeId === id}
  tabindex={menu.activeId === id ? 0 : -1}
  onclick={select}
  onkeydown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); select(); } }}
  onpointerenter={() => { if (!disabled) menu.activate(id); }}
  onfocus={() => menu.activate(id)}
>
  {#if icon}<span class="menu-item__icon">{@render icon()}</span>{/if}
  <span class="menu-item__label">{label}</span>
  {#if shortcut}<kbd class="menu-item__shortcut">{shortcut}</kbd>{/if}
</button>

<style>
  .menu-item {
    display: flex;
    align-items: center;
    gap: var(--br-space-3);
    width: 100%;
    min-height: var(--br-control-h);
    padding: var(--br-space-2) var(--br-space-3);
    border: 0;
    background: transparent;
    color: var(--br-ink);
    text-align: start;
    cursor: pointer;
  }
  .menu-item:disabled { color: var(--br-dim); cursor: not-allowed; }
  .menu-item[data-active='true']:not(:disabled) { background: var(--br-structure-wash); color: var(--br-signal); }
  .menu-item__label { flex: 1; min-width: 0; }
  .menu-item__shortcut { margin-inline-start: auto; color: var(--br-mute); font-size: var(--br-text-xs); }
</style>
