<script lang="ts">
  let { class: className = "" }: { class?: string } = $props();
</script>

<div class={["menu-separator", className]} role="separator" aria-orientation="horizontal"></div>

<style>
  .menu-separator {
    height: 1px;
    margin: var(--br-space-2) 0;
    background: var(--br-line);
  }
</style>
