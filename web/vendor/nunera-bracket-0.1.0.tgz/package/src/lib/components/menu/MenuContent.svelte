<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import { dismissableLayer } from '../../headless/dismissable-layer';
  import { getMenuContext } from './context';

  interface Props extends HTMLAttributes<HTMLDivElement> {
    children: Snippet;
    label?: string;
    placement?: 'bottom-start' | 'bottom-end' | 'top-start' | 'top-end';
    ref?: HTMLDivElement | null;
  }

  let { children, label, placement = 'bottom-start', ref = $bindable(null), ...rest }: Props = $props();
  const menu = getMenuContext();

  function keydown(event: KeyboardEvent) {
    const keys: Record<string, () => void> = {
      ArrowDown: () => menu.move(1),
      ArrowUp: () => menu.move(-1),
      Home: () => menu.moveTo('first'),
      End: () => menu.moveTo('last')
    };
    const handler = keys[event.key];
    if (handler) {
      event.preventDefault();
      handler();
      return;
    }
    if (event.key === 'Tab') {
      menu.setOpen(false);
      return;
    }
    if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault();
      menu.typeahead(event.key);
    }
  }
</script>

{#if menu.open}
  <div
    {...rest}
    bind:this={ref}
    id={`${menu.id}-content`}
    class="menu-content"
    role="menu"
    aria-label={label}
    data-placement={placement}
    tabindex="-1"
    onkeydown={keydown}
    use:dismissableLayer={{
      ondismiss: (reason) => {
        menu.setOpen(false);
        if (reason === 'escape') menu.focusTrigger();
      }
    }}
  >
    {@render children()}
  </div>
{/if}

<style>
  .menu-content {
    position: absolute;
    z-index: var(--br-z-popover);
    min-width: 180px;
    padding: var(--br-space-2);
    border: 1px solid var(--br-lineHot);
    background: var(--br-panel);
    box-shadow: var(--br-shadow-md);
  }
  .menu-content[data-placement='bottom-start'] { inset-block-start: calc(100% + var(--br-space-2)); inset-inline-start: 0; }
  .menu-content[data-placement='bottom-end'] { inset-block-start: calc(100% + var(--br-space-2)); inset-inline-end: 0; }
  .menu-content[data-placement='top-start'] { inset-block-end: calc(100% + var(--br-space-2)); inset-inline-start: 0; }
  .menu-content[data-placement='top-end'] { inset-block-end: calc(100% + var(--br-space-2)); inset-inline-end: 0; }
</style>
