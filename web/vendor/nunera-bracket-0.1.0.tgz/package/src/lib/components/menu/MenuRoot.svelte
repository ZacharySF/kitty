<script lang="ts">
  import { untrack, type Snippet } from 'svelte';
  import { setMenuContext, type MenuContext, type MenuItemRegistration } from './context';

  interface Props {
    /** Bindable open state; omit for uncontrolled usage. */
    open?: boolean;
    /** Milliseconds of inactivity before the typeahead buffer resets. */
    typeaheadTimeout?: number;
    onselect?: (id: string) => void;
    onopenchange?: (open: boolean) => void;
    children: Snippet;
  }

  let { open = $bindable(false), typeaheadTimeout = 600, onselect, onopenchange, children }: Props = $props();

  const id = $props.id();
  let items = $state<MenuItemRegistration[]>([]);
  let activeId = $state<string | undefined>();
  let trigger: HTMLElement | null = null;
  let search = '';
  let searchTimer: ReturnType<typeof setTimeout> | undefined;

  const enabled = $derived(items.filter((item) => !item.disabled));

  function focusItem(item: MenuItemRegistration | undefined) {
    if (!item) return;
    activeId = item.id;
    item.node.focus();
  }

  const context: MenuContext = {
    get id() { return id; },
    get open() { return open; },
    get activeId() { return activeId; },
    setOpen(next, options) {
      if (open === next) return;
      open = next;
      onopenchange?.(next);
      if (!next) {
        activeId = undefined;
        return;
      }
      const focus = options?.focus ?? 'none';
      if (focus === 'none') return;
      queueMicrotask(() => focusItem(focus === 'last' ? enabled.at(-1) : enabled[0]));
    },
    toggle() { context.setOpen(!open, { focus: open ? 'none' : 'first' }); },
    register(item) {
      /* Registration runs inside each item's effect; untrack keeps the shared list out of that effect's dependencies. */
      untrack(() => { items = [...items, item]; });
      return () => untrack(() => {
        items = items.filter((candidate) => candidate.id !== item.id);
        if (activeId === item.id) activeId = undefined;
      });
    },
    activate(next) { activeId = next; },
    move(delta) {
      if (!enabled.length) return;
      const current = enabled.findIndex((item) => item.id === activeId);
      const index = current < 0 ? (delta > 0 ? 0 : enabled.length - 1) : (current + delta + enabled.length) % enabled.length;
      focusItem(enabled[index]);
    },
    moveTo(position) { focusItem(position === 'first' ? enabled[0] : enabled.at(-1)); },
    typeahead(character) {
      clearTimeout(searchTimer);
      search += character.toLocaleLowerCase();
      searchTimer = setTimeout(() => { search = ''; }, typeaheadTimeout);

      /* APG behavior: repeating one character cycles the items starting with it instead of searching a longer prefix. */
      const repeated = search.length > 1 && [...search].every((entry) => entry === search[0]);
      const query = repeated ? search[0] : search;
      const from = enabled.findIndex((item) => item.id === activeId);
      const rotate = search.length === 1 || repeated;
      const ordered = rotate && from >= 0
        ? [...enabled.slice(from + 1), ...enabled.slice(0, from + 1)]
        : enabled;
      const match = ordered.find((item) => item.label.toLocaleLowerCase().startsWith(query));
      if (match) focusItem(match);
    },
    select(selected) {
      onselect?.(selected);
      context.setOpen(false);
      context.focusTrigger();
    },
    focusTrigger() { trigger?.focus(); },
    setTrigger(node) { trigger = node; }
  };

  setMenuContext(context);
</script>

<div class="menu-root" data-open={open}>
  {@render children()}
</div>

<style>
  .menu-root { position: relative; display: inline-flex; }
</style>
