import { getContext, setContext } from 'svelte';

const KEY = Symbol('bracket-menu');

export interface MenuItemRegistration {
  id: string;
  label: string;
  disabled: boolean;
  node: HTMLElement;
}

export interface MenuContext {
  readonly id: string;
  readonly open: boolean;
  readonly activeId: string | undefined;
  setOpen(open: boolean, options?: { focus?: 'first' | 'last' | 'none' }): void;
  toggle(): void;
  register(item: MenuItemRegistration): () => void;
  activate(id: string): void;
  move(delta: number): void;
  moveTo(position: 'first' | 'last'): void;
  typeahead(character: string): void;
  select(id: string): void;
  focusTrigger(): void;
  setTrigger(node: HTMLElement | null): void;
}

export function setMenuContext(context: MenuContext): void {
  setContext(KEY, context);
}

export function getMenuContext(): MenuContext {
  const context = getContext<MenuContext | undefined>(KEY);
  if (!context) throw new Error('Menu parts must be rendered inside <Menu.Root>');
  return context;
}
