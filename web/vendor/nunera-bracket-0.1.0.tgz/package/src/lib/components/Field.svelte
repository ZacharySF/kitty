<script lang="ts">
  import type { Snippet } from 'svelte';
  import { getMessages } from '../headless/messages';

  export interface FieldControlProps {
    id?: string;
    required?: boolean;
    disabled?: boolean;
    readonly?: boolean;
    'aria-invalid'?: 'true';
    'aria-describedby'?: string;
    'aria-errormessage'?: string;
  }

  interface Props {
    label?: string;
    for?: string;
    description?: string;
    error?: string;
    required?: boolean;
    optional?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    invalid?: boolean;
    counter?: string;
    children: Snippet<[FieldControlProps]>;
    class?: string;
  }

  let { label, for: htmlFor, description, error, required = false, optional = false, disabled = false, readOnly = false, invalid = false, counter, children, class: className = '' }: Props = $props();
  const messages = $derived(getMessages());
  const descriptionId = $derived(htmlFor && description ? `${htmlFor}-description` : undefined);
  const errorId = $derived(htmlFor && error ? `${htmlFor}-error` : undefined);
  const describedBy = $derived([descriptionId, errorId].filter(Boolean).join(' ') || undefined);
  const control = $derived<FieldControlProps>({
    id: htmlFor,
    required: required || undefined,
    disabled: disabled || undefined,
    readonly: readOnly || undefined,
    'aria-invalid': error || invalid ? 'true' : undefined,
    'aria-describedby': describedBy,
    'aria-errormessage': errorId
  });
</script>

<div class={['br-field', className]} data-invalid={Boolean(error || invalid)} data-disabled={disabled} data-readonly={readOnly}>
  {#if label}
    <label class="br-field__label" for={htmlFor}>
      {label}
      {#if required}<span class="br-field__required" aria-hidden="true">*</span>{/if}
      {#if optional}<small>{messages.optional}</small>{/if}
      {#if counter}<small>{counter}</small>{/if}
    </label>
  {/if}
  {@render children(control)}
  {#if description}<div class="br-field__description" id={descriptionId}>{description}</div>{/if}
  {#if error}<div class="br-field__error" id={errorId} role="alert">{error}</div>{/if}
</div>
