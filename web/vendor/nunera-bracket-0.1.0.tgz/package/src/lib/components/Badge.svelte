<script lang="ts">
  import type { HTMLAttributes } from 'svelte/elements';
  import type { Intent } from '../types';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type BadgePart = 'root';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    label: string;
    intent?: Intent;
    size?: 'sm' | 'md' | 'lg';
    variant?: 'pill' | 'dot';
    pulse?: boolean;
    count?: number;
    max?: number;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<BadgePart>;
    styles?: PartOverrides<BadgePart>;
  }
  let { as = 'span', label, intent = 'primary', size = 'md', variant = 'pill', pulse = false, count, max = 99, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(['br-badge', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} data-intent={intent} data-size={size} data-variant={variant} data-pulse={pulse}>{#if variant === 'dot'}<i aria-hidden="true"></i>{/if}{label}{#if count !== undefined} {count > max ? `${max}+` : count}{/if}</svelte:element>
<style>.br-badge[data-size='sm']{font-size:var(--br-text-xs)}.br-badge[data-size='lg']{padding:var(--br-space-2) var(--br-space-3);font-size:var(--br-text-sm)}.br-badge[data-variant='dot']{display:inline-flex;align-items:center;gap:var(--br-space-1);background:transparent}.br-badge i{width:7px;height:7px;border-radius:50%;background:currentColor}</style>
