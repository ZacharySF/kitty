<script lang="ts">
  export interface LocaleOption { value:string; label:string }
  interface Props { locales:LocaleOption[]; value?:string; label?:string; onchange?:(value:string)=>void }
  let { locales,value=$bindable(),label='Language',onchange }:Props=$props();
</script>
<label><span>{label}</span><select bind:value onchange={(event)=>onchange?.(event.currentTarget.value)}>{#each locales as locale (locale.value)}<option value={locale.value}>{locale.label}</option>{/each}</select></label>
<style>label{display:flex;align-items:center;gap:var(--br-space-2)}span{color:var(--br-mute)}select{padding:var(--br-space-2);border:1px solid var(--br-line);background:var(--br-field);color:var(--br-ink)}</style>
