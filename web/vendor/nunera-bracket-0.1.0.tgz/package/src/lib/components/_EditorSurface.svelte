<script lang="ts">
  export type EditorMode = 'rich-text-editor' | 'markdown-editor' | 'code-editor' | 'diff-viewer' | 'node-editor-flow-canvas' | 'whiteboard-infinite-canvas' | 'drawing-canvas' | 'terminal-emulator';
  export interface EditorSurfaceProps {
    mode: EditorMode;
    value?: string;
    readonly?: boolean;
    theme?: 'dark' | 'light';
    label?: string;
    oninput?: (value: string) => void;
    onsubmit?: (value: string) => void;
  }

  let { mode, value = $bindable(''), readonly = false, theme = 'dark', label = 'Editor', oninput, onsubmit }: EditorSurfaceProps = $props();
  let markdownView = $state<'write' | 'preview' | 'split'>('split');
  let diffLayout = $state<'unified' | 'side-by-side'>('side-by-side');
  let zoom = $state(100);
  let terminalInput = $state('');
  let color = $state('#38bdf8');
  let brushSize = $state(4);
  let erasing = $state(false);
  let canvas = $state<HTMLCanvasElement>();
  let drawing = false;
  let snapshots: ImageData[] = [];

  const source = $derived(value || (mode === 'code-editor' ? 'const relay = true;\nconsole.log(relay);' : mode === 'markdown-editor' ? '# Mission\n\n**Telemetry** online.' : 'Telemetry online'));
  const codeLines = $derived(source.split('\n'));

  function command(name: string, commandValue?: string) {
    if (typeof document !== 'undefined') document.execCommand(name, false, commandValue);
  }
  function update(next: string) {
    value = next;
    oninput?.(next);
  }
  function pastePlain(event: ClipboardEvent) {
    event.preventDefault();
    command('insertText', event.clipboardData?.getData('text/plain') ?? '');
  }
  function applyMarkdown(token: string) {
    update(`${token}${source}${token}`);
  }
  function draw(event: PointerEvent) {
    if (!drawing || !canvas) return;
    const bounds = canvas.getBoundingClientRect();
    const context = canvas.getContext('2d');
    if (!context) return;
    context.lineTo(event.clientX - bounds.left, event.clientY - bounds.top);
    context.strokeStyle = erasing ? '#0b1017' : color;
    context.lineWidth = brushSize;
    context.lineCap = 'round';
    context.stroke();
  }
  function beginDraw(event: PointerEvent) {
    if (!canvas) return;
    const context = canvas.getContext('2d');
    if (!context) return;
    snapshots.push(context.getImageData(0, 0, canvas.width, canvas.height));
    const bounds = canvas.getBoundingClientRect();
    context.beginPath();
    context.moveTo(event.clientX - bounds.left, event.clientY - bounds.top);
    drawing = true;
  }
  function undoDrawing() {
    const previous = snapshots.pop();
    const context = canvas?.getContext('2d');
    if (previous && context) context.putImageData(previous, 0, 0);
  }
  function submitTerminal() {
    const next = terminalInput.trim();
    if (!next) return;
    onsubmit?.(next);
    value = `${value}\n\u001b[32m$ ${next}\u001b[0m`;
    terminalInput = '';
  }
</script>

<section class="editor-surface" data-module={mode}>
  {#if mode === 'rich-text-editor'}
    <div class="toolbar" role="toolbar" aria-label="Rich text formatting">
      <button type="button" aria-label="Bold" onclick={() => command('bold')}><b>B</b></button>
      <button type="button" aria-label="Italic" onclick={() => command('italic')}><i>I</i></button>
      <button type="button" aria-label="Underline" onclick={() => command('underline')}><u>U</u></button>
      <button type="button" aria-label="Heading" onclick={() => command('formatBlock', 'h2')}>H2</button>
      <button type="button" aria-label="Bulleted list" onclick={() => command('insertUnorderedList')}>LIST</button>
      <button type="button" aria-label="Insert link" onclick={() => command('createLink', '#')}>LINK</button>
      <button type="button" aria-label="Undo" onclick={() => command('undo')}>UNDO</button>
      <button type="button" aria-label="Redo" onclick={() => command('redo')}>REDO</button>
    </div>
    <div class="rich-editor" contenteditable={!readonly} role="textbox" aria-label={label} aria-multiline="true" onpaste={pastePlain} oninput={(event) => update(event.currentTarget.innerHTML)}>{source}</div>
    <output aria-label="HTML output">{value || source}</output>
    <output aria-label="JSON output">{JSON.stringify({ html: value || source })}</output>
  {:else if mode === 'markdown-editor'}
    <div class="toolbar" role="toolbar" aria-label="Markdown formatting">
      <button type="button" aria-label="Bold" onclick={() => applyMarkdown('**')}>B</button>
      <button type="button" aria-label="Write markdown" onclick={() => markdownView = 'write'}>WRITE</button>
      <button type="button" aria-label="Preview markdown" onclick={() => markdownView = 'preview'}>PREVIEW</button>
      <button type="button" aria-label="Split markdown" onclick={() => markdownView = 'split'}>SPLIT</button>
    </div>
    <div class="split">
      {#if markdownView !== 'preview'}<textarea aria-label="Markdown source" value={source} oninput={(event) => update(event.currentTarget.value)}></textarea>{/if}
      {#if markdownView !== 'write'}<article class="preview" aria-label="Markdown preview"><pre>{source}</pre></article>{/if}
    </div>
  {:else if mode === 'code-editor'}
    <div class="code-editor" data-theme={theme}>
      {#each codeLines as line, index (index)}
        <div><span class="line-number">{index + 1}</span><code class:keyword={/\b(const|let|function|return)\b/.test(line)}>{line || ' '}</code></div>
      {/each}
      {#if !readonly}<textarea aria-label="Code source" value={source} oninput={(event) => update(event.currentTarget.value)}></textarea>{/if}
    </div>
  {:else if mode === 'diff-viewer'}
    <label>Layout <select aria-label="Diff layout" bind:value={diffLayout}><option value="side-by-side">Side by side</option><option value="unified">Unified</option></select></label>
    <div class:side-by-side={diffLayout === 'side-by-side'} class="diff">
      <pre class="removed">− timeout = 20</pre><pre class="added">+ timeout = 30</pre>
    </div>
  {:else if mode === 'node-editor-flow-canvas'}
    <div class="zoom-controls"><button type="button" aria-label="Zoom out" onclick={() => zoom = Math.max(50, zoom - 10)}>−</button><output>{zoom}%</output><button type="button" aria-label="Zoom in" onclick={() => zoom = Math.min(200, zoom + 10)}>+</button></div>
    <div class="flow-canvas" style:--zoom={zoom / 100} role="application" aria-label="Node editor canvas">
      <svg viewBox="0 0 320 120" aria-hidden="true"><path class="edge" d="M90 60 C140 60 160 60 210 60" /></svg>
      <button class="node first" draggable="true" type="button"><span class="handle"></span>INPUT</button>
      <button class="node second" draggable="true" type="button"><span class="handle"></span>OUTPUT</button>
    </div>
  {:else if mode === 'whiteboard-infinite-canvas'}
    <div class="toolbar" role="toolbar" aria-label="Whiteboard tools"><button type="button" aria-label="Select tool">SELECT</button><button type="button" aria-label="Shape tool">SHAPE</button><button type="button" aria-label="Text tool">TEXT</button><button type="button" aria-label="Freehand tool">DRAW</button><button type="button" aria-label="Zoom in" onclick={() => zoom += 10}>+</button></div>
    <svg class="whiteboard" viewBox="0 0 320 140" role="img" aria-label="Infinite whiteboard"><rect class="shape" x="30" y="25" width="95" height="55"/><text x="50" y="56">Relay</text><path class="freehand" d="M150 75q30-50 70 0t65-5"/><circle class="selection" cx="125" cy="80" r="5"/></svg>
  {:else if mode === 'drawing-canvas'}
    <div class="toolbar" role="toolbar" aria-label="Drawing tools"><input type="color" aria-label="Brush color" bind:value={color}/><input type="range" aria-label="Brush size" min="1" max="30" bind:value={brushSize}/><button type="button" aria-label="Eraser" aria-pressed={erasing} onclick={() => erasing = !erasing}>ERASE</button><button type="button" aria-label="Undo drawing" onclick={undoDrawing}>UNDO</button></div>
    <canvas bind:this={canvas} width="640" height="240" onpointerdown={beginDraw} onpointermove={draw} onpointerup={() => drawing = false} onpointerleave={() => drawing = false} aria-label="Drawing canvas"></canvas>
  {:else}
    <div class="terminal-output" role="log" aria-live="polite"><span class="ansi-green">operator@bracket:~$</span> status<br/><span class="ansi-blue">relay-04</span> online{#if value}<br/>{value.replace(/\u001b\[[0-9;]*m/g, '')}{/if}</div>
    <form onsubmit={(event) => { event.preventDefault(); submitTerminal(); }}><span aria-hidden="true">$</span><input aria-label="Terminal input" bind:value={terminalInput}/></form>
  {/if}
</section>

<style>
  .editor-surface { display: grid; gap: 6px; min-height: 120px; padding: 7px; border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-text); font: 10px/1.45 var(--br-font-mono); }
  button, select, input, textarea { border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; }
  button { padding: 3px 6px; cursor: pointer; }
  button:focus-visible, input:focus-visible, textarea:focus-visible, [contenteditable]:focus-visible { outline: 1px solid var(--br-signal); outline-offset: 1px; }
  .toolbar, .zoom-controls { display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
  .rich-editor, textarea, .preview { min-height: 76px; padding: 7px; border: 1px solid var(--br-line); background: var(--br-surface); }
  output { overflow: hidden; color: var(--br-mute); white-space: nowrap; text-overflow: ellipsis; }
  .split { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 6px; }
  textarea { width: 100%; resize: vertical; }
  pre { margin: 0; white-space: pre-wrap; }
  .code-editor { position: relative; display: grid; padding: 7px; background: #081018; color: #d7e5ef; }
  .code-editor[data-theme='light'] { background: #eef4f8; color: #15222d; }
  .code-editor > div { display: grid; grid-template-columns: 25px 1fr; }
  .line-number { color: var(--br-mute); user-select: none; }
  code.keyword { color: var(--br-signal); }
  .code-editor textarea { margin-top: 6px; color: inherit; }
  .diff { display: grid; gap: 4px; }
  .diff.side-by-side { grid-template-columns: 1fr 1fr; }
  .removed { padding: 7px; background: color-mix(in srgb, var(--br-danger) 18%, transparent); color: var(--br-danger); }
  .added { padding: 7px; background: color-mix(in srgb, var(--br-success) 18%, transparent); color: var(--br-success); }
  .flow-canvas { position: relative; height: 120px; overflow: hidden; background-image: radial-gradient(var(--br-line) 1px, transparent 1px); background-size: calc(12px * var(--zoom)) calc(12px * var(--zoom)); }
  .flow-canvas svg { position: absolute; inset: 0; width: 100%; height: 100%; }
  .edge { fill: none; stroke: var(--br-signal); stroke-width: 2; }
  .node { position: absolute; top: 42px; width: 80px; height: 36px; border-color: var(--br-structure); }
  .node.first { left: 20px; }.node.second { right: 20px; }.handle { display: inline-block; width: 6px; height: 6px; margin-right: 4px; border-radius: 50%; background: var(--br-signal); }
  .whiteboard { width: 100%; background: var(--br-surface); touch-action: none; }.shape { fill: var(--br-raised); stroke: var(--br-structure); }.freehand { fill: none; stroke: var(--br-signal); stroke-width: 3; }.selection { fill: var(--br-warning); }
  canvas { width: 100%; height: 120px; background: #0b1017; touch-action: none; }
  .terminal-output { min-height: 80px; padding: 7px; background: #05090d; color: #d4e4ee; white-space: pre-wrap; }.ansi-green { color: #5ee09b; }.ansi-blue { color: #69b7ff; }
  form { display: flex; gap: 6px; } form input { flex: 1; }
</style>
