<script lang="ts">
  import type { Snippet } from 'svelte';
  import { MediaQuery } from 'svelte/reactivity';

  interface Props {
    children: Snippet;
    /** Media query; parentheses are added when omitted. Takes precedence over `above`/`below`. */
    query?: string;
    /** Render only at or above this width, e.g. `48rem`. */
    above?: string;
    /** Render only below this width, e.g. `48rem`. */
    below?: string;
    /** Value used during SSR and before the first client match. */
    ssr?: boolean;
    fallback?: Snippet;
  }

  let { children, query, above, below, ssr = false, fallback }: Props = $props();

  const resolved = $derived(
    query ??
      [above && `(min-width: ${above})`, below && `(max-width: calc(${below} - 0.02px))`].filter(Boolean).join(' and ')
  );
  const media = $derived(new MediaQuery(resolved, ssr));
  const matches = $derived(resolved ? media.current : ssr);
</script>

{#if matches}
  {@render children()}
{:else if fallback}
  {@render fallback()}
{/if}
