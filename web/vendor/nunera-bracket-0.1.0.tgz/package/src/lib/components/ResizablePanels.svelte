<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';

  interface Props extends HTMLAttributes<HTMLDivElement> {
    first: Snippet;
    second: Snippet;
    orientation?: 'horizontal' | 'vertical';
    defaultSize?: number;
    size?: number;
    minSize?: number;
    maxSize?: number;
    onsizechange?: (size: number) => void;
    ref?: HTMLDivElement | null;
  }
  let { first, second, orientation = 'horizontal', defaultSize = 50, size = $bindable(defaultSize), minSize = 10, maxSize = 90, onsizechange, ref = $bindable(null), style = '', ...rest }: Props = $props();
  let dragging = $state(false);

  function setSize(next: number) {
    const bounded = Math.min(maxSize, Math.max(minSize, Math.round(next * 100) / 100));
    if (bounded === size) return;
    size = bounded;
    onsizechange?.(bounded);
  }
  function move(event: PointerEvent) {
    if (!dragging || !ref) return;
    const rect = ref.getBoundingClientRect();
    const position = orientation === 'horizontal' ? event.clientX - rect.left : event.clientY - rect.top;
    const total = orientation === 'horizontal' ? rect.width : rect.height;
    if (total > 0) setSize(position / total * 100);
  }
  function stop() {
    dragging = false;
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', stop);
  }
  function start() {
    dragging = true;
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop, { once: true });
  }
  function keydown(event: KeyboardEvent) {
    const backward = orientation === 'horizontal' ? 'ArrowLeft' : 'ArrowUp';
    const forward = orientation === 'horizontal' ? 'ArrowRight' : 'ArrowDown';
    if (event.key === backward) { event.preventDefault(); setSize(size - 1); }
    if (event.key === forward) { event.preventDefault(); setSize(size + 1); }
    if (event.key === 'Home') { event.preventDefault(); setSize(minSize); }
    if (event.key === 'End') { event.preventDefault(); setSize(maxSize); }
  }
  function splitter(node: HTMLElement) {
    node.tabIndex = 0;
    node.addEventListener('pointerdown', start);
    node.addEventListener('keydown', keydown);
    return {
      destroy() {
        node.removeEventListener('pointerdown', start);
        node.removeEventListener('keydown', keydown);
      }
    };
  }
  const layoutStyle = $derived(orientation === 'horizontal'
    ? `grid-template-columns:minmax(0,${size}fr) auto minmax(0,${100 - size}fr);${style}`
    : `grid-template-rows:minmax(0,${size}fr) auto minmax(0,${100 - size}fr);${style}`);
</script>

<div {...rest} bind:this={ref} class="panels" class:vertical={orientation === 'vertical'} data-testid="resizable-panels" data-dragging={dragging} style={layoutStyle}>
  <div class="panel">{@render first()}</div>
  <!-- WAI-ARIA Window Splitter is a focusable separator; the action owns its input listeners. -->
  <div class="handle" role="separator" aria-label="Resize panels" aria-orientation={orientation} aria-valuemin={minSize} aria-valuemax={maxSize} aria-valuenow={Math.round(size)} use:splitter></div>
  <div class="panel">{@render second()}</div>
</div>

<style>
  .panels { display: grid; min-width: 0; min-height: 0; }
  .panel { min-width: 0; min-height: 0; overflow: auto; }
  .handle { width: 8px; min-height: 24px; padding: 0; border: 0; border-inline: 1px solid var(--br-line); background: var(--br-inset); cursor: col-resize; }
  .vertical .handle { width: auto; height: 8px; min-height: 0; border-inline: 0; border-block: 1px solid var(--br-line); cursor: row-resize; }
  .handle:hover, .handle:focus-visible, [data-dragging='true'] .handle { background: var(--br-structure-wash); border-color: var(--br-signal); }
</style>
