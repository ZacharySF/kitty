<script lang="ts" generics="T extends string">
  import type { HTMLSelectAttributes } from 'svelte/elements';
  import type { Option } from '../types';

  interface Props<T> extends Omit<HTMLSelectAttributes, 'value' | 'onchange'> {
    value?: T | T[];
    options: Option<T>[];
    placeholder?: string;
    name?: string;
    disabled?: boolean;
    invalid?: boolean;
    multiple?: boolean;
    onchange?: (value: T | T[]) => void;
  }

  let {
    value = $bindable(),
    options,
    placeholder,
    name,
    disabled = false,
    invalid = false,
    multiple = false,
    onchange,
    ...rest
  }: Props<T> = $props();

  const groups = $derived([...new Set(options.map((option) => option.group).filter((group): group is string => Boolean(group)))]);

  function change(event: Event) {
    const select = event.currentTarget as HTMLSelectElement;
    value = multiple
      ? Array.from(select.selectedOptions, (option) => option.value as T)
      : select.value as T;
    onchange?.(value);
  }
</script>

<div class="br-control" data-invalid={invalid}>
  <select {...rest} {name} {disabled} {multiple} aria-invalid={invalid} value={multiple ? undefined : value} onchange={change}>
    {#if placeholder && !multiple}<option value="" disabled>{placeholder}</option>{/if}
    {#each groups as group (group)}
      <optgroup label={group}>
        {#each options.filter((option) => option.group === group) as option (option.value)}
          <option value={option.value} disabled={option.disabled} selected={multiple && Array.isArray(value) && value.includes(option.value)}>{option.label}</option>
        {/each}
      </optgroup>
    {/each}
    {#each options.filter((option) => !option.group) as option (option.value)}
      <option value={option.value} disabled={option.disabled} selected={multiple && Array.isArray(value) && value.includes(option.value)}>{option.label}</option>
    {/each}
  </select>
</div>
