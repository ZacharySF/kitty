<script lang="ts" generics="T extends string">
  import type { Option, Orientation } from '../types';

  interface Props<T> { value?: T; options: Option<T>[]; orientation?: Orientation; label?: string; name?: string; onchange?: (value: T) => void }

  let { value = $bindable(), options, orientation = 'vertical', label, name, onchange }: Props<T> = $props();
  let focused = $state(-1);
  const instanceId = $props.id();

  $effect(() => {
    const selected = options.findIndex((option) => option.value === value && !option.disabled);
    focused = selected >= 0 ? selected : options.findIndex((option) => !option.disabled);
  });

  function select(option: Option<T> | undefined, index: number) {
    if (!option || option.disabled) return;
    value = option.value;
    focused = index;
    onchange?.(option.value);
  }

  function keydown(event: KeyboardEvent) {
    const direction = event.key === 'ArrowRight' || event.key === 'ArrowDown'
      ? 1
      : event.key === 'ArrowLeft' || event.key === 'ArrowUp'
        ? -1
        : 0;
    if (!direction || focused < 0) return;
    event.preventDefault();

    for (let offset = 1; offset <= options.length; offset += 1) {
      const index = (focused + direction * offset + options.length) % options.length;
      if (options[index]?.disabled) continue;
      select(options[index], index);
      document.getElementById(`${instanceId}-radio-${index}`)?.focus();
      return;
    }
  }
</script>

<div class="br-radio-group" data-orientation={orientation} role="radiogroup" aria-label={label} tabindex="-1" onkeydown={keydown}>
  {#each options as option, index (option.value)}
    <button
      id={`${instanceId}-radio-${index}`}
      type="button"
      class="br-radio"
      role="radio"
      aria-checked={value === option.value}
      disabled={option.disabled}
      tabindex={focused === index ? 0 : -1}
      onclick={() => select(option, index)}
    >
      <i class="br-radio__mark"></i>
      <span>{option.label}{#if option.description}<small>{option.description}</small>{/if}</span>
    </button>
  {/each}
</div>
{#if name}<input type="hidden" {name} value={value ?? ''} />{/if}
