<script lang="ts">
  import type { Snippet } from 'svelte';
  import { getMessages } from '../headless/messages';

  interface Props {
    children: Snippet;
    prefix?: Snippet;
    suffix?: Snippet;
    actions?: Snippet;
    clearable?: boolean;
    onclear?: () => void;
    class?: string;
  }

  let { children, prefix, suffix, actions, clearable = false, onclear, class: className = '' }: Props = $props();
  const messages = $derived(getMessages());
</script>

<div class={['br-input-group', className]}>
  {#if prefix}<span class="addon prefix">{@render prefix()}</span>{/if}
  <div class="control">{@render children()}</div>
  {#if clearable}<button type="button" class="clear" aria-label={messages.clearInput} onclick={() => onclear?.()}>×</button>{/if}
  {#if suffix}<span class="addon suffix">{@render suffix()}</span>{/if}
  {#if actions}<span class="actions">{@render actions()}</span>{/if}
</div>

<style>
  .br-input-group { display: flex; align-items: stretch; min-width: 0; }
  .control { flex: 1 1 auto; min-width: 0; }
  .control :global(.br-control), .control :global(input), .control :global(select), .control :global(textarea) { width: 100%; height: 100%; }
  .addon, .clear { display: inline-grid; place-items: center; flex: none; min-width: 32px; padding-inline: var(--br-space-2); border: 1px solid var(--br-line); background: var(--br-inset); color: var(--br-mute); }
  .clear { cursor: pointer; }
  .actions { display: inline-flex; }
  .br-input-group > :global(*) + :global(*), .actions :global(*) + :global(*) { margin-inline-start: -1px; }
</style>
