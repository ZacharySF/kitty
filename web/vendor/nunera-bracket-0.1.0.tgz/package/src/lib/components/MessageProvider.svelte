<script lang="ts">
  import type { Snippet } from 'svelte';
  import { setMessages, type BracketMessages } from '../headless/messages';

  interface Props { messages: Partial<BracketMessages>; children: Snippet }
  let { messages, children }: Props = $props();
  setMessages(new Proxy({} as Partial<BracketMessages>, { get: (_, key) => Reflect.get(messages, key) }));
</script>
{@render children()}
