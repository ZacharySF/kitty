<script lang="ts">
  import { onMount } from 'svelte';
  export interface TocItem { id:string; label:string; level?:number }
  interface Props { items:TocItem[]; active?:string; label?:string }
  let { items,active=$bindable(),label='Table of contents' }:Props=$props();
  onMount(()=>{if(!globalThis.IntersectionObserver)return;const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting)active=(entry.target as HTMLElement).id;},{rootMargin:'0px 0px -70%'});for(const item of items){const element=document.getElementById(item.id);if(element)observer.observe(element);}return()=>observer.disconnect();});
</script>
<nav aria-label={label}><ol>{#each items as item (item.id)}<li style:--level={item.level??1}><a href={`#${item.id}`} aria-current={active===item.id?'location':undefined}>{item.label}</a></li>{/each}</ol></nav>
<style>ol{display:grid;gap:var(--br-space-1);margin:0;padding:0;list-style:none}li{padding-inline-start:calc((var(--level) - 1)*var(--br-space-3))}a{display:block;padding:var(--br-space-1) var(--br-space-2);border-inline-start:2px solid transparent;color:var(--br-mute);text-decoration:none}a[aria-current='location']{border-color:var(--br-signal);color:var(--br-signal)}</style>
