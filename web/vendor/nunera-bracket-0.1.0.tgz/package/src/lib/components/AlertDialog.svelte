<script lang="ts">
  import { tick } from 'svelte';
  interface Props { open?: boolean; title: string; description?: string; confirmLabel?: string; cancelLabel?: string; destructive?: boolean; onconfirm?: () => void; oncancel?: () => void }
  let { open = $bindable(false), title, description, confirmLabel, cancelLabel = 'Cancel', destructive = false, onconfirm, oncancel }: Props = $props();
  let cancelButton = $state<HTMLButtonElement>();
  const effectiveConfirm = $derived(confirmLabel ?? (destructive ? 'Delete' : 'Confirm'));
  $effect(() => { if (open && destructive) tick().then(() => cancelButton?.focus()); });
  function cancel() { open = false; oncancel?.(); }
  function confirm() { open = false; onconfirm?.(); }
  function keydown(event: KeyboardEvent) { if (event.key === 'Escape') { event.preventDefault(); cancel(); } }
</script>
{#if open}<div class="layer"><div class="backdrop" data-testid="alert-dialog-backdrop"></div><div class="dialog" role="alertdialog" aria-modal="true" aria-label={title} tabindex="-1" onkeydown={keydown}><h2>{title}</h2>{#if description}<p>{description}</p>{/if}<footer><button bind:this={cancelButton} type="button" class="br-btn" onclick={cancel}>{cancelLabel}</button><button type="button" class="br-btn" data-intent={destructive ? 'danger' : 'primary'} onclick={confirm}>{effectiveConfirm}</button></footer></div></div>{/if}
<style>.layer{position:fixed;inset:0;z-index:var(--br-z-modal);display:grid;place-items:center}.backdrop{position:absolute;inset:0;background:color-mix(in srgb,var(--br-void) 78%,transparent)}.dialog{position:relative;display:grid;gap:var(--br-space-3);width:min(440px,calc(100vw - 24px));padding:var(--br-space-5);border:1px solid var(--br-lineHot);background:var(--br-panel)}h2,p{margin:0}p{color:var(--br-mute)}footer{display:flex;justify-content:flex-end;gap:var(--br-space-2)}</style>
