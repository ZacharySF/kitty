<script lang="ts">
  export interface MenubarItem { id: string; label: string; disabled?: boolean; action: () => void }
  export interface MenubarMenu { id: string; label: string; items: MenubarItem[] }
  interface Props { menus: MenubarMenu[]; label?: string }
  let { menus, label = 'Application menu' }: Props = $props();
  let open = $state<string>();
  let active = $state(0);
  let root: HTMLElement;
  function focusMenu(index:number){active=(index+menus.length)%menus.length;root.querySelectorAll<HTMLButtonElement>('.trigger')[active]?.focus();if(open)open=menus[active]?.id;}
  function keydown(event:KeyboardEvent){if(event.key==='ArrowRight'){event.preventDefault();focusMenu(active+1);}else if(event.key==='ArrowLeft'){event.preventDefault();focusMenu(active-1);}else if(event.key==='ArrowDown'){event.preventDefault();open=menus[active]?.id;queueMicrotask(()=>root.querySelector<HTMLButtonElement>('[role="menuitem"]:not(:disabled)')?.focus());}else if(event.key==='Escape'){open=undefined;root.querySelectorAll<HTMLButtonElement>('.trigger')[active]?.focus();}}
  function choose(item:MenubarItem){if(item.disabled)return;item.action();open=undefined;}
</script>
<div class="menubar" role="menubar" tabindex="-1" aria-label={label} bind:this={root} onkeydown={keydown}>
  {#each menus as menu,index (menu.id)}
    <div class="slot">
      <button type="button" class="trigger" role="menuitem" aria-haspopup="menu" aria-expanded={open===menu.id} tabindex={index===active?0:-1} onfocus={()=>active=index} onclick={()=>open=open===menu.id?undefined:menu.id}>{menu.label}</button>
      {#if open===menu.id}<div class="menu" role="menu" aria-label={menu.label}>{#each menu.items as item (item.id)}<button type="button" role="menuitem" disabled={item.disabled} onclick={()=>choose(item)}>{item.label}</button>{/each}</div>{/if}
    </div>
  {/each}
</div>
<style>.menubar{display:flex;gap:1px;border:1px solid var(--br-line);background:var(--br-panel)}.slot{position:relative}.trigger,.menu button{border:0;background:transparent;color:var(--br-ink)}.trigger{padding:var(--br-space-2) var(--br-space-3)}.trigger[aria-expanded='true'],.trigger:focus{background:var(--br-structure);color:var(--br-on-structure)}.menu{position:absolute;z-index:var(--br-z-popover);inset-block-start:100%;inset-inline-start:0;min-width:160px;padding:var(--br-space-1);border:1px solid var(--br-lineHot);background:var(--br-panel);box-shadow:var(--br-shadow-md)}.menu button{display:block;width:100%;padding:var(--br-space-2);text-align:start}.menu button:hover,.menu button:focus{background:var(--br-structure);color:var(--br-on-structure)}button:disabled{opacity:.45}</style>
