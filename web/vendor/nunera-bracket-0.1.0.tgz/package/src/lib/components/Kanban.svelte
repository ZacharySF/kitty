<script lang="ts">
  export interface KanbanCard { id: string; title: string; description?: string; tags?: string[] }
  export interface KanbanColumn { id: string; title: string; limit?: number; cards: KanbanCard[] }

  interface Props {
    columns?: KanbanColumn[];
    onmove?: (card: KanbanCard, from: string, to: string, index: number) => void;
  }

  let { columns = $bindable([]), onmove }: Props = $props();
  let dragging = $state<{ card: KanbanCard; from: string } | null>(null);

  function move(to: string, index: number) {
    if (!dragging || dragging.from === to) return;
    const source = columns.find((column) => column.id === dragging!.from);
    const target = columns.find((column) => column.id === to);
    if (!source || !target || (target.limit !== undefined && target.cards.length >= target.limit)) return;

    source.cards = source.cards.filter((card) => card.id !== dragging!.card.id);
    target.cards.splice(index, 0, dragging.card);
    columns = [...columns];
    onmove?.(dragging.card, dragging.from, to, index);
    dragging = null;
  }

  function shift(card: KanbanCard, from: string, offset: number) {
    const next = columns[columns.findIndex((column) => column.id === from) + offset];
    if (!next) return;
    dragging = { card, from };
    move(next.id, next.cards.length);
  }

  function keydown(event: KeyboardEvent, card: KanbanCard, from: string) {
    if (!event.altKey) return;
    if (event.key === 'ArrowRight') { event.preventDefault(); shift(card, from, 1); }
    else if (event.key === 'ArrowLeft') { event.preventDefault(); shift(card, from, -1); }
  }
</script>

<div class="board">
  {#each columns as column (column.id)}
    <section
      aria-label={column.title}
      ondragover={(event) => event.preventDefault()}
      ondrop={() => move(column.id, column.cards.length)}
    >
      <header>
        <b>{column.title}</b>
        <span class:limit={column.limit !== undefined && column.cards.length >= column.limit}>
          {column.cards.length}{#if column.limit !== undefined}/{column.limit}{/if}
        </span>
      </header>
      <ul>
        {#each column.cards as card (card.id)}
          <li>
            <button
              class="card"
              type="button"
              draggable="true"
              ondragstart={() => (dragging = { card, from: column.id })}
              ondragend={() => (dragging = null)}
              onkeydown={(event) => keydown(event, card, column.id)}
            >
              <b>{card.title}</b>
              {#if card.description}<p>{card.description}</p>{/if}
              {#if card.tags}<footer>{#each card.tags as tag (tag)}<span>{tag}</span>{/each}</footer>{/if}
            </button>
          </li>
        {/each}
      </ul>
    </section>
  {/each}
</div>

<style>
  .board { display: grid; grid-auto-flow: column; grid-auto-columns: minmax(220px, 1fr); gap: 7px; overflow: auto; }
  .board > section { border: 1px solid var(--br-line); background: var(--br-inset); }
  section > header { display: flex; justify-content: space-between; padding: 6px 7px; border-bottom: 1px solid var(--br-line); color: var(--br-mute); font-size: 9px; letter-spacing: .12em; text-transform: uppercase; }
  header span { color: var(--br-signal); }
  header span.limit { color: var(--br-danger); }
  ul { display: grid; gap: 5px; margin: 0; padding: 5px; min-height: 90px; list-style: none; }
  .card { display: block; width: 100%; padding: 7px; border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; text-align: left; cursor: grab; }
  .card:focus-visible { border-color: var(--br-signal); }
  .card b { font-size: 10px; }
  .card p { margin: 3px 0; font-size: 9px; }
  footer { display: flex; gap: 3px; flex-wrap: wrap; }
  footer span { padding: 1px 4px; border: 1px solid var(--br-line); color: var(--br-structure); font-size: 7px; }
</style>
