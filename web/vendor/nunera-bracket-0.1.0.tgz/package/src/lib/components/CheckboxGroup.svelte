<script lang="ts">
  import type { Option, Orientation } from '../types';
  import Checkbox from './Checkbox.svelte';

  interface Props { value?: string[]; options: Option<string>[]; orientation?: Orientation; label?: string; selectAll?: boolean; disabled?: boolean; onchange?: (value: string[]) => void }
  let { value = $bindable([]), options, orientation = 'vertical', label = 'Checkbox group', selectAll = false, disabled = false, onchange }: Props = $props();
  const enabled = $derived(options.filter((option) => !option.disabled).map((option) => option.value));
  const allChecked = $derived(enabled.length > 0 && enabled.every((item) => value.includes(item)));
  const someChecked = $derived(enabled.some((item) => value.includes(item)));

  function set(next: string[]) { value = next; onchange?.(value); }
  function toggle(option: Option<string>, checked: boolean) { if (checked) set([...value, option.value]); else set(value.filter((item) => item !== option.value)); }
  function toggleAll() { set(allChecked ? value.filter((item) => !enabled.includes(item)) : [...new Set([...value, ...enabled])]); }
</script>

<div class="checkbox-group" role="group" aria-label={label} data-orientation={orientation}>
  {#if selectAll}<Checkbox label="Select all" checked={allChecked ? true : someChecked ? 'indeterminate' : false} disabled={disabled || !enabled.length} onchange={toggleAll} />{/if}
  {#each options as option (option.value)}
    <Checkbox label={option.label} description={option.description} checked={value.includes(option.value)} disabled={disabled || option.disabled} onchange={(checked) => toggle(option, checked)} />
  {/each}
</div>

<style>.checkbox-group{display:flex;gap:var(--br-space-2)}.checkbox-group[data-orientation='vertical']{flex-direction:column}</style>
