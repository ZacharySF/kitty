<script lang="ts">
  import { onMount } from 'svelte';
  interface Props { load:()=>void|Promise<void>; hasMore?:boolean; loading?:boolean; label?:string; auto?:boolean }
  let { load,hasMore=true,loading=false,label='Load more',auto=true }:Props=$props();let sentinel:HTMLElement;
  async function more(){if(!hasMore||loading)return;await load();}
  onMount(()=>{if(!auto||!globalThis.IntersectionObserver)return;const observer=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting))void more();});observer.observe(sentinel);return()=>observer.disconnect();});
</script>
<div class="loader" bind:this={sentinel}>{#if hasMore}<button type="button" disabled={loading} onclick={more}>{loading?'Loading…':label}</button>{:else}<span>End of results</span>{/if}</div>
<style>.loader{display:grid;place-items:center;padding:var(--br-space-3)}button{padding:var(--br-space-2) var(--br-space-4);border:1px solid var(--br-line);background:var(--br-raised);color:var(--br-ink)}span{color:var(--br-dim)}</style>
