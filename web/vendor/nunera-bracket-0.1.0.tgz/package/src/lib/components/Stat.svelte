<script lang="ts">
  import type { HTMLAttributes } from 'svelte/elements';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type StatPart = 'root' | 'label' | 'value' | 'delta';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    label: string;
    value: string | number;
    delta?: number;
    comparison?: string;
    help?: string;
    lowerIsBetter?: boolean;
    goal?: number;
    current?: number;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<StatPart>;
    styles?: PartOverrides<StatPart>;
  }
  let { as = 'div', label, value, delta, comparison, help, lowerIsBetter = false, goal, current, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
  const positive = $derived(delta === undefined ? undefined : lowerIsBetter ? delta < 0 : delta > 0);
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(['stat', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')}><header class={partClass('', classes, 'label')} style={partStyle(undefined, styles, 'label')}>{label}{#if help}<abbr title={help}>?</abbr>{/if}</header><strong class={partClass('', classes, 'value')} style={partStyle(undefined, styles, 'value')}>{value}</strong>{#if delta !== undefined}<span class={partClass('', classes, 'delta')} style={partStyle(undefined, styles, 'delta')} class:positive class:negative={!positive}>{delta > 0 ? '↑' : delta < 0 ? '↓' : '→'} {Math.abs(delta)}% {comparison}</span>{/if}{#if goal !== undefined && current !== undefined}<div><i style:width={`${Math.min(100, current / goal * 100)}%`}></i></div><small>{current} / {goal}</small>{/if}</svelte:element>
<style>.stat{display:grid;gap:3px;padding:8px 9px;border:1px solid var(--br-line);background:var(--br-raised)}header{display:flex;justify-content:space-between;color:var(--br-mute);font-size:8px;letter-spacing:.14em;text-transform:uppercase}abbr{color:var(--br-signal)}strong{color:var(--br-ink);font-family:var(--br-font-display);font-size:24px;font-weight:400}span{font-size:9px}.positive{color:var(--br-go)}.negative{color:var(--br-danger)}div{height:4px;background:var(--br-line)}div i{display:block;height:100%;background:var(--br-go)}small{color:var(--br-dim);font-size:8px}</style>
