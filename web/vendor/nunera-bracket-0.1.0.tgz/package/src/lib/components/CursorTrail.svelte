<script lang="ts">
  import EffectSurface, { type EffectSurfaceProps } from './_EffectSurface.svelte';
  let props: Omit<EffectSurfaceProps, 'mode'> = $props();
</script>

<EffectSurface mode="custom-cursor-cursor-trail" {...props} />
