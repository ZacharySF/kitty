<script lang="ts">
  export interface ActionSheetItem { id: string; label: string; icon?: string; destructive?: boolean; disabled?: boolean; action: () => void }
  interface Props { open?: boolean; title?: string; items: ActionSheetItem[]; cancelLabel?: string; onclose?: () => void }
  let { open=$bindable(false), title='Actions', items, cancelLabel='Cancel', onclose }:Props=$props();
  function close(){open=false;onclose?.();}
  function choose(item:ActionSheetItem){if(item.disabled)return;item.action();close();}
</script>
{#if open}<div class="layer"><button class="backdrop" aria-label="Close action sheet" onclick={close}></button><div class="sheet" role="dialog" aria-modal="true" aria-label={title}><h2>{title}</h2>{#each items as item (item.id)}<button type="button" class:destructive={item.destructive} disabled={item.disabled} onclick={()=>choose(item)}>{#if item.icon}<span aria-hidden="true">{item.icon}</span>{/if}{item.label}</button>{/each}<button type="button" class="cancel" onclick={close}>{cancelLabel}</button></div></div>{/if}
<style>.layer{position:fixed;inset:0;z-index:var(--br-z-modal)}.backdrop{position:absolute;inset:0;border:0;background:color-mix(in srgb,var(--br-void) 70%,transparent)}.sheet{position:absolute;inset:auto var(--br-space-2) var(--br-space-2);display:grid;gap:1px;padding:var(--br-space-2);border:1px solid var(--br-lineHot);background:var(--br-panel);box-shadow:var(--br-shadow-lg)}h2{margin:var(--br-space-1);font-size:var(--br-text-sm)}.sheet>button{display:flex;gap:var(--br-space-2);justify-content:center;padding:var(--br-space-3);border:0;background:var(--br-raised);color:var(--br-ink)}.sheet>button.destructive{color:var(--br-danger)}.sheet>button:disabled{opacity:.45}.cancel{margin-block-start:var(--br-space-2);font-weight:700}</style>
