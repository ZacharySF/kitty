<script lang="ts">import type { Snippet } from 'svelte'; import type { HTMLAttributes } from 'svelte/elements'; interface Props extends HTMLAttributes<HTMLElement> { as?: string; children: Snippet } let { as = 'article', children, ...rest }: Props = $props();</script>
<svelte:element this={as} {...rest} class="br-prose">{@render children()}</svelte:element>
<style>
  .br-prose { color: var(--br-ink); line-height: 1.65; }
  .br-prose :global(> * + *) { margin-block-start: var(--br-space-5); }
  .br-prose :global(h1), .br-prose :global(h2), .br-prose :global(h3) { color: var(--br-ink); line-height: 1.2; }
  .br-prose :global(ul), .br-prose :global(ol) { padding-inline-start: var(--br-space-7); }
  .br-prose :global(table) { width: 100%; border-collapse: collapse; }
  .br-prose :global(th), .br-prose :global(td) { padding: var(--br-space-3); border: 1px solid var(--br-line); }
  .br-prose :global(code) { font-family: var(--br-font-ui); color: var(--br-caution); }
  .br-prose :global(img) { display: block; max-width: 100%; height: auto; }
</style>
