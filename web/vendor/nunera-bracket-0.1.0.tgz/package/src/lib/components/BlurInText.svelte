<script lang="ts">
  import EffectSurface, { type EffectSurfaceProps } from './_EffectSurface.svelte';
  let props: Omit<EffectSurfaceProps, 'mode'> = $props();
</script>

<EffectSurface mode="blur-in-text" {...props} />
