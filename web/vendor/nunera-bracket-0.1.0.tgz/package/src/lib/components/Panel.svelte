<script lang="ts">
  import type { Snippet } from 'svelte';
  import type { HTMLAttributes } from 'svelte/elements';
  import { partClass, partStyle, type PartOverrides } from '../headless/parts';

  export type PanelPart = 'root' | 'header' | 'readout' | 'body';

  interface Props extends HTMLAttributes<HTMLElement> {
    as?: string;
    title?: string;
    icon?: string;
    readout?: string | number;
    variant?: 'panel' | 'inset' | 'raised';
    children: Snippet;
    actions?: Snippet;
    class?: string;
    ref?: HTMLElement | null;
    classes?: PartOverrides<PanelPart>;
    styles?: PartOverrides<PanelPart>;
  }
  let { as = 'section', title, icon, readout, variant = 'panel', children, actions, class: className = '', ref = $bindable(null), classes, styles, ...rest }: Props = $props();
</script>
<svelte:element this={as} {...rest} bind:this={ref} class={partClass(['br-panel', className].filter(Boolean).join(' '), classes, 'root')} style={partStyle(undefined, styles, 'root')} data-variant={variant}>
  {#if title}<header class={partClass('br-panel__header', classes, 'header')} style={partStyle(undefined, styles, 'header')}>{#if icon}<i aria-hidden="true">{icon}</i>{/if}<span>{title}</span>{#if readout !== undefined}<span class={partClass('br-panel__readout', classes, 'readout')} style={partStyle(undefined, styles, 'readout')}>{readout}</span>{/if}{#if actions}{@render actions()}{/if}</header>{/if}
  <div class={partClass('', classes, 'body')} style={partStyle(undefined, styles, 'body')}>{@render children()}</div>
</svelte:element>
