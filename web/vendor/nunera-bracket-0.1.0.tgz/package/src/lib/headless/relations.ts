export interface RelationIds {
  root: string;
  label: string;
  description: string;
  error: string;
}

/** Derives stable ARIA relation IDs from a caller- or framework-owned base ID. */
export function relationIds(root: string): RelationIds {
  if (!root) throw new TypeError('A non-empty relation ID is required');
  return { root, label: `${root}-label`, description: `${root}-description`, error: `${root}-error` };
}

export function joinIds(...ids: Array<string | null | undefined | false>): string | undefined {
  let result = '';
  for (const id of ids) if (id) result += `${result ? ' ' : ''}${id}`;
  return result || undefined;
}
