export interface PressOptions {
  disabled?: boolean;
  onPress: (event: MouseEvent) => void;
  onPressStart?: (event: PointerEvent) => void;
  onPressEnd?: (event: PointerEvent) => void;
}

/** Svelte action that normalizes activation around the platform click event. */
export function press(node: HTMLElement, initial: PressOptions) {
  let options = initial;
  const previousAriaDisabled = node.getAttribute('aria-disabled');

  function syncDisabled() {
    if (options.disabled) node.setAttribute('aria-disabled', 'true');
    else if (previousAriaDisabled === null) node.removeAttribute('aria-disabled');
    else node.setAttribute('aria-disabled', previousAriaDisabled);
  }
  function click(event: MouseEvent) {
    if (options.disabled) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    options.onPress(event);
  }
  function pointerdown(event: PointerEvent) {
    if (options.disabled || event.button !== 0) return;
    node.dataset.pressed = '';
    options.onPressStart?.(event);
  }
  function pointerend(event: PointerEvent) {
    if (!('pressed' in node.dataset)) return;
    delete node.dataset.pressed;
    options.onPressEnd?.(event);
  }

  node.addEventListener('click', click, true);
  node.addEventListener('pointerdown', pointerdown);
  node.addEventListener('pointerup', pointerend);
  node.addEventListener('pointercancel', pointerend);
  syncDisabled();

  return {
    update(next: PressOptions) { options = next; syncDisabled(); },
    destroy() {
      node.removeEventListener('click', click, true);
      node.removeEventListener('pointerdown', pointerdown);
      node.removeEventListener('pointerup', pointerend);
      node.removeEventListener('pointercancel', pointerend);
      delete node.dataset.pressed;
      if (previousAriaDisabled === null) node.removeAttribute('aria-disabled');
      else node.setAttribute('aria-disabled', previousAriaDisabled);
    }
  };
}
