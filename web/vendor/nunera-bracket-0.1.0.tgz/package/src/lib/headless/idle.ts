export interface IdleVisibilityOptions { timeout?: number; events?: string[] }

export function createIdleVisibility(options: IdleVisibilityOptions = {}) {
  let idle = false;
  let visible = document.visibilityState !== 'hidden';
  let timer: ReturnType<typeof setTimeout>;
  const listeners = new Set<(state: { idle: boolean; visible: boolean }) => void>();
  const events = options.events ?? ['pointerdown', 'pointermove', 'keydown', 'scroll', 'touchstart'];

  function publish() { for (const listener of listeners) listener({ idle, visible }); }
  function reset() {
    const changed = idle;
    idle = false;
    clearTimeout(timer);
    timer = setTimeout(() => { idle = true; publish(); }, options.timeout ?? 60_000);
    if (changed) publish();
  }
  function visibility() { visible = document.visibilityState !== 'hidden'; publish(); }
  for (const event of events) window.addEventListener(event, reset, { passive: true });
  document.addEventListener('visibilitychange', visibility);
  reset();

  return {
    get idle() { return idle; },
    get visible() { return visible; },
    reset,
    subscribe(listener: (state: { idle: boolean; visible: boolean }) => void) { listeners.add(listener); listener({ idle, visible }); return () => listeners.delete(listener); },
    destroy() {
      clearTimeout(timer);
      for (const event of events) window.removeEventListener(event, reset);
      document.removeEventListener('visibilitychange', visibility);
      listeners.clear();
    }
  };
}
