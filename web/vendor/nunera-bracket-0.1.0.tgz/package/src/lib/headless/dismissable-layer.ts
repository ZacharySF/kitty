export interface DismissableLayerOptions {
  ondismiss: (reason: 'outside' | 'escape') => void;
  outside?: boolean;
  escape?: boolean;
}

interface Layer { node: HTMLElement; options: DismissableLayerOptions }
const layers: Layer[] = [];

export function dismissableLayer(node: HTMLElement, options: DismissableLayerOptions) {
  const layer: Layer = { node, options: { outside: true, escape: true, ...options } };
  layers.push(layer);

  function pointerdown(event: PointerEvent) {
    if (layers.at(-1) !== layer || layer.options.outside === false || node.contains(event.target as Node)) return;
    layer.options.ondismiss('outside');
  }

  function keydown(event: KeyboardEvent) {
    if (layers.at(-1) !== layer || layer.options.escape === false || event.key !== 'Escape') return;
    event.preventDefault();
    layer.options.ondismiss('escape');
  }

  document.addEventListener('pointerdown', pointerdown);
  document.addEventListener('keydown', keydown);
  return {
    update(next: DismissableLayerOptions) { layer.options = { outside: true, escape: true, ...next }; },
    destroy() {
      const index = layers.indexOf(layer);
      if (index >= 0) layers.splice(index, 1);
      document.removeEventListener('pointerdown', pointerdown);
      document.removeEventListener('keydown', keydown);
    }
  };
}
