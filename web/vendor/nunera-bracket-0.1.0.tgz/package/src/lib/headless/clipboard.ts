const WRITE_UNAVAILABLE = 'Clipboard write is unavailable';
const READ_UNAVAILABLE = 'Clipboard read is unavailable';

export async function writeClipboard(text: string, html?: string): Promise<void> {
  if (typeof navigator === 'undefined' || typeof document === 'undefined') throw new Error(WRITE_UNAVAILABLE);

  if (html && typeof ClipboardItem !== 'undefined' && navigator.clipboard?.write) {
    await navigator.clipboard.write([
      new ClipboardItem({
        'text/plain': new Blob([text], { type: 'text/plain' }),
        'text/html': new Blob([html], { type: 'text/html' })
      })
    ]);
    return;
  }
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return;
  }
  if (typeof document.execCommand !== 'function') throw new Error(WRITE_UNAVAILABLE);

  const area = document.createElement('textarea');
  area.value = text;
  area.style.position = 'fixed';
  area.style.opacity = '0';
  document.body.append(area);
  area.select();
  const copied = document.execCommand('copy');
  area.remove();
  if (!copied) throw new Error(WRITE_UNAVAILABLE);
}

export async function readClipboard(): Promise<string> {
  if (typeof navigator === 'undefined' || !navigator.clipboard?.readText) throw new Error(READ_UNAVAILABLE);
  return navigator.clipboard.readText();
}
