export type DismissReason = 'escape' | 'outside';
export type OverlayDismiss = (reason: DismissReason) => void;

export interface OverlayStack {
  register(dismiss: OverlayDismiss): () => void;
  isTop(dismiss: OverlayDismiss): boolean;
  dismissTop(reason: DismissReason): boolean;
  readonly size: number;
}

/** Maintains nested overlay dismissal order without coupling overlays to the DOM. */
export function createOverlayStack(): OverlayStack {
  const layers: OverlayDismiss[] = [];
  return {
    register(dismiss) {
      layers.push(dismiss);
      return () => {
        const index = layers.lastIndexOf(dismiss);
        if (index >= 0) layers.splice(index, 1);
      };
    },
    isTop(dismiss) { return layers.at(-1) === dismiss; },
    dismissTop(reason) {
      const dismiss = layers.at(-1);
      if (!dismiss) return false;
      dismiss(reason);
      return true;
    },
    get size() { return layers.length; }
  };
}

export const overlayStack = createOverlayStack();
