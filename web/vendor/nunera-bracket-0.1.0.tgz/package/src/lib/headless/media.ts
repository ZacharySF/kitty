export function createMediaQuery(query: string) {
  const list = matchMedia(query);
  let matches = list.matches;
  const listeners = new Set<(matches: boolean) => void>();
  function change(event: MediaQueryListEvent | Event) {
    matches = 'matches' in event ? event.matches : list.matches;
    for (const listener of listeners) listener(matches);
  }
  list.addEventListener('change', change);
  return {
    get matches() { return matches; },
    subscribe(listener: (matches: boolean) => void) { listeners.add(listener); listener(matches); return () => listeners.delete(listener); },
    destroy() { list.removeEventListener('change', change); listeners.clear(); }
  };
}

export function createBreakpoint(values: Record<string, string>) {
  const entries = Object.entries(values).map(([name, width]) => ({ name, query: createMediaQuery(`(min-width: ${width})`) }));
  let current: string | undefined;
  const listeners = new Set<(name: string | undefined) => void>();
  const subscriptions = entries.map((entry) => entry.query.subscribe(update));

  function update() {
    const next = entries.filter((entry) => entry.query.matches).at(-1)?.name;
    if (next === current) return;
    current = next;
    for (const listener of listeners) listener(current);
  }
  update();

  return {
    get current() { return current; },
    matches(name: string) { return entries.find((entry) => entry.name === name)?.query.matches ?? false; },
    subscribe(listener: (name: string | undefined) => void) { listeners.add(listener); listener(current); return () => listeners.delete(listener); },
    destroy() { for (const unsubscribe of subscriptions) unsubscribe(); for (const entry of entries) entry.query.destroy(); listeners.clear(); }
  };
}
