export const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';

export async function whenClient<T>(callback: () => T | Promise<T>): Promise<T> {
  if (!isBrowser) throw new Error('Client-only operation is unavailable during SSR');
  return callback();
}
