export type PartOverrides<Part extends string> = Partial<Record<Part, string>>;

export function partClass<Part extends string>(base: string, overrides: PartOverrides<Part> | undefined, part: Part): string {
  return [base, overrides?.[part]].filter(Boolean).join(' ');
}

export function partStyle<Part extends string>(base: string | undefined, overrides: PartOverrides<Part> | undefined, part: Part): string | undefined {
  const joined = [base, overrides?.[part]].filter(Boolean).join(';');
  return joined === '' ? undefined : joined;
}
