export type ColorMode = 'light' | 'dark' | 'system';
export interface ColorModeOptions { initial?: ColorMode; storageKey?: string; target?: HTMLElement }
export interface RevealOrigin { x: number; y: number }

export function colorModeScript(storageKey = 'bracket-color-mode'): string {
  return `(()=>{try{const k=${JSON.stringify(storageKey)},v=localStorage.getItem(k)||'system',d=v==='system'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):v;document.documentElement.dataset.brColorMode=d;document.documentElement.style.colorScheme=d}catch{}})()`;
}

export function createColorMode(options: ColorModeOptions = {}) {
  const target = options.target ?? document.documentElement;
  const storageKey = options.storageKey ?? 'bracket-color-mode';
  const media = matchMedia('(prefers-color-scheme: dark)');
  let mode: ColorMode = options.initial ?? (localStorage.getItem(storageKey) as ColorMode | null) ?? 'system';
  const listeners = new Set<(mode: Exclude<ColorMode, 'system'>) => void>();

  function resolved(): Exclude<ColorMode, 'system'> { return mode === 'system' ? (media.matches ? 'dark' : 'light') : mode; }
  function apply() {
    const value = resolved();
    target.dataset.brColorMode = value;
    target.style.colorScheme = value;
    for (const listener of listeners) listener(value);
  }
  function mediaChange() { if (mode === 'system') apply(); }
  media.addEventListener('change', mediaChange);
  apply();

  function startViewTransition(update: () => void, origin?: RevealOrigin) {
    const start = (document as Document & { startViewTransition?: (callback: () => void) => { ready: Promise<void> } }).startViewTransition;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!start || reduced) {
      update();
      return;
    }
    const transition = start.call(document, update);
    const x = origin?.x ?? innerWidth / 2;
    const y = origin?.y ?? innerHeight / 2;
    const radius = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
    void transition.ready.then(() => {
      target.animate(
        { clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${radius}px at ${x}px ${y}px)`] },
        { duration: 420, easing: 'ease-in-out', pseudoElement: '::view-transition-new(root)' }
      );
    });
  }

  return {
    get mode() { return mode; },
    get resolved() { return resolved(); },
    set(next: ColorMode) { mode = next; localStorage.setItem(storageKey, next); apply(); },
    toggle(origin?: RevealOrigin) {
      const next: ColorMode = resolved() === 'dark' ? 'light' : 'dark';
      startViewTransition(() => { mode = next; localStorage.setItem(storageKey, next); apply(); }, origin);
      return next;
    },
    subscribe(listener: (mode: Exclude<ColorMode, 'system'>) => void) { listeners.add(listener); listener(resolved()); return () => listeners.delete(listener); },
    destroy() { media.removeEventListener('change', mediaChange); listeners.clear(); }
  };
}
