export type SyntaxTokenType = 'plain' | 'comment' | 'string' | 'number' | 'keyword';
export interface SyntaxToken { value: string; type: SyntaxTokenType }

const KEYWORDS = new Set(['as', 'async', 'await', 'break', 'case', 'catch', 'class', 'const', 'continue', 'default', 'delete', 'do', 'else', 'enum', 'export', 'extends', 'false', 'finally', 'for', 'from', 'function', 'if', 'implements', 'import', 'in', 'instanceof', 'interface', 'let', 'new', 'null', 'of', 'return', 'static', 'super', 'switch', 'this', 'throw', 'true', 'try', 'type', 'typeof', 'undefined', 'var', 'void', 'while', 'with', 'yield']);
const TOKEN = /(\/\/.*$|#[^\n]*$|`(?:\\.|[^`])*`|"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\b\d+(?:\.\d+)?\b|\b[A-Za-z_$][\w$]*\b)/gm;

export function tokenizeLine(line: string, language = 'text'): SyntaxToken[] {
  if (language === 'text' || language === 'plaintext') return [{ value: line, type: 'plain' }];
  const tokens: SyntaxToken[] = [];
  let start = 0;
  for (const match of line.matchAll(TOKEN)) {
    const index = match.index;
    if (index > start) tokens.push({ value: line.slice(start, index), type: 'plain' });
    const value = match[0];
    const type: SyntaxTokenType = value.startsWith('//') || (value.startsWith('#') && ['python', 'py', 'shell', 'bash'].includes(language))
      ? 'comment'
      : value.startsWith('"') || value.startsWith("'") || value.startsWith('`')
        ? 'string'
        : /^\d/.test(value)
          ? 'number'
          : KEYWORDS.has(value)
            ? 'keyword'
            : 'plain';
    tokens.push({ value, type });
    start = index + value.length;
  }
  if (start < line.length) tokens.push({ value: line.slice(start), type: 'plain' });
  return tokens.length ? tokens : [{ value: '', type: 'plain' }];
}
