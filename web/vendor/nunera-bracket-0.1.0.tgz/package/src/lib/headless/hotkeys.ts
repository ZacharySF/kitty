export interface HotkeyBinding {
  keys: string;
  handler: (event: KeyboardEvent) => void;
  scope?: string;
  description?: string;
  enabled?: () => boolean;
}

export interface HotkeySummary { keys: string; scope: string; description?: string }
export interface HotkeyConflict { keys: string; scope: string; count: number }

function normalize(event: KeyboardEvent): string {
  const parts: string[] = [];
  if (event.ctrlKey) parts.push('ctrl');
  if (event.metaKey) parts.push('meta');
  if (event.altKey) parts.push('alt');
  if (event.shiftKey) parts.push('shift');
  parts.push(event.key.toLocaleLowerCase());
  return parts.join('+');
}

export function createHotkeys(initial: HotkeyBinding[] = [], sequenceTimeout = 800) {
  const bindings = [...initial];
  let scope = 'global';
  let sequence: string[] = [];
  let timer: ReturnType<typeof setTimeout> | undefined;

  function resetSequence() { clearTimeout(timer); sequence = []; }
  function onKeydown(event: KeyboardEvent) {
    const chord = normalize(event);
    sequence.push(chord);
    clearTimeout(timer);
    timer = setTimeout(resetSequence, sequenceTimeout);
    const candidate = sequence.join(' ');
    const scoped = bindings.filter((item) => (item.scope ?? 'global') === scope && item.enabled?.() !== false);
    const exact = scoped.find((item) => item.keys.toLocaleLowerCase() === candidate);
    if (exact) {
      event.preventDefault();
      exact.handler(event);
      resetSequence();
      return;
    }
    if (!scoped.some((item) => item.keys.toLocaleLowerCase().startsWith(`${candidate} `))) {
      sequence = [chord];
      const single = scoped.find((item) => item.keys.toLocaleLowerCase() === chord);
      if (single) {
        event.preventDefault();
        single.handler(event);
      }
      resetSequence();
    }
  }

  return {
    attach(target: Window | Document = window) {
      target.addEventListener('keydown', onKeydown as EventListener);
      return () => { target.removeEventListener('keydown', onKeydown as EventListener); resetSequence(); };
    },
    register(binding: HotkeyBinding) {
      bindings.push(binding);
      return () => {
        const index = bindings.indexOf(binding);
        if (index >= 0) bindings.splice(index, 1);
      };
    },
    setScope(next: string) { scope = next; resetSequence(); },
    list(): HotkeySummary[] { return bindings.map(({ keys, scope: bindingScope = 'global', description }) => ({ keys, scope: bindingScope, description })); },
    cheatsheet(): HotkeySummary[] { return this.list().filter((item) => item.description); },
    conflicts(): HotkeyConflict[] {
      const counts: Record<string, number> = {};
      for (const binding of bindings) {
        const key = `${binding.scope ?? 'global'}\u0000${binding.keys.toLocaleLowerCase()}`;
        counts[key] = (counts[key] ?? 0) + 1;
      }
      return Object.entries(counts)
        .filter(([, count]) => count > 1)
        .map(([key, count]) => {
          const [bindingScope, keys] = key.split('\u0000');
          return { scope: bindingScope, keys, count };
        });
    }
  };
}
