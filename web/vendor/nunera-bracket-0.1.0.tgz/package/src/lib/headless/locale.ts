export type Direction = 'ltr' | 'rtl';
export interface LocaleOptions { locale?: string; direction?: Direction; timeZone?: string }

const RTL_LANGUAGES: Record<string, true> = { ar: true, dv: true, fa: true, he: true, ku: true, ps: true, sd: true, ur: true, yi: true };

export function createLocale(options: LocaleOptions = {}) {
  let locale = options.locale ?? Intl.DateTimeFormat().resolvedOptions().locale;
  let timeZone = options.timeZone ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
  let explicitDirection = options.direction;
  const listeners = new Set<() => void>();

  function direction(): Direction { return explicitDirection ?? (RTL_LANGUAGES[locale.split('-')[0]] ? 'rtl' : 'ltr'); }
  function publish() { for (const listener of listeners) listener(); }

  return {
    get locale() { return locale; },
    get direction() { return direction(); },
    get timeZone() { return timeZone; },
    set(next: LocaleOptions) {
      locale = next.locale ?? locale;
      timeZone = next.timeZone ?? timeZone;
      explicitDirection = next.direction;
      publish();
    },
    number(options?: Intl.NumberFormatOptions) { return new Intl.NumberFormat(locale, options); },
    date(options?: Intl.DateTimeFormatOptions) { return new Intl.DateTimeFormat(locale, { timeZone, ...options }); },
    collator(options: Intl.CollatorOptions = { usage: 'search', sensitivity: 'base' }) { return new Intl.Collator(locale, options); },
    subscribe(listener: () => void) { listeners.add(listener); listener(); return () => listeners.delete(listener); }
  };
}
