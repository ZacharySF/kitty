let locks = 0;
let restore: (() => void) | undefined;

export function lockScroll(): () => void {
  if (typeof document === 'undefined') return () => undefined;
  locks += 1;
  if (locks === 1) {
    const root = document.documentElement;
    const body = document.body;
    const previous = {
      rootOverflow: root.style.overflow,
      rootPadding: root.style.paddingInlineEnd,
      bodyPosition: body.style.position,
      bodyTop: body.style.top,
      bodyWidth: body.style.width,
      scrollY: window.scrollY
    };
    const gutter = Math.max(0, window.innerWidth - root.clientWidth);
    root.dataset.brScrollLocked = 'true';
    root.style.overflow = 'hidden';
    if (gutter) root.style.paddingInlineEnd = `${gutter}px`;
    const isiOS = /iP(?:ad|hone|od)/.test(navigator.userAgent);
    if (isiOS) {
      body.style.position = 'fixed';
      body.style.top = `${-previous.scrollY}px`;
      body.style.width = '100%';
    }
    restore = () => {
      delete root.dataset.brScrollLocked;
      root.style.overflow = previous.rootOverflow;
      root.style.paddingInlineEnd = previous.rootPadding;
      body.style.position = previous.bodyPosition;
      body.style.top = previous.bodyTop;
      body.style.width = previous.bodyWidth;
      if (isiOS) window.scrollTo(0, previous.scrollY);
    };
  }

  let active = true;
  return () => {
    if (!active) return;
    active = false;
    locks = Math.max(0, locks - 1);
    if (!locks) {
      restore?.();
      restore = undefined;
    }
  };
}
