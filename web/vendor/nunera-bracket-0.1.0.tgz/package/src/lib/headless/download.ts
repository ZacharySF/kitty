export interface DownloadOptions { filename?: string; revokeDelay?: number }

export function download(url: string, options: DownloadOptions = {}): void {
  if (typeof document === 'undefined') throw new Error('Download is unavailable');
  const anchor = document.createElement('a');
  anchor.href = url;
  if (options.filename) anchor.download = options.filename;
  anchor.rel = 'noopener';
  anchor.hidden = true;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
}

export function downloadBlob(blob: Blob, filename: string, options: Omit<DownloadOptions, 'filename'> = {}): void {
  if (typeof URL === 'undefined' || typeof URL.createObjectURL !== 'function') throw new Error('Blob download is unavailable');
  const url = URL.createObjectURL(blob);
  download(url, { filename });
  setTimeout(() => URL.revokeObjectURL(url), options.revokeDelay ?? 0);
}
