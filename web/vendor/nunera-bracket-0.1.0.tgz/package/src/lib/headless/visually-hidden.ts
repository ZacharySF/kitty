const HIDDEN_STYLE = 'position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0';

export function visuallyHidden(node: HTMLElement) {
  const previous = node.getAttribute('style');
  node.style.cssText = `${previous ? `${previous};` : ''}${HIDDEN_STYLE}`;
  return {
    destroy() {
      if (previous === null) node.removeAttribute('style');
      else node.setAttribute('style', previous);
    }
  };
}
