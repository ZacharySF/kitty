export function memoizeOne<Arguments extends readonly unknown[], Result>(operation: (...args: Arguments) => Result): (...args: Arguments) => Result {
  let initialized = false;
  let previous: Arguments;
  let result: Result;
  return (...args: Arguments) => {
    if (initialized && args.length === previous.length) {
      let equal = true;
      for (let index = 0; index < args.length; index += 1) {
        if (!Object.is(args[index], previous[index])) { equal = false; break; }
      }
      if (equal) return result;
    }
    result = operation(...args);
    previous = args;
    initialized = true;
    return result;
  };
}
