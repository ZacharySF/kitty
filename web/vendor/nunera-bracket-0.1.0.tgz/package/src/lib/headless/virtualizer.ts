export interface VirtualItem { index: number; start: number; size: number; end: number; sticky?: boolean }
export interface VirtualizerOptions {
  count: number;
  estimateSize: (index: number) => number;
  overscan?: number;
  horizontal?: boolean;
  reverse?: boolean;
  sticky?: number[];
}
export interface VirtualRange { items: VirtualItem[]; totalSize: number }
export interface GridVirtualizerOptions {
  rows: number;
  columns: number;
  rowSize: (index: number) => number;
  columnSize: (index: number) => number;
  overscan?: number;
}
export interface VirtualCell { row: number; column: number; top: number; left: number; width: number; height: number }

export function calculateVirtualItems(scrollOffset: number, viewportSize: number, options: VirtualizerOptions): VirtualRange {
  const starts: number[] = [];
  let cursor = 0;
  for (let index = 0; index < options.count; index += 1) {
    starts[index] = cursor;
    cursor += options.estimateSize(index);
  }
  const totalSize = cursor;
  const logicalOffset = options.reverse ? Math.max(0, totalSize - viewportSize - scrollOffset) : scrollOffset;
  const overscan = options.overscan ?? 3;
  let first = starts.findIndex((start, index) => start + options.estimateSize(index) > logicalOffset);
  if (first < 0) first = Math.max(0, options.count - 1);
  let last = first;
  while (last < options.count && starts[last] < logicalOffset + viewportSize) last += 1;
  first = Math.max(0, first - overscan);
  last = Math.min(options.count, last + overscan);
  const indexes = new Set(Array.from({ length: last - first }, (_, offset) => first + offset));
  for (const index of options.sticky ?? []) if (index >= 0 && index < options.count) indexes.add(index);
  const items = [...indexes].sort((a, b) => a - b).map((index) => {
    const size = options.estimateSize(index);
    return { index, size, start: starts[index], end: starts[index] + size, sticky: options.sticky?.includes(index) || undefined };
  });
  return { items, totalSize };
}

function offsets(count: number, size: (index: number) => number) {
  const values: number[] = [];
  let total = 0;
  for (let index = 0; index < count; index += 1) {
    values.push(total);
    total += size(index);
  }
  return { values, total };
}

export function createVirtualizer(options: VirtualizerOptions) {
  return {
    range(scrollOffset: number, viewportSize: number) { return calculateVirtualItems(scrollOffset, viewportSize, options); },
    scrollToIndex(index: number, align: 'start' | 'center' | 'end' = 'start', viewportSize = 0) {
      const { values, total } = offsets(options.count, options.estimateSize);
      const safe = Math.max(0, Math.min(options.count - 1, index));
      const size = options.estimateSize(safe);
      const target = align === 'center' ? values[safe] - (viewportSize - size) / 2 : align === 'end' ? values[safe] - viewportSize + size : values[safe];
      const clamped = Math.max(0, Math.min(Math.max(0, total - viewportSize), target));
      return options.reverse ? Math.max(0, total - viewportSize - clamped) : clamped;
    },
    grid(grid: GridVirtualizerOptions, scrollTop: number, viewportHeight: number, scrollLeft: number, viewportWidth: number) {
      const rows = offsets(grid.rows, grid.rowSize);
      const columns = offsets(grid.columns, grid.columnSize);
      const overscan = grid.overscan ?? 0;
      const firstRow = Math.max(0, rows.values.findIndex((top, index) => top + grid.rowSize(index) > scrollTop) - overscan);
      const firstColumn = Math.max(0, columns.values.findIndex((left, index) => left + grid.columnSize(index) > scrollLeft) - overscan);
      let lastRow = firstRow;
      let lastColumn = firstColumn;
      while (lastRow < grid.rows && rows.values[lastRow] < scrollTop + viewportHeight) lastRow += 1;
      while (lastColumn < grid.columns && columns.values[lastColumn] < scrollLeft + viewportWidth) lastColumn += 1;
      lastRow = Math.min(grid.rows, lastRow + overscan);
      lastColumn = Math.min(grid.columns, lastColumn + overscan);
      const cells: VirtualCell[] = [];
      for (let row = firstRow; row < lastRow; row += 1) {
        for (let column = firstColumn; column < lastColumn; column += 1) {
          cells.push({ row, column, top: rows.values[row], left: columns.values[column], width: grid.columnSize(column), height: grid.rowSize(row) });
        }
      }
      return { cells, totalHeight: rows.total, totalWidth: columns.total };
    }
  };
}
