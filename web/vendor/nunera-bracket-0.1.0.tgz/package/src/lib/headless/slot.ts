type AnyProps = Record<string, unknown>;
type Handler = (event: Event) => void;

function styleText(style: unknown): string {
  if (!style) return '';
  if (typeof style === 'string') return style.replace(/;$/, '');
  if (typeof style !== 'object') return String(style);
  return Object.entries(style as Record<string, unknown>).map(([name, value]) => `${name}:${value}`).join(';');
}

export function mergeProps(...sources: AnyProps[]): AnyProps {
  const result: AnyProps = {};
  const handlers = new Map<string, Handler[]>();
  const refs: Array<(node: unknown) => void> = [];

  for (const source of sources) {
    for (const [key, value] of Object.entries(source)) {
      if (value === undefined) continue;
      if (key === 'class') {
        result.class = [result.class, value].filter(Boolean).join(' ');
      } else if (key === 'style') {
        result.style = [styleText(result.style), styleText(value)].filter(Boolean).join(';');
      } else if (key === 'ref' && typeof value === 'function') {
        refs.push(value as (node: unknown) => void);
      } else if (/^on[a-z]/.test(key) && typeof value === 'function') {
        const values = handlers.get(key) ?? [];
        values.push(value as Handler);
        handlers.set(key, values);
      } else {
        result[key] = value;
      }
    }
  }

  if (refs.length) result.ref = (node: unknown) => { for (const ref of refs) ref(node); };
  for (const [key, values] of handlers) {
    result[key] = (event: Event) => {
      for (const handler of values) {
        handler(event);
        if (event.defaultPrevented) break;
      }
    };
  }
  return result;
}
