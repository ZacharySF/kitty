export interface PortalOptions {
  target?: HTMLElement | ShadowRoot | string;
}

function resolveTarget(target: PortalOptions['target']): HTMLElement | ShadowRoot {
  if (!target) return document.body;
  if (typeof target === 'string') {
    const element = document.querySelector<HTMLElement>(target);
    if (!element) throw new Error(`Portal target not found: ${target}`);
    return element;
  }
  return target;
}

export function portal(node: HTMLElement, options: PortalOptions = {}) {
  const marker = document.createComment('bracket-portal');
  node.parentNode?.insertBefore(marker, node);

  function move(target: PortalOptions['target']) {
    resolveTarget(target).append(node);
  }

  move(options.target);
  return {
    update(next: PortalOptions = {}) { move(next.target); },
    destroy() {
      marker.parentNode?.insertBefore(node, marker);
      marker.remove();
    }
  };
}
