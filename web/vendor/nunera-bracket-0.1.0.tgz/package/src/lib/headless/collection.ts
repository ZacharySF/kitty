export interface CollectionItem {
  id: string;
  textValue: string;
  disabled?: boolean;
}

export interface CollectionManager {
  register(item: CollectionItem): () => void;
  unregister(id: string): void;
  first(): string | undefined;
  last(): string | undefined;
  next(current: string | undefined, direction: 1 | -1, loop?: boolean): string | undefined;
  search(query: string, current?: string): string | undefined;
  items(): readonly CollectionItem[];
}

/** Ordered collection navigation shared by tabs, menus, listboxes, trees, and grids. */
export function createCollection(initial: readonly CollectionItem[] = []): CollectionManager {
  const values: CollectionItem[] = [...initial];

  function enabledAt(index: number): string | undefined {
    const item = values[index];
    return item && !item.disabled ? item.id : undefined;
  }

  function edge(direction: 1 | -1): string | undefined {
    for (let index = direction === 1 ? 0 : values.length - 1; index >= 0 && index < values.length; index += direction) {
      const id = enabledAt(index);
      if (id) return id;
    }
  }

  return {
    register(item) {
      const existing = values.findIndex((candidate) => candidate.id === item.id);
      if (existing >= 0) values[existing] = item;
      else values.push(item);
      return () => this.unregister(item.id);
    },
    unregister(id) {
      const index = values.findIndex((item) => item.id === id);
      if (index >= 0) values.splice(index, 1);
    },
    first() { return edge(1); },
    last() { return edge(-1); },
    next(current, direction, loop = true) {
      if (!values.length) return undefined;
      const currentIndex = current ? values.findIndex((item) => item.id === current) : -1;
      let index = currentIndex < 0 ? (direction === 1 ? -1 : values.length) : currentIndex;
      for (let checked = 0; checked < values.length; checked += 1) {
        index += direction;
        if (index < 0 || index >= values.length) {
          if (!loop) return undefined;
          index = direction === 1 ? 0 : values.length - 1;
        }
        const id = enabledAt(index);
        if (id) return id;
      }
    },
    search(query, current) {
      const normalized = query.trim().toLocaleLowerCase();
      if (!normalized || !values.length) return undefined;
      const currentIndex = current ? values.findIndex((item) => item.id === current) : -1;
      for (let offset = 1; offset <= values.length; offset += 1) {
        const item = values[(currentIndex + offset + values.length) % values.length];
        if (!item.disabled && item.textValue.toLocaleLowerCase().startsWith(normalized)) return item.id;
      }
    },
    items() { return values; }
  };
}
