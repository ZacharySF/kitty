export type AnnouncementPriority = 'polite' | 'assertive';

export function createAnnouncer(container: HTMLElement = document.body) {
  const regions: Record<AnnouncementPriority, HTMLElement> = {
    polite: document.createElement('div'),
    assertive: document.createElement('div')
  };
  const last: Record<AnnouncementPriority, string> = { polite: '', assertive: '' };

  for (const priority of ['polite', 'assertive'] as const) {
    const region = regions[priority];
    region.dataset.brAnnouncer = priority;
    region.setAttribute('aria-live', priority);
    region.setAttribute('aria-atomic', 'true');
    region.className = 'br-sr';
    container.append(region);
  }

  return {
    announce(message: string, priority: AnnouncementPriority = 'polite') {
      if (!message || last[priority] === message) return;
      last[priority] = message;
      queueMicrotask(() => { regions[priority].textContent = message; });
    },
    clear(priority?: AnnouncementPriority) {
      for (const key of priority ? [priority] : ['polite', 'assertive'] as const) {
        regions[key].textContent = '';
        last[key] = '';
      }
    },
    destroy() { regions.polite.remove(); regions.assertive.remove(); }
  };
}
