export interface InViewOptions extends IntersectionObserverInit { onchange: (entry: IntersectionObserverEntry) => void; once?: boolean }
export interface MeasureOptions { onchange: (rect: DOMRectReadOnly, entry: ResizeObserverEntry) => void; box?: ResizeObserverBoxOptions }

export function inView(node: Element, options: InViewOptions) {
  let current = options;
  const observer = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      current.onchange(entry);
      if (current.once && entry.isIntersecting) observer.unobserve(entry.target);
    }
  }, current);
  observer.observe(node);
  return {
    update(next: InViewOptions) { current = next; },
    destroy() { observer.disconnect(); }
  };
}

export function measure(node: Element, options: MeasureOptions) {
  let current = options;
  const observer = new ResizeObserver((entries) => {
    for (const entry of entries) current.onchange(entry.contentRect, entry);
  });
  observer.observe(node, { box: current.box });
  return {
    update(next: MeasureOptions) { current = next; },
    destroy() { observer.disconnect(); }
  };
}
