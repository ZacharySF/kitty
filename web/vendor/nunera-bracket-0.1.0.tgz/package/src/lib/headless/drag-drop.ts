export type SortDirection = 'left' | 'right' | 'up' | 'down';
export interface SortableOptions { announce?: (message: string) => void; onmove?: (items: string[]) => void; columns?: number }
export interface SortableTarget { readonly items: string[]; insert(id: string, index: number): void }
export interface SortableManager extends SortableTarget {
  readonly grabbed: string | null;
  move(id: string, direction: SortDirection): void;
  transfer(id: string, target: SortableTarget, index?: number): void;
  collision(x: number, y: number, rects: Array<{ id: string; rect: DOMRect }>): string | undefined;
  sensor(node: HTMLElement, id: string): { destroy(): void };
  autoScroll(container: HTMLElement, point: { x: number; y: number }, edge?: number): void;
  dropAnimation(node: HTMLElement): void;
}

export function createSortable(initial: string[], options: SortableOptions = {}): SortableManager {
  let items = [...initial];
  let grabbed: string | null = null;
  const nodes = new Map<string, HTMLElement>();

  /** Keyed list rerenders can detach the grabbed element, so focus is restored after the DOM settles. */
  function restoreFocus(id: string) {
    requestAnimationFrame(() => {
      const node = nodes.get(id);
      if (node?.isConnected && document.activeElement !== node) node.focus();
    });
  }

  function publish(message: string) {
    options.onmove?.([...items]);
    options.announce?.(message);
  }
  function move(id: string, direction: SortDirection) {
    const from = items.indexOf(id);
    if (from < 0) return;
    const columns = Math.max(1, options.columns ?? items.length);
    const delta = direction === 'left' ? -1 : direction === 'right' ? 1 : direction === 'up' ? -columns : columns;
    const to = Math.max(0, Math.min(items.length - 1, from + delta));
    if (to === from) return;
    const next = [...items];
    next.splice(from, 1);
    next.splice(to, 0, id);
    items = next;
    publish(`Moved ${id} to position ${to + 1} of ${items.length}`);
  }
  function transfer(id: string, target: SortableTarget, index = target.items.length) {
    const from = items.indexOf(id);
    if (from < 0) return;
    items = items.filter((item) => item !== id);
    target.insert(id, index);
    publish(`Moved ${id} to another container`);
  }
  function insert(id: string, index: number) {
    const next = items.filter((item) => item !== id);
    next.splice(Math.max(0, Math.min(next.length, index)), 0, id);
    items = next;
    publish(`Inserted ${id}`);
  }
  function collision(x: number, y: number, rects: Array<{ id: string; rect: DOMRect }>) {
    return [...rects].sort((a, b) => Math.hypot(a.rect.x + a.rect.width / 2 - x, a.rect.y + a.rect.height / 2 - y) - Math.hypot(b.rect.x + b.rect.width / 2 - x, b.rect.y + b.rect.height / 2 - y))[0]?.id;
  }
  function sensor(node: HTMLElement, id: string) {
    nodes.set(id, node);
    function keydown(event: KeyboardEvent) {
      const directions: Record<string, SortDirection> = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' };
      if (event.key === ' ' || event.key === 'Enter') {
        event.preventDefault();
        grabbed = grabbed === id ? null : id;
        options.announce?.(grabbed ? `Picked up ${id}` : `Dropped ${id}`);
      } else if (grabbed === id && directions[event.key]) {
        event.preventDefault();
        move(id, directions[event.key]);
        restoreFocus(id);
      }
    }
    function pointerdown() { grabbed = id; }
    function pointerup() { if (grabbed === id) { grabbed = null; options.announce?.(`Dropped ${id}`); } }
    node.addEventListener('keydown', keydown);
    node.addEventListener('pointerdown', pointerdown);
    node.addEventListener('pointerup', pointerup);
    return {
      destroy() {
        if (nodes.get(id) === node) nodes.delete(id);
        node.removeEventListener('keydown', keydown);
        node.removeEventListener('pointerdown', pointerdown);
        node.removeEventListener('pointerup', pointerup);
      }
    };
  }
  function autoScroll(container: HTMLElement, point: { x: number; y: number }, edge = 32) {
    const rect = container.getBoundingClientRect();
    if (point.y < rect.top + edge) container.scrollBy({ top: -edge });
    else if (point.y > rect.bottom - edge) container.scrollBy({ top: edge });
    if (point.x < rect.left + edge) container.scrollBy({ left: -edge });
    else if (point.x > rect.right - edge) container.scrollBy({ left: edge });
  }

  return {
    get items() { return [...items]; },
    get grabbed() { return grabbed; },
    move,
    transfer,
    insert,
    collision,
    sensor,
    autoScroll,
    dropAnimation(node: HTMLElement) { node.animate([{ transform: 'scale(.98)' }, { transform: 'scale(1)' }], { duration: 120, easing: 'ease-out' }); }
  };
}
