export interface FocusScopeOptions {
  autofocus?: boolean;
  contain?: boolean;
  restoreFocus?: boolean;
}

const FOCUSABLE = 'a[href],button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex]:not([tabindex="-1"])';

export function focusScope(node: HTMLElement, options: FocusScopeOptions = {}) {
  let current = { autofocus: true, contain: true, restoreFocus: true, ...options };
  const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;

  function focusable() {
    return [...node.querySelectorAll<HTMLElement>(FOCUSABLE)].filter((element) => !element.hidden && element.getAttribute('aria-hidden') !== 'true');
  }

  function keydown(event: KeyboardEvent) {
    if (!current.contain || event.key !== 'Tab') return;
    const items = focusable();
    if (!items.length) {
      event.preventDefault();
      node.focus();
      return;
    }
    const first = items[0];
    const last = items.at(-1)!;
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  node.addEventListener('keydown', keydown);
  if (current.autofocus) (focusable()[0] ?? node).focus();

  return {
    update(next: FocusScopeOptions = {}) { current = { autofocus: true, contain: true, restoreFocus: true, ...next }; },
    destroy() {
      node.removeEventListener('keydown', keydown);
      if (current.restoreFocus) previous?.focus();
    }
  };
}
