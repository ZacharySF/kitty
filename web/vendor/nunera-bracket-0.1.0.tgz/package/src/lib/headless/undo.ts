export interface UndoEntry<T> { label: string; before: T; after: T }

export function createUndoManager<T>(initial: T, limit = 100) {
  let current = initial;
  const past: UndoEntry<T>[] = [];
  const future: UndoEntry<T>[] = [];
  const listeners = new Set<(value: T) => void>();

  function notify() {
    for (const listener of listeners) listener(current);
  }

  return {
    get current() { return current; },
    get canUndo() { return past.length > 0; },
    get canRedo() { return future.length > 0; },
    commit(label: string, next: T) {
      past.push({ label, before: current, after: next });
      if (past.length > limit) past.shift();
      future.length = 0;
      current = next;
      notify();
    },
    undo() {
      const entry = past.pop();
      if (!entry) return current;
      future.push(entry);
      current = entry.before;
      notify();
      return current;
    },
    redo() {
      const entry = future.pop();
      if (!entry) return current;
      past.push(entry);
      current = entry.after;
      notify();
      return current;
    },
    reset(next: T) {
      current = next;
      past.length = 0;
      future.length = 0;
      notify();
    },
    subscribe(listener: (value: T) => void) {
      listeners.add(listener);
      listener(current);
      return () => listeners.delete(listener);
    },
    history() { return past.map((entry) => entry.label); }
  };
}
