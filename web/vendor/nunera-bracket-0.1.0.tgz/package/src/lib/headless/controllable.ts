export interface ControllableStateOptions<T> {
  defaultValue: T;
  controlled?: boolean;
  value?: () => T;
  onChange?: (value: T) => void;
}

export interface ControllableState<T> {
  readonly value: T;
  set(value: T): void;
  update(updater: (value: T) => T): void;
}

/** One transition path for bindable controlled and internal uncontrolled state. */
export function createControllableState<T>(options: ControllableStateOptions<T>): ControllableState<T> {
  if (options.controlled && !options.value) throw new TypeError('Controlled state requires a value getter');
  let internal = options.defaultValue;
  const current = () => options.controlled ? options.value!() : internal;

  function set(value: T): void {
    if (Object.is(current(), value)) return;
    if (!options.controlled) internal = value;
    options.onChange?.(value);
  }

  return {
    get value() { return current(); },
    set,
    update(updater) { set(updater(current())); }
  };
}
