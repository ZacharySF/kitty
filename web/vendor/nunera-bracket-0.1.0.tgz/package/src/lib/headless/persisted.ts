export interface PersistedOptions<T> {
  storage?: Storage;
  serialize?: (value: T | { version: number; value: T }) => string;
  parse?: (raw: string) => unknown;
  version?: number;
  migrate?: (value: unknown, from: number) => T;
  url?: URL;
  queryParam?: string;
  history?: Pick<History, 'replaceState'>;
}

export function createPersistedState<T>(key: string, initial: T, options: PersistedOptions<T> = {}) {
  const storage = options.storage ?? (typeof localStorage === 'undefined' ? undefined : localStorage);
  const serialize = options.serialize ?? JSON.stringify;
  const parse = options.parse ?? JSON.parse;
  const queryParam = options.queryParam;
  let value = initial;
  const listeners = new Set<(value: T) => void>();

  if (queryParam && options.url?.searchParams.has(queryParam)) {
    try { value = parse(options.url.searchParams.get(queryParam)!) as T; }
    catch { value = options.url.searchParams.get(queryParam) as T; }
  } else if (storage) {
    try {
      const raw = storage.getItem(key);
      if (raw) {
        const record = parse(raw) as T | { version: number; value: unknown };
        value = typeof record === 'object' && record !== null && 'version' in record && 'value' in record
          ? record.version === (options.version ?? 1)
            ? record.value as T
            : options.migrate?.(record.value, record.version) ?? initial
          : record as T;
      }
    } catch {
      value = initial;
    }
  }

  function publish(next: T) {
    value = next;
    if (storage) {
      const payload = options.version ? { version: options.version, value } : value;
      storage.setItem(key, serialize(payload));
    }
    if (queryParam && options.url) {
      const raw = typeof next === 'string' ? next : JSON.stringify(next);
      options.url.searchParams.set(queryParam, raw);
      options.history?.replaceState(null, '', options.url);
    }
    for (const listener of listeners) listener(value);
  }

  return {
    get current() { return value; },
    set current(next: T) { publish(next); },
    subscribe(listener: (value: T) => void) { listeners.add(listener); listener(value); return () => listeners.delete(listener); },
    clear() {
      value = initial;
      storage?.removeItem(key);
      if (queryParam && options.url) options.url.searchParams.delete(queryParam);
      for (const listener of listeners) listener(value);
    }
  };
}
