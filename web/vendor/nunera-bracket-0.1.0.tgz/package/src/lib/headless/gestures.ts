export interface SwipeDetail { direction: 'left' | 'right' | 'up' | 'down'; distance: number; velocity: number }
export interface GestureOptions {
  longPressMs?: number;
  swipeThreshold?: number;
  onlongpress?: (event: PointerEvent) => void;
  onswipe?: (detail: SwipeDetail) => void;
  ondrag?: (detail: { dx: number; dy: number; event: PointerEvent }) => void;
  onpinch?: (detail: { scale: number; event: PointerEvent }) => void;
}

export function gestures(node: HTMLElement, options: GestureOptions = {}) {
  let current = options;
  const points = new Map<number, { x: number; y: number }>();
  let start: { x: number; y: number; time: number; event: PointerEvent } | null = null;
  let initialPinch = 0;
  let timer: ReturnType<typeof setTimeout> | undefined;

  function distance() {
    const values = [...points.values()];
    return values.length < 2 ? 0 : Math.hypot(values[1].x - values[0].x, values[1].y - values[0].y);
  }
  function down(event: PointerEvent) {
    points.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (!start) {
      start = { x: event.clientX, y: event.clientY, time: performance.now(), event };
      timer = setTimeout(() => current.onlongpress?.(event), current.longPressMs ?? 500);
    }
    if (points.size === 2) initialPinch = distance();
  }
  function move(event: PointerEvent) {
    if (!points.has(event.pointerId)) return;
    points.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (start) current.ondrag?.({ dx: event.clientX - start.x, dy: event.clientY - start.y, event });
    if (points.size === 2 && initialPinch) current.onpinch?.({ scale: distance() / initialPinch, event });
  }
  function up(event: PointerEvent) {
    clearTimeout(timer);
    if (start) {
      const dx = event.clientX - start.x;
      const dy = event.clientY - start.y;
      const absoluteX = Math.abs(dx);
      const absoluteY = Math.abs(dy);
      const travel = Math.max(absoluteX, absoluteY);
      if (travel >= (current.swipeThreshold ?? 40)) {
        const direction = absoluteX > absoluteY ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
        current.onswipe?.({ direction, distance: travel, velocity: travel / Math.max(1, performance.now() - start.time) });
      }
    }
    points.delete(event.pointerId);
    if (!points.size) start = null;
  }

  node.addEventListener('pointerdown', down);
  node.addEventListener('pointermove', move);
  node.addEventListener('pointerup', up);
  node.addEventListener('pointercancel', up);
  return {
    update(next: GestureOptions) { current = next; },
    destroy() {
      clearTimeout(timer);
      node.removeEventListener('pointerdown', down);
      node.removeEventListener('pointermove', move);
      node.removeEventListener('pointerup', up);
      node.removeEventListener('pointercancel', up);
    }
  };
}
