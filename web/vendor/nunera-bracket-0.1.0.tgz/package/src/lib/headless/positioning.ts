export type PositionSide = 'top' | 'right' | 'bottom' | 'left';
export type PositionAlign = 'start' | 'center' | 'end';

export interface RectLike { left: number; right: number; top: number; bottom: number; width: number; height: number }
export interface FloatingSize { width: number; height: number }
export interface PositionOptions {
  side?: PositionSide;
  align?: PositionAlign;
  offset?: number;
  collisionPadding?: number;
  viewport?: { width: number; height: number };
}
export interface PositionResult {
  x: number;
  y: number;
  side: PositionSide;
  transformOrigin: string;
  cssVariables: Record<string, string>;
}

const opposite: Record<PositionSide, PositionSide> = { top: 'bottom', right: 'left', bottom: 'top', left: 'right' };

function mainSpace(anchor: RectLike, viewport: { width: number; height: number }, side: PositionSide, padding: number): number {
  if (side === 'top') return anchor.top - padding;
  if (side === 'bottom') return viewport.height - anchor.bottom - padding;
  if (side === 'left') return anchor.left - padding;
  return viewport.width - anchor.right - padding;
}

/** Computes anchored coordinates, flips on main-axis collision, and shifts into the viewport. */
export function computePosition(anchor: RectLike, floating: FloatingSize, options: PositionOptions = {}): PositionResult {
  const requested = options.side ?? 'bottom';
  const align = options.align ?? 'center';
  const offset = options.offset ?? 4;
  const padding = options.collisionPadding ?? 8;
  const viewport = options.viewport ?? {
    width: typeof window === 'undefined' ? anchor.right + floating.width + padding : window.innerWidth,
    height: typeof window === 'undefined' ? anchor.bottom + floating.height + padding : window.innerHeight
  };
  const required = (requested === 'top' || requested === 'bottom' ? floating.height : floating.width) + offset;
  const flipped = mainSpace(anchor, viewport, requested, padding) < required && mainSpace(anchor, viewport, opposite[requested], padding) > mainSpace(anchor, viewport, requested, padding);
  const side = flipped ? opposite[requested] : requested;

  let x = anchor.left + (anchor.width - floating.width) / 2;
  let y = anchor.top + (anchor.height - floating.height) / 2;
  if (side === 'top') y = anchor.top - floating.height - offset;
  if (side === 'bottom') y = anchor.bottom + offset;
  if (side === 'left') x = anchor.left - floating.width - offset;
  if (side === 'right') x = anchor.right + offset;

  if (side === 'top' || side === 'bottom') {
    if (align === 'start') x = anchor.left;
    if (align === 'end') x = anchor.right - floating.width;
  } else {
    if (align === 'start') y = anchor.top;
    if (align === 'end') y = anchor.bottom - floating.height;
  }

  x = Math.min(Math.max(x, padding), viewport.width - floating.width - padding);
  y = Math.min(Math.max(y, padding), viewport.height - floating.height - padding);
  const horizontalOrigin = side === 'left' ? '100%' : side === 'right' ? '0%' : align === 'start' ? '0%' : align === 'end' ? '100%' : '50%';
  const verticalOrigin = side === 'top' ? '100%' : side === 'bottom' ? '0%' : align === 'start' ? '0%' : align === 'end' ? '100%' : '50%';

  return {
    x,
    y,
    side,
    transformOrigin: `${horizontalOrigin} ${verticalOrigin}`,
    cssVariables: {
      '--br-anchor-width': `${anchor.width}px`,
      '--br-anchor-height': `${anchor.height}px`,
      '--br-available-width': `${Math.max(0, viewport.width - padding * 2)}px`,
      '--br-available-height': `${Math.max(0, viewport.height - padding * 2)}px`,
      '--br-transform-origin': `${horizontalOrigin} ${verticalOrigin}`
    }
  };
}

export function autoUpdate(anchor: Element, floating: HTMLElement, update: () => void): () => void {
  if (typeof window === 'undefined') return () => undefined;
  const observer = typeof ResizeObserver === 'undefined' ? undefined : new ResizeObserver(update);
  observer?.observe(anchor);
  observer?.observe(floating);
  window.addEventListener('resize', update);
  window.addEventListener('scroll', update, true);
  update();
  return () => {
    observer?.disconnect();
    window.removeEventListener('resize', update);
    window.removeEventListener('scroll', update, true);
  };
}
