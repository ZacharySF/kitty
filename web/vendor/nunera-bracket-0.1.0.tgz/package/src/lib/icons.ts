export const icons = {
  map: '\uEC05', table: '\uEBB7', undo: '\uEAE2', redo: '\uEBB0', keys: '\uEA65',
  question: '\uEB32', list: '\uEB17', terminal: '\uEA85', inbox: '\uEB09', agent: '\uEB08',
  compass: '\uEBD5', layers: '\uEBD2', paint: '\uEB2A', search: '\uEA6D', filter: '\uEAF1',
  close: '\uEA76', check: '\uEAB2', warn: '\uEA6C', error: '\uEA87', info: '\uEA74',
  eye: '\uEA70', eyeOff: '\uEAE7', pin: '\uEB1A', target: '\uEBF8', history: '\uEA82',
  calendar: '\uEAB0', comment: '\uEA6B', discuss: '\uEAC7', video: '\uEAD9', camera: '\uEADA',
  media: '\uEAEA', link: '\uEB14', sync: '\uEA77', refresh: '\uEB37', pulse: '\uEB31',
  tower: '\uEB34', database: '\uEACE', server: '\uEB50', shield: '\uEB53', lock: '\uEA75',
  flame: '\uEAF2', beaker: '\uEA79', telescope: '\uEB68', sparkle: '\uEC10', play: '\uEB2C',
  add: '\uEA60', send: '\uEC0F', person: '\uEA67', tag: '\uEA66', graph: '\uEB03',
  note: '\uEB26', law: '\uEB12', globe: '\uF0AC', bolt: '\uF0E7', clock: '\uF017',
  signal: '\uF012', gear: '\uF013', rocket: '\uF135', sun: '\uF185', moon: '\uF186',
  chevRight: '\uEAB6', chevDown: '\uEAB4', chevUp: '\uEAB7', arrowRight: '\uEA9C', star: '\uEB59'
} as const;
export type IconName = keyof typeof icons;
