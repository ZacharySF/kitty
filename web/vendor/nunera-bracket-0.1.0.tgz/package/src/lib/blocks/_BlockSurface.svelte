<script lang="ts">
  export type BlockMode = 'dashboard-shell' | 'settings-page' | 'sign-in' | 'sign-up' | 'forgot-password' | 'mfa-challenge' | 'magic-link' | 'onboarding-flow' | 'profile-page' | 'billing-page' | 'team-management' | 'data-table-page' | 'mail-inbox-app' | 'chat-app' | 'file-manager' | 'kanban-app' | 'calendar-app' | 'hero-section' | 'logo-cloud' | 'feature-grid-bento' | 'testimonials' | 'stats-section' | 'pricing-section' | 'faq-section' | 'cta-section' | 'newsletter-signup' | 'blog-list' | 'blog-post' | 'changelog' | 'team-section' | 'contact-form' | 'comparison-table' | 'waitlist' | 'marketing-footer' | '404-page' | '500-page' | 'maintenance-page' | 'coming-soon-page' | 'no-permission-page';
  export interface BlockContent { title?: string; description?: string; cta?: string; eyebrow?: string }
  export interface BlockSurfaceProps {
    mode: BlockMode | string;
    variant?: 'default' | 'compact' | 'split';
    experiment?: 'A' | 'B';
    content?: BlockContent;
    onaction?: (detail: { block: string; action: string; experiment: 'A' | 'B' }) => void;
  }

  let { mode, variant = 'default', experiment = 'A', content = {}, onaction }: BlockSurfaceProps = $props();
  const appBlocks = ['dashboard-shell', 'settings-page', 'profile-page', 'billing-page', 'team-management', 'data-table-page', 'mail-inbox-app', 'chat-app', 'file-manager', 'kanban-app', 'calendar-app'];
  const authBlocks = ['sign-in', 'sign-up', 'forgot-password', 'mfa-challenge', 'magic-link'];
  const statusBlocks = ['404-page', '500-page', 'maintenance-page', 'coming-soon-page', 'no-permission-page'];
  const titles: Record<string, string> = {
    'dashboard-shell': 'Operations dashboard', 'settings-page': 'Settings', 'sign-in': 'Sign in', 'sign-up': 'Create account',
    'forgot-password': 'Reset password', 'mfa-challenge': 'Verify your identity', 'magic-link': 'Email sign-in link',
    'onboarding-flow': 'Set up your workspace', 'profile-page': 'Operator profile', 'billing-page': 'Billing and plans',
    'team-management': 'Team management', 'data-table-page': 'Telemetry records', 'mail-inbox-app': 'Mission inbox',
    'chat-app': 'Operations chat', 'file-manager': 'Field files', 'kanban-app': 'Mission board', 'calendar-app': 'Schedule',
    'hero-section': 'Coordinate every mission', 'logo-cloud': 'Trusted in the field', 'feature-grid-bento': 'Built for reliable operations',
    testimonials: 'Operator reports', 'stats-section': 'Measured performance', 'pricing-section': 'Plans for every team',
    'faq-section': 'Frequently asked questions', 'cta-section': 'Ready to deploy?', 'newsletter-signup': 'Field notes',
    'blog-list': 'Latest reports', 'blog-post': 'Building a resilient mesh', changelog: 'Product changelog',
    'team-section': 'Meet the team', 'contact-form': 'Contact operations', 'comparison-table': 'Compare plans',
    waitlist: 'Join the waitlist', 'marketing-footer': 'Bracket', '404-page': 'Not found', '500-page': 'System error',
    'maintenance-page': 'Scheduled maintenance', 'coming-soon-page': 'Coming soon', 'no-permission-page': 'Permission required'
  };
  const descriptions: Record<string, string> = {
    '404-page': 'The requested route does not exist.', '500-page': 'The service encountered an unexpected failure.',
    'maintenance-page': 'Systems will return after scheduled maintenance.', 'coming-soon-page': 'This capability is being prepared.',
    'no-permission-page': 'Your account cannot access this resource.'
  };
  const title = $derived(content.title ?? titles[mode] ?? mode);
  const description = $derived(content.description ?? descriptions[mode] ?? 'A production-ready Bracket template with composable sections.');
  const cta = $derived(content.cta ?? (mode === 'newsletter-signup' && experiment === 'B' ? 'Join waitlist' : mode === 'newsletter-signup' ? 'Subscribe' : authBlocks.includes(mode) ? 'Continue' : statusBlocks.includes(mode) ? 'Return home' : experiment === 'B' ? 'Start now' : 'Get started'));
  function action(name = 'primary') { onaction?.({ block: mode, action: name, experiment }); }
</script>

<section class="block" class:experiment-b={experiment === 'B'} data-block={mode} data-variant={variant} data-experiment={experiment}>
  <div class="block-content">
    <header class="intro">
      {#if content.eyebrow}<p class="eyebrow">{content.eyebrow}</p>{/if}
      <h1>{title}</h1><p>{description}</p>
    </header>

    {#if appBlocks.includes(mode)}
      <div class="app-layout">
        <nav aria-label="Application"><a href="#overview" aria-current="page">Overview</a><a href="#activity">Activity</a><a href="#team">Team</a></nav>
        <main>
          {#if mode === 'settings-page'}
            <form><label>Workspace name<input value="Relay Operations"/></label><label><input type="checkbox" checked/> Email alerts</label><button type="button" onclick={() => action('save')}>SAVE CHANGES</button></form>
          {:else if mode === 'profile-page'}
            <article class="profile"><span class="avatar">MK</span><div><h2>Michael Kryvonis</h2><p>System operator</p></div><button type="button">EDIT PROFILE</button></article>
          {:else if mode === 'billing-page'}
            <article><h2>Operator plan</h2><strong>$19 / month</strong><p>Next invoice: November 8</p></article>
          {:else if mode === 'team-management'}
            <table><caption>Workspace members</caption><tbody><tr><th>Michael</th><td>Owner</td></tr><tr><th>Alex</th><td>Editor</td></tr></tbody></table>
          {:else if mode === 'data-table-page'}
            <table><caption>Telemetry records</caption><thead><tr><th>ID</th><th>Status</th><th>Latency</th></tr></thead><tbody><tr><td>R-04</td><td>Online</td><td>42 ms</td></tr></tbody></table>
          {:else if mode === 'mail-inbox-app'}
            <ul class="inbox"><li><b>Mission Control</b><span>Route plan approved</span></li><li><b>Relay 04</b><span>Calibration complete</span></li></ul>
          {:else if mode === 'chat-app'}
            <div class="messages"><p>Mesh status?</p><p class="reply">All relays connected.</p><label>Message<input/></label></div>
          {:else if mode === 'file-manager'}
            <div class="files"><button type="button">📁 Reports</button><button type="button">📄 telemetry.csv</button><button type="button">📄 route.pdf</button></div>
          {:else if mode === 'kanban-app'}
            <div class="kanban">{#each ['Queued', 'Active', 'Done'] as column (column)}<section><h2>{column}</h2><article>Verify relay</article></section>{/each}</div>
          {:else if mode === 'calendar-app'}
            <div class="calendar">{#each ['09:00 Briefing', '11:30 Calibration', '14:00 Review'] as event (event)}<time>{event}</time>{/each}</div>
          {:else}
            <div class="dashboard-grid"><article><span>Active relays</span><strong>24</strong></article><article><span>Median latency</span><strong>42 ms</strong></article><article><span>Success rate</span><strong>99.8%</strong></article></div>
          {/if}
        </main>
        <aside><b>STATUS</b><span class="online">All systems online</span></aside>
      </div>
      <button type="button" onclick={() => action()}>{cta}</button>
    {:else if authBlocks.includes(mode)}
      <form class="auth" onsubmit={(event) => { event.preventDefault(); action(); }}>
        <label>Email<input type="email" autocomplete="email" required/></label>
        {#if mode === 'sign-in' || mode === 'sign-up'}<label>Password<input type="password" autocomplete={mode === 'sign-up' ? 'new-password' : 'current-password'} required/></label>{/if}
        {#if mode === 'mfa-challenge'}<label>Verification code<input inputmode="numeric" autocomplete="one-time-code" required/></label>{/if}
        <button type="submit">{cta}</button>
      </form>
    {:else if mode === 'onboarding-flow'}
      <ol class="steps"><li class="done">Account</li><li aria-current="step">Workspace</li><li>Invite team</li></ol><form><label>Workspace name<input value="Relay Operations"/></label><button type="button" onclick={() => action()}>{cta}</button></form>
    {:else if mode === 'pricing-section'}
      <div class="plans">{#each [{name:'Scout',price:'$0'},{name:'Operator',price:'$19'},{name:'Fleet',price:'$49'}] as plan, index (plan.name)}<article class="plan" class:featured={index === 1}><h2>{plan.name}</h2><strong>{plan.price}</strong><ul><li>Mission workspace</li><li>Telemetry reports</li></ul><button type="button" onclick={() => action(plan.name)}>{cta}</button></article>{/each}</div>
    {:else if mode === 'logo-cloud'}
      <div class="logos" aria-label="Customers">{#each ['KUDZU', 'ICHOR', 'AXON', 'ORION'] as logo (logo)}<b>{logo}</b>{/each}</div><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'feature-grid-bento'}
      <div class="bento">{#each ['Realtime sync', 'Accessible defaults', 'Typed APIs', 'Offline ready'] as feature, index (feature)}<article class:wide={index === 0}><h2>{feature}</h2><p>Built into every workflow.</p></article>{/each}</div><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'testimonials'}
      <div class="quotes"><blockquote>“Bracket keeps field operations clear.”<cite>— Mission lead</cite></blockquote><blockquote>“Fast, reliable, and accessible.”<cite>— Systems engineer</cite></blockquote></div><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'stats-section'}
      <dl class="stats"><div><dt>Uptime</dt><dd>99.99%</dd></div><div><dt>Median latency</dt><dd>42 ms</dd></div><div><dt>Relays</dt><dd>24</dd></div></dl><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'faq-section'}
      <div class="faq">{#each ['Can I self-host?', 'Does it work offline?', 'Is it accessible?'] as question (question)}<details><summary>{question}</summary><p>Yes. The template exposes typed integration hooks.</p></details>{/each}</div><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'newsletter-signup' || mode === 'waitlist'}
      <form class="subscribe" onsubmit={(event) => { event.preventDefault(); action(); }}><label>Email<input type="email" autocomplete="email" required/></label><button type="submit">{cta}</button></form>
    {:else if mode === 'blog-list'}
      <div class="posts">{#each ['Resilient mesh networks', 'Accessible data tools', 'Field-ready interfaces'] as post (post)}<article><time datetime="2026-10-09">OCT 09</time><h2>{post}</h2><a href="#post">Read report</a></article>{/each}</div><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'blog-post'}
      <article class="prose"><p class="eyebrow">ENGINEERING</p><h2>Designing for unreliable networks</h2><p>Field interfaces must preserve intent across intermittent connections and constrained hardware.</p><h3>Measure first</h3><p>Track latency, packet loss, and recovery before changing topology.</p></article><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'changelog'}
      <ol class="changes"><li><time datetime="2026-10-09">0.1.0</time><div><h2>Initial release</h2><p>Components, utilities, blocks, and registry.</p></div></li></ol><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'team-section'}
      <div class="team">{#each ['MK', 'AR', 'JL'] as person (person)}<article><span class="avatar">{person}</span><h2>{person} Operator</h2><p>Systems engineering</p></article>{/each}</div><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'contact-form'}
      <form class="contact" onsubmit={(event) => { event.preventDefault(); action(); }}><label>Name<input autocomplete="name" required/></label><label>Email<input type="email" autocomplete="email" required/></label><label>Message<textarea required></textarea></label><button type="submit">{cta}</button></form>
    {:else if mode === 'comparison-table'}
      <table><caption>Plan comparison</caption><thead><tr><th>Feature</th><th>Scout</th><th>Operator</th></tr></thead><tbody><tr><th>Projects</th><td>1</td><td>Unlimited</td></tr><tr><th>Exports</th><td>—</td><td>Included</td></tr></tbody></table><button type="button" onclick={() => action()}>{cta}</button>
    {:else if mode === 'marketing-footer'}
      <footer><div><b>BRACKET</b><p>Field-ready interface systems.</p></div><nav aria-label="Footer"><a href="#product">Product</a><a href="#docs">Docs</a><a href="#legal">Legal</a></nav><small>© 2026 Nunera</small></footer><button type="button" onclick={() => action()}>{cta}</button>
    {:else if statusBlocks.includes(mode)}
      <div class="status-art" aria-hidden="true">{mode.startsWith('4') ? '404' : mode.startsWith('5') ? '500' : '◈'}</div><button type="button" onclick={() => action()}>{cta}</button>
    {:else}
      <div class="hero-art"><i></i><i></i><i></i></div><button type="button" onclick={() => action()}>{cta}</button>
    {/if}
  </div>
</section>

<style>
  .block { container-type: inline-size; padding: clamp(14px, 4vw, 42px); border: 1px solid var(--br-line); background: var(--br-surface); color: var(--br-text); font: 11px/1.5 var(--br-font-sans); color-scheme: light dark; }
  .block-content { width: min(100%, 1040px); margin-inline: auto; }.intro { max-width: 650px; margin-bottom: 20px; }.intro h1 { margin: 0; color: var(--br-ink); font-size: clamp(24px, 6cqi, 54px); line-height: 1; text-wrap: balance; }.intro p { color: var(--br-mute); }.eyebrow { color: var(--br-signal) !important; font: 9px var(--br-font-mono); letter-spacing: .16em; }
  button, input, textarea { min-height: 36px; border: 1px solid var(--br-line); background: var(--br-raised); color: inherit; font: inherit; }button { padding: 7px 11px; cursor: pointer; }button:focus-visible, input:focus-visible, textarea:focus-visible, a:focus-visible { outline: 2px solid var(--br-signal); outline-offset: 2px; }a { color: var(--br-signal); }
  .app-layout { display: grid; grid-template-columns: 150px minmax(0, 1fr) 150px; min-height: 260px; border: 1px solid var(--br-line); }.app-layout > nav, .app-layout > aside { display: grid; align-content: start; gap: 8px; padding: 12px; background: var(--br-inset); }.app-layout main { padding: 12px; }.online { color: var(--br-success); }.dashboard-grid, .plans, .posts, .team, .quotes, .stats, .bento { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }.dashboard-grid article, .plan, .posts article, .team article, .bento article, .quotes blockquote { margin: 0; padding: 12px; border: 1px solid var(--br-line); background: var(--br-raised); }.dashboard-grid strong, .stats dd { display: block; color: var(--br-signal); font-size: 22px; }.app-layout form, .auth, .contact, .subscribe, .block-content > form { display: grid; gap: 8px; max-width: 440px; }.block label { display: grid; gap: 3px; }.profile { display: flex; gap: 10px; align-items: center; }.avatar { display: grid; place-items: center; width: 54px; height: 54px; border-radius: 50%; background: var(--br-raised); color: var(--br-signal); }.profile button { margin-left: auto; }
  table { width: 100%; border-collapse: collapse; }th, td { padding: 7px; border: 1px solid var(--br-line); text-align: left; }.inbox, .files, .messages, .calendar { display: grid; gap: 6px; padding: 0; list-style: none; }.inbox li, .messages p, .calendar time { display: flex; justify-content: space-between; padding: 8px; border: 1px solid var(--br-line); }.messages .reply { margin-left: 20%; border-color: var(--br-signal); }.kanban { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }.kanban section { padding: 7px; background: var(--br-inset); }.kanban article { padding: 7px; background: var(--br-raised); }.steps { display: flex; gap: 12px; padding: 0; list-style: none; }.steps li[aria-current], .steps .done { color: var(--br-signal); }.plan.featured { border-color: var(--br-signal); transform: translateY(-5px); }.logos { display: flex; flex-wrap: wrap; justify-content: space-around; gap: 20px; padding: 26px; color: var(--br-structure); }.bento .wide { grid-column: span 2; }.quotes cite { display: block; color: var(--br-mute); }.stats div { padding: 10px; border-left: 2px solid var(--br-signal); }.stats dd { margin: 0; }.faq, .changes { display: grid; gap: 6px; }.faq details { padding: 8px; border: 1px solid var(--br-line); }.prose { max-width: 680px; font-size: 14px; }.changes { padding: 0; list-style: none; }.changes li { display: grid; grid-template-columns: 80px 1fr; gap: 10px; }.team { text-align: center; }.team .avatar { margin: auto; }.block footer { display: grid; grid-template-columns: 1fr auto; gap: 14px; }.block footer small { grid-column: 1 / -1; }.status-art { color: var(--br-line); font-size: clamp(70px, 20cqi, 190px); font-weight: 700; line-height: .8; }.hero-art { position: relative; height: 100px; }.hero-art i { position: absolute; width: 70px; height: 70px; border: 1px solid var(--br-signal); transform: rotate(45deg); }.hero-art i:nth-child(2) { left: 55px; opacity: .6; }.hero-art i:nth-child(3) { left: 110px; opacity: .3; }
  .status-art { color: var(--br-mute); }
  .block[data-variant='compact'] { padding: 12px; }.block[data-variant='compact'] .intro { margin-bottom: 8px; }.block[data-variant='split'] > .block-content { display: grid; grid-template-columns: minmax(220px, .7fr) minmax(0, 1.3fr); gap: 22px; align-items: center; }.experiment-b { border-top: 3px solid var(--br-signal); }.experiment-b .intro h1 { color: var(--br-signal); }
  @container (max-width: 680px) { .block[data-variant='split'] > .block-content { grid-template-columns: 1fr; }.app-layout { grid-template-columns: 1fr; }.app-layout > nav { grid-auto-flow: column; overflow: auto; }.app-layout > aside { display: none; }.dashboard-grid, .plans, .posts, .team, .quotes, .stats, .bento { grid-template-columns: 1fr; }.bento .wide { grid-column: auto; }.kanban { grid-template-columns: repeat(3, minmax(150px, 1fr)); overflow: auto; } }
  @media (prefers-color-scheme: dark) { .block { box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--br-signal) 8%, transparent); } }
</style>
