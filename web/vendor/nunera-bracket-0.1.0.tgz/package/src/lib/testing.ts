import { contrast, type Role, type Theme } from './theme';

export interface ContrastFailure { foreground: Role; background: Role; ratio: number; minimum: number }
export interface ThemeAudit { passed: boolean; failures: ContrastFailure[] }

const textChecks: { foreground: Role; background: Role; minimum: number }[] = [
  { foreground: 'ink', background: 'panel', minimum: 7 },
  { foreground: 'mute', background: 'panel', minimum: 4.5 },
  { foreground: 'ink', background: 'raised', minimum: 4.5 },
  { foreground: 'mute', background: 'inset', minimum: 4.5 }
];

export function auditTheme(theme: Theme): ThemeAudit {
  const failures = textChecks.flatMap(({ foreground, background, minimum }) => {
    const ratio = contrast(theme[foreground], theme[background]);
    return ratio < minimum ? [{ foreground, background, ratio, minimum }] : [];
  });
  return { passed: failures.length === 0, failures };
}
