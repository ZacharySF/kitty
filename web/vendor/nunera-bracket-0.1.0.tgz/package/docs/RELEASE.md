# Release policy

## Required automated gates

Run from a clean dependency installation:

```sh
pnpm install --frozen-lockfile
pnpm verify
pnpm verify:release
```

`verify` runs `generate:docs` first, then checks documentation coverage and links; Svelte/TypeScript diagnostics; unit, component, SSR, Chromium interaction, axe, and visual suites; packed-consumer imports; registry evidence; production builds; and bundle budgets. `verify:release` adds Firefox and WebKit.

A release is blocked by any diagnostic, undocumented public export, stale generated reference, broken documentation link, failed behavior check, serious/critical axe finding, supported-width overflow, stale requirement evidence, empty export demo, package-entry failure, or bundle-budget regression.

## Manual gates

- Complete and sign the three platform rows in [ACCESSIBILITY.md](./ACCESSIBILITY.md); `Not run` is a blocker.
- Review every intentional visual snapshot change in the rendered catalog.
- Exercise the packed tarball in Kudzu; source-relative imports are not acceptable evidence.
- Verify [MIGRATION.md](./MIGRATION.md), package entries, generated API references, and [CHANGELOG.md](../CHANGELOG.md) against the shipped interface.
- Confirm generated files are unchanged after a second `pnpm generate:docs` run.

## Registry invariant

The release claim is mechanical: 332 modules, 2,431 requirements, every module mapped to at least one public export, every requirement linked to existing evidence, and every catalog demo backed by a real implementation. `pnpm test:coverage` enforces that invariant.

## Artifact and publication policy

The current package is `"private": true`. Release verification proves workspace/file and packed-tarball consumption; it does not publish to npm. Before any registry publication, intentionally remove the private flag, verify package metadata and ownership, inspect `pnpm pack` contents, install that exact tarball into an isolated consumer, and rerun the release gates. Never infer publishability from a successful build.

The shipped contract includes the export map, CLI output, registry IDs and JSON shapes, CSS token names, component props/events, headless signatures, and generated file paths. Review those surfaces before changing the version.

## Release record

Record the version, commit, package tarball checksum, Node and pnpm versions, automated command results, visual reviewer, three assistive-technology results, migration reviewer, and any accepted limitations. Do not mark a release complete while a required field is unknown.

## Versioning

Bracket follows semantic versioning. Breaking prop, export, token, registry-ID, or CLI output changes require a major version after 1.0. Additive components and optional props are minor; compatible fixes are patch releases. Do not retain deprecated shims before 1.0—migrate every in-repository caller in the same change.
