# Figma mapping contract

`src/lib/registry/figma.json` is the generated design-to-code manifest for all 332 registry modules. It is data for a design-library importer or Code Connect integration; Bracket does not currently ship a Figma plugin, a `.fig` library, or vendor-specific Code Connect source.

## Row schema

```ts
interface FigmaMapping {
  id: string;          // immutable registry module ID
  family: string;      // catalog family
  figma: string;       // suggested node name: Bracket/<family>/<name>
  exports: string[];   // public code exports represented by the node
  package: string;     // supported package entry point
  properties: string[];// public component prop names resolved for those exports
}
```

The registry `id` is the immutable join key. Renaming a visible Figma node or code export does not silently change that ID. When a row has several exports, the design node represents a composable module rather than an instruction to select the first export blindly.

`properties` is generated from the same resolved component props as [COMPONENTS.md](./COMPONENTS.md), including inherited wrapper props. A row can have an empty property list when it represents utilities, types, headless behavior, or another module without a component prop surface. Property presence documents code capability; it does not prove that a Figma component property or Code Connect binding has been authored.

## Recommended property mapping

| Figma property | Code contract |
| --- | --- |
| Variant | Exact `variant` union listed for that component |
| Size | Exact `size` union or length type listed for that component |
| Intent | Exact `intent` union listed for that component |
| Density | Nearest `ThemeProvider` or ancestor `data-br-density` |
| Disabled | `disabled` when listed |
| Read only | `readOnly` when listed |
| Invalid | `invalid` when listed |
| Direction | Inherited `dir` or locale provider; do not duplicate when no prop exists |
| Block experiment | `experiment="A" | "B"` |
| Content slot | A Svelte `Snippet` prop; map only when the design integration supports code slots |
| Callback | `on*` prop; document the event but do not model it as a visual variant |

Names are case-sensitive. Do not normalize unlike contracts (`readonly` versus `readOnly`, for example); follow the exact generated prop table.

## Tokens

Map Figma variables by semantic role, never by sampled literal color:

`br/void`, `br/panel`, `br/inset`, `br/raised`, `br/line`, `br/line-hot`, `br/ink`, `br/mute`, `br/dim`, `br/structure`, `br/signal`, `br/go`, `br/reference`, `br/caution`, `br/alternate`, and `br/danger`.

The code token corresponding to the design name `br/line-hot` is `--br-lineHot`; this legacy camel-case spelling is part of the current pre-1.0 CSS contract. Spacing, radius, typography, elevation, layering, breakpoint, motion, and density scales are listed in [THEMING.md](./THEMING.md).

## Handoff workflow

1. Regenerate code references and mappings with `pnpm generate:docs`.
2. Import `figma.json` into the external design tooling and join by `id`.
3. Bind only properties listed for that row and verify unions/defaults in [COMPONENTS.md](./COMPONENTS.md).
4. Record design-only variants explicitly; they are not code capabilities until exported and regenerated.
5. Run `pnpm test:docs` and `pnpm test:coverage` before release.

The documentation gate verifies row count, registry IDs, public exports, component-property coverage, and local links. Visual equivalence between a Figma library and browser rendering remains a human design-review responsibility.
