# Migration guide

## Kudzu to Bracket

1. Install the packed package and import `@nunera/bracket/styles.css` once.
2. Replace the palette application call with `applyKudzuPalette`. Existing `--void`, `--panel`, `--c1` through `--c6`, and `--danger` consumers continue to resolve.
3. Replace local primitives by feature slice. Keep state ownership in the feature; use bindable Bracket props only at the component boundary.
4. Move feature CSS from legacy palette variables to semantic `--br-*` roles.
5. Replace `applyKudzuPalette` with `applyTheme` after the final legacy CSS consumer is removed.
6. Delete the old palette and duplicated primitives in the same cutover.

The packed-package gate executes this adapter through `@nunera/bracket/theme`; it does not use source-relative imports.

## API conventions

- Event callbacks use the exact names and signatures in [COMPONENTS.md](./COMPONENTS.md); native events are normally lowercase handler props such as `onclick`, `oninput`, and `onkeydown`.
- Bind only props marked `bindable` in the generated component contract; common examples include `bind:value`, `bind:open`, and `bind:selected`.
- `size`, `variant`, `intent`, and `density` are common presentation names, not guaranteed universal props.
- `disabled`, `readOnly`, `required`, and `invalid` appear only where meaningful; use the exact casing and type in the component table.
- Typed `classes` and `styles` part maps exist only where documented. Thematic changes belong in CSS variables from [THEMING.md](./THEMING.md).
- Browser-only work belongs in actions, attachments, event handlers, or guarded lifecycle code. Components remain server-renderable.

## Optional entry points

Use a focused entry to isolate heavy families:

```ts
import { CodeEditor } from '@nunera/bracket/editor';
import { LineChart } from '@nunera/bracket/charts';
import { VideoPlayer } from '@nunera/bracket/media';
import { BracketMap } from '@nunera/bracket/maps';
import { HeroSection } from '@nunera/bracket/blocks';
```

The root entry remains valid. Optional entries are clean import boundaries, not parallel APIs.

See [PACKAGE.md](./PACKAGE.md) for every supported entry point and [API.md](./API.md) for all non-component exports. Direct wildcard imports are supported by the export map, but underscore-prefixed source modules are implementation details.

## Verification after each slice

Run `pnpm check`, the component-specific test, and an actual browser path. Before release, run `pnpm verify:release` and complete the manual assistive-technology matrix in [ACCESSIBILITY.md](./ACCESSIBILITY.md).
