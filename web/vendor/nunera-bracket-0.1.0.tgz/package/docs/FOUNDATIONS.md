# Foundation contracts

Bracket's shared contracts are public, typed, SSR-safe modules. Import only the modules a component needs from `@nunera/bracket` or the matching `@nunera/bracket/headless/*` subpath.

## State and composition

`createControllableState` gives controlled and uncontrolled components one transition path. A controlled owner supplies `controlled: true`, a `value` getter, and `onChange`; an uncontrolled owner supplies only `defaultValue` and optionally `onChange`.

```ts
const state = createControllableState({
  defaultValue: false,
  controlled: true,
  value: () => open,
  onChange: (next) => (open = next)
});
```
Shared visual props use `size`, `variant`, and `intent`; state props use `disabled`, `readOnly`, `invalid`, and `required`. This is the shared naming convention, not a promise that every component has every prop. [COMPONENTS.md](./COMPONENTS.md) is authoritative for each component.

`mergeProps` composes classes, inline styles, refs, and event handlers. Consumer handlers run before internal handlers, and `preventDefault()` opts out of the internal behavior. `relationIds` and `joinIds` create stable label, description, and error relationships from a framework-owned base ID.

Polymorphic primitives that document `as` can bind `ref` and accept the corresponding native attributes. Typed `classes`/`styles` part recipes and state/placement data attributes exist only where listed in the generated component contract.

## Collections and interaction

`createCollection` provides ordered registration, disabled-item traversal, wrapping Home/End equivalents, and locale-aware prefix search. `press` normalizes mouse, touch, pen, keyboard, and assistive-technology activation around the platform `click` event while exposing pointer press state.

Overlays compose `overlayStack`, `dismissableLayer`, `focusScope`, `lockScroll`, `computePosition`, `autoUpdate`, and `createPresence`. Nested surfaces dismiss in stack order, modal focus is contained and restored, and anchored geometry is exposed through `--br-anchor-*`, `--br-available-*`, and `--br-transform-origin` variables.

## Themes and responsive values

`ThemeProvider` scopes semantic color roles and density variables to a subtree. Every built-in theme sets light or dark `color-scheme`; automated tests require 7:1 `ink`/`panel` and 4.5:1 `mute`/`panel` contrast. Foregrounds for semantic fills are selected by measured black/white contrast. See [THEMING.md](./THEMING.md) for token roles, density modes, CSS overrides, and Kudzu palette migration.

`Box` accepts responsive values shaped as `{ base, sm, md, lg, xl }`. Breakpoints use the shared 30/48/64/80rem scale and emit CSS custom properties, so no resize listener or runtime stylesheet is required.

## Accessibility

Every rendered catalog family is scanned with axe in CI. Collection keyboard behavior, modal focus containment and restoration, live-region announcements, visible `:focus-visible` rings, reduced motion, label/description/error wiring, and WCAG AA theme contrast have executable contract tests. Interactive controls use a 24px minimum target; coarse pointers raise controls toward 44px.

## Locale

`MessageProvider` scopes all built-in strings. `createLocale` exposes direction detection plus `Intl.NumberFormat`, `Intl.DateTimeFormat`, and `Intl.Collator` instances for the active locale and time zone. Components use logical inline properties so RTL does not require a second stylesheet.

## Performance and platform policy

Overlays lazy-mount and remain present only through exit motion. `memoizeOne` avoids repeated derived work; `createVirtualizer` limits large list and grid rendering. CI enforces initial-load, per-chunk, aggregate JavaScript, and CSS budgets. Browser release checks run against Chromium, Firefox, and WebKit; pointer interactions use Pointer Events and platform click semantics.

## Developer workflow

The catalog is a live interactive playground backed by `src/lib/registry/catalog.json`. Generated references cover all root-exported components in [COMPONENTS.md](./COMPONENTS.md), all other named exports in [API.md](./API.md), every package entry in [PACKAGE.md](./PACKAGE.md), and every block in [BLOCKS.md](./BLOCKS.md). `pnpm generate:docs` regenerates those references and registries. `pnpm verify` then runs documentation coverage, Svelte and TypeScript diagnostics, component and SSR suites, evidence validation, browser and accessibility checks, visual snapshots, isolated package installation, and bundle budgets. Bracket is MIT licensed and collects no telemetry.
