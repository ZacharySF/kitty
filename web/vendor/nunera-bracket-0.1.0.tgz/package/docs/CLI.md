# `bracket` CLI

The package exposes one local code-generation executable: `bracket` (`bin/bracket.mjs`). It reads the packaged block registry, writes Svelte source into the current project, performs no network requests, and does not modify `package.json` or install dependencies.

## Usage

```text
bracket list [--json]
bracket add <block> [--variant default|compact|split] [--dir src/lib] [--force] [--json]
bracket --help
```

Running `bracket` without arguments prints help. Commands and block IDs are case-sensitive.

## `list`

Lists all 39 block recipes in registry order.

```sh
bracket list
bracket list --json
```

Text output contains one block per line:

```text
dashboard-shell          Dashboard Shell [default, compact, split]
```

`--json` emits the compact JSON array from `src/lib/registry/blocks.json`. Each element has this shape:

```ts
interface BlockRecipe {
  id: string;
  name: string;
  export: string;
  variants: string[];
  files: string[];
  requirements: Array<{ tier: 'core' | 'production'; text: string }>;
}
```

Use [BLOCKS.md](./BLOCKS.md) for the complete recipe inventory and requirements.

## `add`

Copies one block wrapper and the shared block runtime into the target source tree.

```sh
bracket add hero-section
bracket add hero-section --variant split
bracket add hero-section --dir packages/web/src/lib
bracket add hero-section --variant compact --force --json
```

### Arguments and options

| Input | Required | Default | Behavior |
| --- | --- | --- | --- |
| `<block>` | yes | — | Exact registry ID, such as `hero-section`. It must immediately follow `add`. |
| `--variant <name>` | no | `default` | Initial wrapper default. Every current block supports `default`, `compact`, and `split`. |
| `--dir <path>` | no | `src/lib` | Target library directory. Relative paths resolve from the process working directory; absolute paths are accepted. |
| `--force` | no | false | Permits replacement of both generated files. Without it, either existing file stops the command before any write. |
| `--json` | no | false | Emits the compact result object instead of human-readable output. |

The generated files are:

```text
<dir>/components/<Export>.svelte
<dir>/blocks/_BlockSurface.svelte
```

The wrapper fixes `mode` to the selected block ID, sets `variant` to the requested initial default, and forwards the remaining `BlockSurfaceProps`. The runtime is copied from the installed package. Generated source is owned by the consuming project; rerunning with `--force` replaces local edits.

### Success output

Text mode:

```text
Installed HeroSection (split)
  components/HeroSection.svelte
  blocks/_BlockSurface.svelte
```

JSON mode:

```ts
interface AddResult {
  id: string;
  export: string;
  variant: string;
  files: [string, string]; // paths relative to --dir
}
```

Example:

```json
{"id":"hero-section","export":"HeroSection","variant":"split","files":["components/HeroSection.svelte","blocks/_BlockSurface.svelte"]}
```

## Failure behavior

Validation failures write a `bracket:`-prefixed message to stderr and set exit code `1`:

- missing or unknown block ID;
- unknown variant;
- either destination already exists without `--force`;
- unknown command.

Filesystem and JSON read/write failures are uncaught Node.js errors and exit nonzero with the underlying diagnostic. Generation is not transactional: a filesystem failure after the first write can leave the wrapper without the runtime. Run in a version-controlled working tree and inspect changes before committing.

`--force` is destructive for the two destination files. The CLI does not delete any other file, execute generated code, contact a service, or infer application routing, authentication, persistence, or analytics.
