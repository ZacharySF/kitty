# Theming guide

Bracket's themeable visual foundation uses CSS custom properties. A theme is a flat record of 16 semantic color roles plus a name; everything else — spacing, radius, type, shadow, z-index, breakpoints, motion — is a documented token scale. Density uses the component sizing tokens listed below.

## Token tiers

| Tier | Tokens | Changed by |
| --- | --- | --- |
| Color roles | `--br-void`, `--br-panel`, `--br-inset`, `--br-raised`, `--br-line`, `--br-lineHot`, `--br-ink`, `--br-mute`, `--br-dim`, `--br-structure`, `--br-signal`, `--br-go`, `--br-reference`, `--br-caution`, `--br-alternate`, `--br-danger` | `applyTheme`, `ThemeProvider` |
| Derived color | `--br-structure-wash`, `--br-on-structure`, `--br-on-signal`, `--br-on-go`, `--br-on-reference`, `--br-on-caution`, `--br-on-danger` | computed from the role above by `applyTheme` |
| Density | `--br-control-h`, `--br-row-py`, `--br-panel-p`, `--br-gap` | `data-br-density="compact \| comfortable \| spacious"` |
| Spacing | `--br-space-0` … `--br-space-9` (0, 2, 4, 6, 8, 12, 16, 24, 32, 48 px) | authored once in `styles.css` |
| Radius | `--br-radius-none \| sm \| md \| lg` | authored once |
| Type | `--br-text-xs \| sm \| md \| lg \| xl \| 2xl`, `--br-font-ui`, `--br-font-display`, `--br-font-icon` | authored once; `--br-font-icon` defaults to bundled Ioskeley NF with Departure Mono and Unicode fallbacks |
| Elevation | `--br-shadow-sm \| md \| lg` | authored once |
| Layering | `--br-z-base \| raised \| sticky \| overlay \| popover \| toast` | authored once |
| Breakpoints | `--br-bp-sm` (30rem), `--br-bp-md` (48rem), `--br-bp-lg` (64rem), `--br-bp-xl` (80rem) | authored once |
| Motion | `--br-motion-fast` (120ms), `--br-motion-medium` (220ms), `--br-motion-slow` (420ms), `--br-ease-standard \| entrance \| exit` | authored once; collapsed to 1ms under `prefers-reduced-motion: reduce` |

Import the stylesheet once per application:

```ts
import '@nunera/bracket/styles.css';
```

## Built-in themes

`themes` contains 14 complete themes: Kudzu, Sodium Vapor, Flight Deck, Phosphor P1, Amber VDT, Blueprint, Drafting, Oscilloscope, Hazard, Nixie, Soviet, Deep Void, Graphite, and Signal. `findTheme(name)` returns the exact match or falls back to the first theme (`Kudzu`) when no name matches.

## Applying a theme

Global, imperative:

```ts
import { applyTheme, themes, findTheme } from '@nunera/bracket/theme';

applyTheme(themes[0]);                                   // document root, comfortable density
applyTheme(findTheme('Blueprint'), undefined, 'compact');
```

Scoped, declarative — `ThemeProvider` writes the same variables onto its own element, so nested regions can differ:

```svelte
<script lang="ts">
  import { ThemeProvider, Panel } from '@nunera/bracket';
  import { findTheme } from '@nunera/bracket/theme';
</script>

<ThemeProvider theme={findTheme('Drafting')} density="spacious">
  <Panel title="Scoped region">Light theme inside a dark application.</Panel>
</ThemeProvider>
```

## Authoring a theme

A theme must supply every role in `ROLES`. Validate before applying:

```ts
import { ROLES, validTheme, contrast, onFill, themeCss, type Theme } from '@nunera/bracket/theme';

const custom = { name: 'Field', void: '#06080A', /* …all 16 roles… */ } satisfies Theme;

validTheme(custom);          // six-digit role colors, ink/panel >= 7:1, mute/panel >= 4.5:1
contrast(custom.ink, custom.panel) >= 7;  // WCAG AAA for primary body text
onFill(custom.signal);       // '#000000' or '#FFFFFF' for text drawn on that fill
themeCss(custom);            // ':root{--br-…}' string for SSR or a <style> tag
```

The automated theme gate verifies every built-in theme at 7:1 for `ink` on `panel` and 4.5:1 for `mute` on `panel`. Each `--br-on-*` pair is selected by measured black-versus-white contrast rather than a fixed guess; consumers must still test any role/surface combinations they introduce.

## Kudzu interoperability

Kudzu ships a `c1`–`c6` palette. Convert in either direction without losing the shared roles:

```ts
import { fromKudzuPalette, toKudzuPalette, applyKudzuPalette } from '@nunera/bracket/theme';

const theme = fromKudzuPalette(kudzuPalette);
applyKudzuPalette(kudzuPalette);      // convert and apply in one step
const palette = toKudzuPalette(theme);
```

## Color mode

`createColorMode` resolves `light`/`dark`/`system`, persists the choice, mirrors it onto `data-br-color-mode`/`color-scheme`, and animates the switch with a View Transition circular reveal when the browser supports it and the user has not asked for reduced motion:

```ts
import { createColorMode, colorModeScript } from '@nunera/bracket';

const mode = createColorMode();                 // reads localStorage, follows the system query
button.addEventListener('click', (event) => mode.toggle({ x: event.clientX, y: event.clientY }));
```

Avoid a first-paint flash by inlining the pre-hydration script in `<head>`:

```html
<script>/* colorModeScript() output */</script>
```

## Per-component overrides

Components that expose typed `classes` and `styles` props list them in [COMPONENTS.md](./COMPONENTS.md). Use those part maps only where documented:

```svelte
<Panel
  title="Telemetry"
  classes={{ root: 'my-panel', header: 'my-panel-header' }}
  styles={{ root: 'border-color: var(--br-signal)' }}
/>
```

Prefer token overrides (`--br-line`, `--br-gap`) on a wrapper element when the change is thematic rather than structural. Components without documented part props still accept only the native attributes and explicit props shown in their generated contract; do not assume a universal part API.

The exact TypeScript signatures for `Theme`, `ROLES`, `themes`, conversion helpers, validation, contrast, and CSS generation are in [API.md](./API.md).
