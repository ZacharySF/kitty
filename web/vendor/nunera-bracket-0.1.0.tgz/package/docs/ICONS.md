# Icons

Bracket icons are bundled font glyphs, not emoji, image requests, SVG injection, or operating-system-dependent symbols. Import `@nunera/bracket/styles.css` so the bundled Ioskeley NF faces and `--br-font-icon` token load before rendering icons.

## `Icon`

```svelte
<script lang="ts">
  import { Icon } from '@nunera/bracket';
</script>

<Icon name="search" />
<Icon name="warn" size={20} label="Warning" />
```

| Prop | Type | Default | Contract |
| --- | --- | --- | --- |
| `name` | `IconName` | required | Selects a glyph from the typed `icons` registry. |
| `size` | `number | string` | `16` | Numbers become CSS pixels; strings are used as CSS lengths. |
| `label` | `string` | — | When present, exposes `role="img"` and `aria-label`. Without it, the icon is decorative and `aria-hidden="true"`. |
| native span attributes | `HTMLAttributes<HTMLSpanElement>` | — | `class`, `style`, `data-*`, and native handlers are forwarded. |

The glyph inherits `currentColor`. Size is applied through `--br-icon-size`. Override the font stack at a scope boundary with `--br-font-icon`; the replacement font must contain the same code points or glyphs will change.

## Registry

`icons` and `IconName` are available from `@nunera/bracket`. The current names are:

| Navigation and structure | Actions and status | Objects and media |
| --- | --- | --- |
| `map`, `table`, `list`, `inbox`, `compass`, `layers`, `search`, `filter`, `target`, `history`, `calendar`, `globe`, `chevRight`, `chevDown`, `chevUp`, `arrowRight` | `undo`, `redo`, `keys`, `question`, `close`, `check`, `warn`, `error`, `info`, `eye`, `eyeOff`, `pin`, `sync`, `refresh`, `add`, `send`, `play`, `star` | `terminal`, `agent`, `paint`, `comment`, `discuss`, `video`, `camera`, `media`, `link`, `pulse`, `tower`, `database`, `server`, `shield`, `lock`, `flame`, `beaker`, `telescope`, `sparkle`, `person`, `tag`, `graph`, `note`, `law`, `bolt`, `clock`, `signal`, `gear`, `rocket`, `sun`, `moon` |

`icons[name]` returns the Private Use Area or Font Awesome-compatible Unicode string. Treat code points as implementation data; use typed names in application code.

## Interactive controls

An icon does not provide button semantics. For an action, use `IconButton` or a native button with an accessible name. `IconButton` requires `label`; its `icon` prop accepts display text/glyph content and is hidden from assistive technology because the label names the control.

Do not use a labeled `Icon` inside an already named button unless the icon conveys additional independent information. Do not communicate state with glyph or color alone; pair it with text, `aria-pressed`, `aria-current`, a status role, or another semantic state.

## Loading and fallback

Bundled font faces use `font-display: block` to avoid showing the wrong glyph from a fallback font during load. `--br-font-icon` falls back to Departure Mono and generic monospace only if Ioskeley NF fails; those fallbacks are not guaranteed to contain every private-use glyph. A failed font request is therefore a deployment error, not a supported visual mode. Preserve the emitted font assets when packaging or copying build output.
