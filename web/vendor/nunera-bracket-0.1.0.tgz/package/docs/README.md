# Bracket documentation

This directory is the canonical documentation set for the `@nunera/bracket` package. Generated references describe the shipped source; manual guides describe integration, policy, and evidence. A release must pass the documentation coverage gate so public exports, blocks, package entries, and local links cannot silently disappear from the references.

## Start here

| Need | Document |
| --- | --- |
| Install and understand package entry points | [PACKAGE.md](./PACKAGE.md) |
| Browse all 306 component contracts | [COMPONENTS.md](./COMPONENTS.md) |
| Browse all non-component TypeScript and headless APIs | [API.md](./API.md) |
| Understand foundations and ownership boundaries | [FOUNDATIONS.md](./FOUNDATIONS.md) |
| Apply themes, density, color mode, and tokens | [THEMING.md](./THEMING.md) |
| Use icons and accessible icon controls | [ICONS.md](./ICONS.md) |
| Install or integrate page blocks | [BLOCKS.md](./BLOCKS.md) and [CLI.md](./CLI.md) |
| Map design-library nodes to code | [FIGMA.md](./FIGMA.md) |
| Migrate a Kudzu application | [MIGRATION.md](./MIGRATION.md) and [KUDZU.md](./KUDZU.md) |
| Review accessibility evidence and manual gates | [ACCESSIBILITY.md](./ACCESSIBILITY.md) |
| Cut and verify a release | [RELEASE.md](./RELEASE.md) |
| Trace the original design-system requirement inventory | [UNIVERSAL_UI_REFERENCE.md](./UNIVERSAL_UI_REFERENCE.md) |

## Generated references

Do not hand-edit these files:

- `COMPONENTS.md` — generated from root-exported Svelte components, inherited props, registry ownership, and implementation contracts.
- `API.md` — generated from every non-component named root export and its source declaration.
- `PACKAGE.md` — generated from `package.json` exports and dependency policy.
- `BLOCKS.md` — generated from the 39 block recipes and their requirement records.
- `src/lib/registry/catalog.json`, `modules.json`, `blocks.json`, and `figma.json` — generated machine-readable contracts.

Regenerate the complete set with:

```sh
pnpm generate:docs
```

`pnpm test:docs` validates public-surface coverage, generated counts, Figma property coverage, historical-document status, and every relative Markdown link. `pnpm verify` regenerates first and then runs that gate with the rest of the release checks.

## Scope and release status

Bracket is pre-1.0 and currently private/workspace-distributed. The automated suite covers source contracts, rendering, interactions, accessibility rules, package consumption, production builds, and bundle budgets. Automated accessibility evidence is not certification: the NVDA/Firefox, VoiceOver/Safari, and TalkBack/Chrome rows in [ACCESSIBILITY.md](./ACCESSIBILITY.md) remain explicit manual release blockers until dated human results replace `Not run`.

`REVIEW.md` and `IMPLEMENTATION_PLAN.md` at the repository root are historical records, not current API or readiness references.
