# Kudzu integration

Kudzu and Bracket share the same field-terminal visual language. Bracket is consumed as a package boundary; Kudzu must not import files from Bracket's repository.

## Install and initialize

```sh
pnpm add @nunera/bracket@file:../../Bracket
```

```ts
import '@nunera/bracket/styles.css';
import { applyKudzuPalette } from '@nunera/bracket/theme';
import { PALETTES } from '$lib/palettes';

applyKudzuPalette(PALETTES[0], document.documentElement, 'comfortable');
```

The adapter maps `c1`–`c6` to `structure`, `signal`, `go`, `reference`, `caution`, and `alternate`, then installs legacy CSS-variable aliases. It preserves existing Kudzu surfaces while new routes use Bracket roles.

## Integration boundaries

- Kudzu owns routing, domain state, data fetching, permissions, and telemetry.
- Bracket owns typed UI state transitions, semantics, focus, theming, responsive behavior, and presentational interactions.
- CMS data enters block `content`; analytics and navigation leave through `onaction`.
- Provider-hosted payment fields remain provider-owned; Bracket never receives raw card values.

## Packed-package proof

`pnpm test:package` creates a tarball, installs it in an isolated Vite consumer, imports every optional entry point, executes `applyKudzuPalette` through the installed `@nunera/bracket/theme` entry, builds the consumer, and invokes the installed `bracket` CLI. This prevents source-workspace resolution from masking packaging defects.

See [MIGRATION.md](./MIGRATION.md) for cutover order and [THEMING.md](./THEMING.md) for token details.
