# Accessibility verification matrix

Automated checks reduce regressions; they do not certify assistive-technology usability. A release requires both automated gates and a dated manual sign-off.

## Automated gates

| Surface | Gate | Contract |
| --- | --- | --- |
| All 26 catalog families | `pnpm test:a11y` | No serious or critical axe violations |
| Keyboard interactions | `pnpm test:unit` and `pnpm test:browser` | Roving focus, Home/End, typeahead, Escape order, focus restoration |
| Themes | theme unit suite | WCAG AA text-role contrast and contrast-aware text on semantic fills |
| Motion | browser effects suite | Reduced-motion alternatives and offscreen animation pause |
| Reflow | browser and visual suites | No document overflow at 320 px; responsive snapshots |
| SSR | `pnpm test:ssr` | No unguarded browser globals; export-backed previews render |
| Blocks | block component/browser suites | Native semantics, RTL inheritance, forced-colors support, dark mode, CMS and A/B seams |

## Manual screen-reader release matrix

Record the release version, operating-system/browser/assistive-technology versions, tester, date, scenario notes, and result. `Not run` is a release blocker; automated evidence cannot change it to a pass.

| Platform | Required pairing | Keyboard/screen-reader scenarios | Status |
| --- | --- | --- | --- |
| Windows | NVDA + Firefox | Landmarks and headings; forms/errors; dialogs; menus; grids; live updates; charts/table alternative | Not run |
| macOS | VoiceOver + Safari | Rotor navigation; forms; overlays; drag alternatives; announcements; reduced motion | Not run |
| Android | TalkBack + Chrome | Swipe order; touch targets; forms; sheets; carousels; status announcements | Not run |

### Manual procedure

1. Navigate without a pointer and confirm a visible focus indicator at every step.
2. Traverse headings, landmarks, links, form controls, tables, and lists using screen-reader shortcuts.
3. Trigger validation, asynchronous loading, toasts, streaming messages, and optimistic rollback; confirm one concise announcement per state change.
4. Open nested overlays; verify initial focus, containment, Escape/back dismissal order, and restoration.
5. Exercise sortable, calendar, tree, grid, chart, editor, and media alternatives without drag, hover, color, or sound alone.
6. Repeat at 200% zoom, 320 CSS px reflow, RTL, forced colors/high contrast, dark mode, and reduced motion.
7. Log failures with component, input method, expected announcement, actual announcement, and reproducible steps.

### Sign-off record

For each platform row, replace `Not run` only after recording:

```text
Release:
Date:
Tester:
OS:
Browser:
Assistive technology:
Result: Pass | Fail
Scenarios/notes:
Issue links:
```

A failure remains a release blocker until the fix is exercised with the same pairing and the record is updated. Store recordings or external audit reports with the release evidence; this repository intentionally does not claim results that have not been run.

Consumers remain responsible for meaningful labels, alternative text, table headers, content order, and application-level route focus.
