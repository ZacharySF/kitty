# Universal UI Component Library: Exhaustive Reference

> Components, functions, and features for any kind of app or website: web apps, dashboards, marketing sites, mobile web, desktop-style tools, commerce, and AI products.
>
> Every component is split into two tiers:
> - **Core:** what any serious component library ships.
> - **Advanced:** what high-end libraries (or best-in-class standalone packages) add. These are the cutting-edge, "nice to have" features.
>
> Section 0 covers library-wide capabilities that apply to every component.

---

## Table of Contents

0. [Library-Wide Capabilities](#0-library-wide-capabilities)
1. [Layout Primitives](#1-layout-primitives)
2. [Typography & Content](#2-typography--content)
3. [Actions](#3-actions)
4. [Form Infrastructure](#4-form-infrastructure)
5. [Text & Number Inputs](#5-text--number-inputs)
6. [Selection Inputs](#6-selection-inputs)
7. [Date & Time](#7-date--time)
8. [Specialized Inputs](#8-specialized-inputs)
9. [Editors & Canvases](#9-editors--canvases)
10. [Data Display](#10-data-display)
11. [Tables & Data Grids](#11-tables--data-grids)
12. [Feedback & Status](#12-feedback--status)
13. [Overlays & Popups](#13-overlays--popups)
14. [Menus & Commands](#14-menus--commands)
15. [Navigation](#15-navigation)
16. [Disclosure & Containers](#16-disclosure--containers)
17. [Media](#17-media)
18. [Data Visualization](#18-data-visualization)
19. [Scheduling & Planning](#19-scheduling--planning)
20. [Collaboration & Social](#20-collaboration--social)
21. [AI & Conversational](#21-ai--conversational)
22. [Commerce](#22-commerce)
23. [Effects & Motion](#23-effects--motion)
24. [Utilities & Behavior (Headless)](#24-utilities--behavior-headless)
25. [Page Blocks & Templates](#25-page-blocks--templates)

---

## 0. Library-Wide Capabilities

### Architecture & API
- **Core:** controlled and uncontrolled modes for every stateful component · consistent prop vocabulary (`size`, `variant`, `color`/`intent`, `disabled`, `readOnly`, `invalid`, `required`) · ref forwarding · polymorphic rendering (`as`, `asChild`, or render prop) · compound components (`Menu.Trigger`, `Menu.Content`) · per-part style overrides (className/style on internal parts) · native HTML attribute passthrough · full TypeScript types · tree-shakeable ESM with per-component imports · SSR-safe
- **Advanced:**
  - Headless core + optional styled layer (behavior as hooks or state machines, styles separate), like Radix, Ark UI, React Aria, Base UI
  - Framework-agnostic state machines (Zag.js model) with adapters for React, Vue, Svelte, Solid
  - Copy-paste / CLI distribution (shadcn registry model): you own the source, `add` command, third-party block registries
  - Typed slot recipes (`classNames={{ root, label, indicator }}`) with variant-aware styling (CVA, Tailwind Variants, Panda recipes)
  - State exposed as data attributes for styling (`data-state="open"`, `data-highlighted`, `data-disabled`, `data-side`)
  - Runtime values exposed as CSS variables (available height/width, transform origin, anchor size)
  - React Server Component compatible, zero-JS rendering where possible, progressive enhancement before hydration
  - Strict generics (a `Select<T>` infers option type, typed form values end to end)
  - Web Components build for framework-free use
  - Low-level "builders" users can assemble into brand-new components
  - Merged props/refs/handlers when composing (Slot pattern) with event `preventDefault` opt-outs

### Theming & Design Tokens
- **Core:** light/dark mode · color palette with semantic tokens (primary, surface, border, danger) · spacing, radius, typography, shadow, z-index scales · theme provider · CSS variables · per-component overrides · responsive props (`{ base, md, lg }`)
- **Advanced:**
  - Multi-tier tokens (primitive → semantic → component) in W3C DTCG format, built with Style Dictionary
  - Figma Variables ↔ code token sync, Figma Code Connect mappings
  - Runtime theme generation from a single brand color (perceptual OKLCH/HCT ramps, auto contrast-safe foregrounds), like Material You dynamic color or Radix Colors
  - Nested/scoped themes (re-theme a subtree), multi-brand white-labeling
  - Density modes (compact, comfortable, spacious) and global radius/scale knobs
  - High-contrast and forced-colors (Windows High Contrast) support, `prefers-contrast`
  - Wide-gamut Display P3 colors, `color-mix()`, relative color syntax
  - Zero-runtime CSS compiled at build time (vanilla-extract, Panda, StyleX, Tailwind v4)
  - Visual theme editor/playground that exports config
  - Container-query responsiveness (components adapt to their slot, not the viewport)
  - CSS cascade layers (`@layer`) so user CSS always wins without `!important`

### Accessibility
- **Core:** WAI-ARIA patterns per component · full keyboard support · visible focus states · label/description wiring (`aria-labelledby`, `aria-describedby`) · focus trap in modals · focus return on close · WCAG AA contrast · screen reader announcements for dynamic content · `prefers-reduced-motion` support
- **Advanced:**
  - Roving tabindex + typeahead in every collection component
  - Virtual focus (`aria-activedescendant`) for comboboxes and grids
  - Normalized press/hover/focus across mouse, touch, pen, keyboard, and screen reader virtual cursor (React Aria `usePress` model)
  - Focus-visible heuristics (ring only for keyboard users)
  - Automated a11y tests per component (axe in CI) and a documented screen reader matrix (NVDA, JAWS, VoiceOver, TalkBack)
  - Live-region queue manager (polite/assertive, deduplicated)
  - Accessible drag and drop (keyboard moves + screen reader announcements)
  - Touch target minimums (24px / 44px) and `pointer: coarse` adaptations
  - `inert` background for modals
  - WCAG 2.2 and APCA-aware contrast tokens
  - Type-level a11y enforcement (e.g. IconButton requires `aria-label` at compile time)

### Internationalization
- **Core:** RTL support via logical properties · translatable built-in strings · locale-aware date and number formatting
- **Advanced:**
  - CLDR-backed locale data: non-Gregorian calendars (Hebrew, Islamic, Japanese, Persian, Buddhist), numbering systems, first day of week, 12/24h
  - Locale-aware collation, search, and filtering (accent/case-insensitive)
  - Bidi-safe truncation and auto-mirrored directional icons
  - ICU MessageFormat pluralization for built-in strings
  - IME composition-safe inputs (CJK typing doesn't trigger premature submit/filter)
  - Time-zone-aware date/time components

### Performance
- **Core:** tree shaking · lazy-mounted overlays · memoization · small per-component bundles
- **Advanced:**
  - Built-in virtualization for lists, selects, grids, and trees (rows + columns, variable/dynamic heights)
  - Canvas/WebGL rendering paths for huge grids and charts
  - Keep-mounted vs unmount-on-close control, lazy tab panels with keep-alive
  - Compositor-only animation (transform/opacity), FLIP technique
  - Web Worker offloading for sort/filter/parse
  - Zero layout shift loading (skeletons match final dimensions)
  - Bundle-size budgets enforced in CI
  - Islands / partial hydration friendliness

### Motion
- **Core:** enter/exit transitions for overlays · reduced-motion respect · duration and easing tokens
- **Advanced:**
  - Spring physics, interruptible animations
  - Exit animations with presence detection (unmount after animation completes)
  - Shared element / layout transitions, View Transitions API integration (same-document and cross-document)
  - Gesture-driven motion (drag, swipe, pinch with velocity and momentum)
  - Scroll-driven animations (CSS `animation-timeline: scroll()/view()`)
  - Transform-origin-aware popovers (scale out from the trigger)
  - Motion tokens and choreography (staggered children, orchestration)

### Modern Platform Integration
- **Core:** works in all evergreen browsers · touch and pointer support
- **Advanced:**
  - Native Popover API and `<dialog>` top layer (no z-index wars)
  - CSS Anchor Positioning for floating elements
  - Container queries, `:has()`, subgrid
  - Customizable native `<select>` (`appearance: base-select`)
  - `interpolate-size` / `calc-size()` for animating to `height: auto`
  - Constraint Validation API + server actions for forms
  - Haptics via Vibration API on mobile, Pointer Events pressure/tilt

### Developer Experience
- **Core:** docs with live examples · prop tables · TypeScript IntelliSense · theming guide
- **Advanced:**
  - Interactive playgrounds / Storybook with controls and a11y panel
  - Visual regression testing (Chromatic-style) and interaction tests
  - Codemods for major-version migrations
  - LLM-ready docs (`llms.txt`, an MCP server for the library, machine-readable component registry)
  - 1:1 Figma kit with Code Connect
  - Testing utilities (stable test IDs, helpers to open menus/select options in tests)
  - DevTools extension to inspect component state and tokens
  - Semantic versioning, LTS releases, clear license, no telemetry

---

## 1. Layout Primitives

### Box / View
- **Core:** generic container · style props (padding, margin, background, border, radius) · polymorphic element · responsive values
- **Advanced:**
  - Token-constrained style props with full type safety
  - Pseudo-state props (`_hover`, `_focus`, `_dark`)
  - Container query props
  - Atomic CSS compiled at build time

### Stack (VStack / HStack)
- **Core:** vertical/horizontal direction · gap · align/justify · wrap · dividers between children · responsive direction
- **Advanced:**
  - Direction switching by container width, not just viewport
  - Automatic separator injection between children
  - Intrinsic layouts ("Cluster", "Switcher", "Sidebar" algorithms from Every Layout)
  - Reverse ordering with logical properties

### Flex
- **Core:** full flexbox surface (direction, wrap, align, justify, grow, shrink, basis, gap)
- **Advanced:**
  - `Flex.Item` with responsive basis
  - Intrinsic layout presets

### Grid / Simple Grid
- **Core:** columns/rows · gap · column span/start · responsive column counts · auto-fit/auto-fill with min child width
- **Advanced:**
  - Subgrid support
  - Named template areas
  - Container-query-driven columns
  - Bento grid presets (mixed spans)
  - Draggable dashboard grid (resize handles, collision handling, compaction, layout persistence, per-breakpoint layouts)

### Container
- **Core:** max-width presets · centered · horizontal padding · fluid option
- **Advanced:**
  - Breakout / full-bleed children inside a constrained container
  - Establishes a container-query context

### Center / Square / Circle
- **Core:** center content on both axes · fixed square/circle sizing
- **Advanced:**
  - Inline centering for icons in text
  - Absolute overlay centering

### Spacer
- **Core:** flexible filler · fixed-size spacer
- **Advanced:**
  - Responsive sizes

### Divider / Separator
- **Core:** horizontal/vertical · semantic vs decorative (ARIA) · label in the middle · thickness and style (solid, dashed, dotted)
- **Advanced:**
  - Label alignment (start, center, end)
  - Gradient fade-out ends
  - Doubles as a draggable resize handle

### Aspect Ratio
- **Core:** fixed-ratio box for media · presets (16:9, 4:3, 1:1)
- **Advanced:**
  - Native `aspect-ratio` with fallback
  - Responsive ratio per breakpoint
  - Object-fit / object-position control

### Masonry
- **Core:** Pinterest-style column packing · column count · gap
- **Advanced:**
  - Responsive columns
  - Virtualization for infinite feeds
  - Order modes: sequential (reading order) vs shortest-column
  - Native CSS masonry (`display: grid-lanes`) as progressive enhancement
  - Animated reflow when items change

### Resizable Panels / Splitter
- **Core:** horizontal/vertical split · drag handle · min/max sizes · default sizes
- **Advanced:**
  - Nested panel groups
  - Collapsible panels with snap-to-collapse threshold
  - Keyboard resizing (arrows, Home/End)
  - Layout persistence (localStorage or cookie, SSR flash-free)
  - Mixed pixel and percentage constraints
  - Double-click handle to reset
  - Imperative API (collapse, expand, resize)
  - Conditionally rendered panels

### Scroll Area
- **Core:** custom styled scrollbars · horizontal/vertical · native scroll behavior preserved
- **Advanced:**
  - Visibility modes (auto-hide, hover, always, scroll-only)
  - Edge fade masks / scroll shadows indicating more content
  - Scroll snap
  - Scroll position restoration
  - Stick-to-bottom for chat and logs
  - RTL scrollbar placement

### Sticky
- **Core:** sticky positioning with offset
- **Advanced:**
  - "Stuck" state detection (restyle when pinned)
  - Stacking multiple sticky headers
  - Hide on scroll down, reveal on scroll up

### App Shell
- **Core:** header, sidebar, main, footer regions · sidebar collapses to drawer on mobile
- **Advanced:**
  - Multiple sidebars (left nav + right inspector)
  - Resizable sidebar, collapse to icon rail
  - Persisted layout state
  - Safe-area insets for notched devices
  - Independent scroll containers per region
  - Swap to bottom tab bar on mobile

---

## 2. Typography & Content

### Text
- **Core:** size/weight/color tokens · single-line truncation · multi-line clamp · alignment · polymorphic element (`p`, `span`, `label`)
- **Advanced:**
  - Fluid type scale using `clamp()`
  - `text-wrap: balance` / `pretty`
  - Automatic hyphenation
  - Optical sizing for variable fonts
  - Leading trim (`text-box-trim`) for pixel-perfect alignment
  - Tooltip only when text is actually truncated
  - Middle truncation for file names and paths (`report_fi...v2.pdf`)

### Heading
- **Core:** levels h1 to h6 decoupled from visual size · anchor link on hover
- **Advanced:**
  - Auto-generated slug IDs for deep linking
  - Automatic heading level from document outline context

### Link
- **Core:** inline and standalone · external-link icon · underline styles · visited state · router integration
- **Advanced:**
  - Prefetch on hover or viewport entry
  - Auto `rel="noopener noreferrer"` for new tabs
  - Rich link previews on hover
  - Active-route matching (exact, partial)

### Inline Code & Kbd
- **Core:** monospace inline code · keyboard key rendering · key combos
- **Advanced:**
  - Platform-aware key labels (⌘ on macOS, Ctrl elsewhere)
  - Click to copy

### Code Block
- **Core:** syntax highlighting · line numbers · copy button · language label
- **Advanced:**
  - Shiki/TextMate-grammar highlighting (VS Code accurate), theme-aware light/dark
  - Line highlighting, focus lines, diff markers (+/-)
  - Filename tab and multi-language tabs (npm / pnpm / yarn)
  - Word wrap toggle, collapsible long blocks
  - Type hovers (Twoslash)
  - Streaming-safe rendering for AI output

### Blockquote
- **Core:** quote styling · citation/attribution
- **Advanced:**
  - Pull-quote variants
  - Share-quote action

### List
- **Core:** ordered/unordered · custom markers/icons · spacing · nesting
- **Advanced:**
  - Checklist variant
  - CSS-counter-driven custom numbering

### Prose / Typography Wrapper
- **Core:** styles raw HTML/Markdown (headings, lists, tables, code, images) with consistent vertical rhythm
- **Advanced:**
  - Markdown/MDX renderer with component mapping
  - Math (KaTeX), Mermaid diagrams, footnotes, GFM tables, callouts
  - Streaming-safe Markdown (partial input renders without flicker)
  - Auto table-of-contents extraction
  - Reading time estimate

### Highlight / Mark
- **Core:** highlight substrings
- **Advanced:**
  - Fuzzy-match highlighting from a search query
  - Multiple highlight colors
  - CSS Custom Highlight API (no DOM mutation)

### Formatters
- **Core:** locale-aware number, currency, percent · date formatting · relative time ("3 min ago")
- **Advanced:**
  - Auto-updating relative time
  - Compact notation (1.2K, 3.4M), units, byte sizes
  - List formatting ("A, B, and C")
  - Hover to reveal absolute timestamp, time-zone display

### Icon
- **Core:** bundled Nerd Font or Unicode glyph component using Ioskeley NF or Departure Mono · inherits `currentColor` · size prop · accessible label or `aria-hidden` · bundled icon set
- **Advanced:**
  - Tree-shakeable multi-pack support
  - Multiple weights/styles (outline, fill, duotone)
  - Animated icons (morphing, path drawing)
  - Variable stroke width
  - Sprite sheet support
  - Auto-mirroring in RTL

### Image
- **Core:** lazy loading · alt text · fallback on error · object-fit · rounded/aspect presets
- **Advanced:**
  - Responsive `srcset`/`sizes` generation, CDN loader integration
  - Blur-up placeholders (LQIP, BlurHash, ThumbHash)
  - AVIF/WebP negotiation, art direction via `<picture>`
  - `fetchpriority` hints for LCP images
  - Focal-point cropping
  - Fade-in on load with zero layout shift
  - Zoom on hover or click

### Spoiler
- **Core:** hides content until clicked
- **Advanced:**
  - Blur or particle-noise reveal effect
  - Keyboard accessible, re-hide option

### Watermark
- **Core:** tiled text or image overlay on content
- **Advanced:**
  - Rotation, opacity, gap control
  - Tamper resistance (re-renders if removed via DevTools)
  - Dynamic text (user email + timestamp for leak tracing)

---

## 3. Actions

### Button
- **Core:** variants (solid, outline, ghost, soft, link) · sizes · intent colors (primary, neutral, danger, success) · disabled · loading state with spinner (width preserved) · leading/trailing icons · full width · `type` submit/reset/button · render as link · focus ring
- **Advanced:**
  - Async `onClick` that auto-manages pending, success, and error states
  - Hold-to-confirm for destructive actions (press-and-hold progress fill)
  - Ripple or spring-scale press feedback
  - Optimistic action + undo
  - Keyboard shortcut hint badge with global hotkey binding
  - Focusable-when-disabled with a tooltip explaining why it's disabled
  - Shimmer/shine, animated gradient border, magnetic hover
  - Morphing button that expands into a form, menu, or panel via layout animation
  - Cooldown/rate-limit state with countdown

### Icon Button
- **Core:** square/circle · required accessible label · sizes and variants matching Button
- **Advanced:**
  - Auto tooltip derived from `aria-label`
  - Pressed state with animated icon swap
  - Badge/count overlay

### Button Group
- **Core:** attached buttons · shared size/variant · horizontal/vertical
- **Advanced:**
  - Overflow into a "more" menu when space runs out
  - Responsive collapse to icon-only

### Split Button
- **Core:** primary action + dropdown of related actions
- **Advanced:**
  - Remembers last-used action as the primary
  - Arrow-key opens the menu

### Toggle (Pressed Button)
- **Core:** on/off pressed state · `aria-pressed` · icon or text
- **Advanced:**
  - Tri-state (mixed)
  - Animated icon transition

### Toggle Group / Segmented Control
- **Core:** single or multiple selection · roving keyboard focus · sizes · disabled items
- **Advanced:**
  - Animated sliding indicator (shared layout)
  - Equal-width full-bleed segments
  - Icon + label that collapses to icon-only responsively
  - Overflow scrolling

### Toolbar
- **Core:** groups of buttons, toggles, and separators · ARIA toolbar pattern · roving focus
- **Advanced:**
  - Overflow menu for items that don't fit
  - Floating/contextual toolbar anchored to a selection
  - Customizable (user can add, remove, reorder tools)

### Floating Action Button / Speed Dial
- **Core:** fixed-position primary action · extended variant with label
- **Advanced:**
  - Speed dial that fans out secondary actions with stagger
  - Hide on scroll
  - Draggable repositioning
  - Morph into a sheet or dialog

### Copy Button / Clipboard
- **Core:** copy text · success feedback state
- **Advanced:**
  - Copy rich formats (HTML + plain text) and images/blobs
  - Fallback for insecure contexts
  - Toast integration
  - Hover-reveal overlay on code blocks

### Share Button
- **Core:** Web Share API with fallback menu
- **Advanced:**
  - Per-platform share targets
  - Copy link + QR code for the link
  - Native share sheet on mobile

---

## 4. Form Infrastructure

### Form
- **Core:** submit handling · validation (required, pattern, min/max, length) · error display · reset · disabled while submitting
- **Advanced:**
  - Schema validation (Zod, Valibot, Yup, Standard Schema) with fully typed values
  - Async field-level validation with debounce and cancellation
  - Server-side errors mapped back to fields (server actions)
  - Validation modes: on blur, on change, on submit, re-validate on change after first submit
  - Focus first invalid field on submit + error summary linking to each field
  - Dirty/touched tracking, unsaved-changes guard on navigation
  - Field arrays (add, remove, reorder repeating groups)
  - Conditional and dependent fields
  - Autosave with draft persistence
  - JSON-Schema-driven form generation
  - Works without JavaScript (progressive enhancement)
  - Undo/redo of form state

### Field / Form Control
- **Core:** label + input + helper text + error message wiring · required indicator · disabled/readOnly/invalid propagated to children
- **Advanced:**
  - Floating label
  - Label positions (top, side, inline)
  - Character counter slot
  - Info tooltip on label
  - Horizontal form layouts with aligned label columns

### Label
- **Core:** associated with input · required/optional markers
- **Advanced:**
  - Click-to-focus for custom (non-native) controls

### Fieldset / Form Group
- **Core:** groups related controls with legend · group-level disabled
- **Advanced:**
  - Collapsible sections
  - Section-level validation status badge

### Input Group / Addons
- **Core:** prefix/suffix text or icons · attached buttons · clear button
- **Advanced:**
  - Inline select addon (e.g. currency or unit picker)
  - Loading indicator slot
  - Keyboard-shortcut hint slot

---

## 5. Text & Number Inputs

### Text Input
- **Core:** sizes · variants (outline, filled, underline) · placeholder · disabled/readOnly/invalid · prefix/suffix · clearable · `maxLength` · `autocomplete` attribute
- **Advanced:**
  - Debounced `onChange`
  - Input masking
  - Auto-sizing width
  - Inline validation status icon
  - Password-manager and autofill friendly
  - Paste sanitization/transform
  - IME-safe change events

### Textarea
- **Core:** rows · resize control · character count · `maxLength`
- **Advanced:**
  - Auto-grow between min/max rows
  - Mention and slash-command triggers
  - Markdown shortcuts
  - Soft limit with overflow text highlighted (X/Twitter style)
  - Spellcheck control

### Number Input
- **Core:** increment/decrement steppers · min/max/step · precision · arrow-key control
- **Advanced:**
  - Locale-aware parsing and formatting (`1.234,56`)
  - Currency, percent, and unit formats
  - Scrub-to-change (drag on the label, Figma style)
  - Opt-in mouse wheel
  - Press-and-hold acceleration
  - Modifier steps (Shift = large, Alt = fine)
  - Math expression evaluation (`12*4` → 48)
  - Clamp on blur vs live clamping

### Password Input
- **Core:** show/hide toggle · `autocomplete="new-password"` / `current-password`
- **Advanced:**
  - Strength meter (zxcvbn)
  - Live requirements checklist
  - Caps Lock warning
  - Breached-password check (Have I Been Pwned k-anonymity API)
  - Generate-password action

### Search Input
- **Core:** search icon · clear button · Enter to submit · `type="search"`
- **Advanced:**
  - Debounced query + loading indicator
  - Recent searches dropdown
  - Shortcut to focus (`/` or ⌘K)
  - Scoped filter chips inside the input
  - Query syntax highlighting (`author:sam is:open`)

### PIN / OTP Input
- **Core:** N separate cells · auto-advance · backspace to previous · paste full code · numeric or alphanumeric
- **Advanced:**
  - SMS autofill (`autocomplete="one-time-code"`, WebOTP API)
  - Masked mode
  - Grouping separators (`123-456`)
  - Auto-submit on completion
  - Single hidden input behind the cells so password managers work

### Masked Input
- **Core:** pattern masks (phone, date, card number, postal code)
- **Advanced:**
  - Dynamic masks (card type detection switches format)
  - Lazy vs eager placeholder characters
  - Raw vs formatted value output
  - Caret position preservation on edit

### Phone Input
- **Core:** country selector with flags · dial code · formatting as you type
- **Advanced:**
  - libphonenumber validation
  - Auto-detect country from input or locale
  - E.164 output
  - Searchable country list

### Tags Input
- **Core:** type and press Enter/comma to add · remove tags · max tag count
- **Advanced:**
  - Paste a list and split by delimiter
  - Duplicate prevention and per-tag validation
  - Edit a tag in place
  - Drag to reorder
  - Autocomplete suggestions

### Editable / Inline Edit
- **Core:** click to edit text in place · Enter saves, Esc cancels
- **Advanced:**
  - Activation modes (click, double-click, focus)
  - Auto-resize to content
  - Async save with optimistic UI and rollback
  - Inline validation
  - Generic editable wrapper for selects, dates, numbers

---

## 6. Selection Inputs

### Checkbox
- **Core:** checked/unchecked/indeterminate · label · description · disabled · sizes
- **Advanced:**
  - Animated check path
  - Shift-click range selection in lists
  - Card-style checkbox tiles

### Checkbox Group
- **Core:** array value · orientation · select all
- **Advanced:**
  - Indeterminate "select all" parent
  - Min/max selection constraints

### Radio Group
- **Core:** single selection · orientation · roving focus · disabled options
- **Advanced:**
  - Radio cards (rich tiles with icon, title, description)
  - Deselectable mode

### Switch
- **Core:** on/off · label · sizes · disabled
- **Advanced:**
  - Icons or text inside the thumb
  - Loading state for async toggles
  - Optimistic toggle with rollback
  - Haptic feedback on mobile

### Native Select
- **Core:** styled native `<select>` · placeholder · option groups
- **Advanced:**
  - Customizable native select (`appearance: base-select`) with rich option content

### Select / Listbox (Custom)
- **Core:** dropdown of options · placeholder · option groups · disabled options · keyboard navigation · typeahead · single or multiple
- **Advanced:**
  - Virtualized options (10k+)
  - Rich option rendering (avatars, icons, descriptions)
  - Item-aligned positioning (macOS style, selected item sits over the trigger) vs popper positioning
  - Async loading with infinite scroll
  - Creatable options
  - Multi-select with checkboxes, chips in trigger, "+N more" overflow
  - Hidden native input for forms and browser autofill
  - Mobile adaptation (bottom sheet or native picker on touch)

### Combobox / Autocomplete
- **Core:** filter as you type · keyboard navigation · free-text or restricted to options · clearable · empty state
- **Advanced:**
  - Async server search with debounce, caching, and request cancellation
  - Fuzzy matching (Fuse, match-sorter) with highlighted matches
  - Grouped/sectioned results, recent or popular items when empty
  - Inline ghost-text autocompletion
  - Multi-select with chips
  - "Create 'xyz'" option
  - Virtualized results
  - Address/places autocomplete integration

### Mention Input
- **Core:** trigger character (`@`, `#`) opens suggestions · inserts a token
- **Advanced:**
  - Multiple triggers with different data sources
  - Atomic token deletion (backspace removes the whole mention)
  - Rich chips inside a plain textarea
  - Async user/entity search

### Cascader
- **Core:** multi-level hierarchical selection (country > state > city) · selected path display
- **Advanced:**
  - Lazy-loaded children
  - Search across all levels
  - Multi-select with partial (half-checked) parents

### Tree Select
- **Core:** tree inside a dropdown · expand/collapse · single or multi
- **Advanced:**
  - Checkbox propagation (parent/child, half-checked)
  - Search that keeps matching nodes' ancestors visible
  - Virtualization and lazy children

### Transfer List / Dual Listbox
- **Core:** move items between two lists · select all · search per side
- **Advanced:**
  - Drag between lists
  - Ordering on the target side
  - Virtualization
  - One-way mode

### Slider / Range Slider
- **Core:** single value and range (two thumbs) · min/max/step · marks with labels · vertical orientation · keyboard control · value tooltip
- **Advanced:**
  - N-thumb sliders with minimum distance between thumbs
  - Logarithmic / non-linear scales
  - Distribution histogram behind the track (price filters)
  - Snap to marks
  - Thumb collision push behavior
  - Fine control with modifier keys
  - Bipolar (origin-centered) fill
  - Inverted direction
  - Haptic ticks at step stops

### Knob / Dial / Angle Slider
- **Core:** rotary control · min/max · drag to rotate
- **Advanced:**
  - Vertical-drag mode (audio plugin convention)
  - Shift for fine tuning, double-click to reset to default
  - Bipolar mode with center detent
  - Logarithmic mapping (frequency, gain)
  - Scroll wheel support
  - Value arc display

### Rating
- **Core:** star rating · half values · read-only · custom icon and count
- **Advanced:**
  - Arbitrary precision (0.1)
  - Hover preview
  - Clearable
  - Emoji/face scales with labels

### Color Picker
- **Core:** saturation/brightness area · hue slider · alpha slider · hex input · swatches
- **Advanced:**
  - Multiple color spaces (RGB, HSL, HSB, OKLCH, Display P3)
  - Eyedropper (EyeDropper API)
  - Live contrast ratio checker against a background
  - Gradient editor (stops, angle, type)
  - Palette generation from a base color
  - Recent colors and design-token swatches
  - Color wheel and per-channel sliders

---

## 7. Date & Time

### Calendar
- **Core:** month view · select date · month/year navigation · disabled dates · min/max · today indicator · configurable week start
- **Advanced:**
  - Multiple months side by side
  - Year/decade drill-down views
  - Non-Gregorian calendar systems
  - Week numbers
  - Custom day cells (price under the date, event dots)
  - Grid keyboard navigation
  - Reasons shown for unavailable dates

### Date Picker
- **Core:** input + calendar popover · format/parse · clearable · min/max
- **Advanced:**
  - Segmented date field (each part keyboard-editable, ordered per locale)
  - Natural language input ("next friday", "in 3 days")
  - Preset shortcuts
  - Native picker fallback on mobile
  - Time-zone awareness

### Date Range Picker
- **Core:** start/end selection · two-month view · range highlight
- **Advanced:**
  - Presets (Last 7 days, This quarter, YTD)
  - Comparison range (vs previous period, analytics style)
  - Min/max range length
  - Relative ranges stored as rules rather than fixed dates
  - Hover preview of the pending range

### Time Picker
- **Core:** hour/minute/second · 12/24h · step intervals
- **Advanced:**
  - Scroll-wheel columns (iOS style)
  - Analog clock face
  - Natural input ("3pm")
  - Business-hours constraints

### Date-Time Picker
- **Core:** combined date + time selection
- **Advanced:**
  - Time-zone conversion preview

### Month / Year / Quarter Picker
- **Core:** select month or year only
- **Advanced:**
  - Fiscal year and quarter modes

### Duration Input
- **Core:** hours/minutes/seconds entry
- **Advanced:**
  - ISO 8601 duration output
  - Natural language ("1h 30m")

### Time Zone Select
- **Core:** searchable IANA zones · current offset display
- **Advanced:**
  - Grouped by region, DST awareness, live current-time preview per zone

### Time Slot / Booking Picker
- **Core:** available slots per day · select a slot
- **Advanced:**
  - Viewer-local time zone conversion
  - Duration selection
  - Real-time availability with conflict handling (Calendly style)

---

## 8. Specialized Inputs

### File Upload / Dropzone
- **Core:** click or drag-and-drop · accepted types · multiple files · max size/count · file list with remove
- **Advanced:**
  - Per-file progress with pause, resume, retry
  - Chunked resumable uploads (tus protocol), direct-to-S3 presigned uploads
  - Image previews, client-side resize and compression
  - Paste from clipboard, folder upload, drop anywhere on the page
  - Mobile camera capture
  - Remote sources (URL, Google Drive, Dropbox), Uppy style
  - Per-file rejection reasons
  - Reorder files before upload

### Image Cropper / Editor
- **Core:** crop with aspect ratio · zoom · rotate
- **Advanced:**
  - Circular crop for avatars
  - Filters and adjustments
  - Annotation (draw, text, arrows)
  - Redact/blur regions
  - Undo history
  - Output size and format control

### Signature Pad
- **Core:** draw signature · clear · export PNG/SVG
- **Advanced:**
  - Pressure-sensitive stroke width (Pointer Events)
  - Bezier smoothing
  - Undo
  - Typed-signature fallback with script fonts

### Emoji Picker
- **Core:** categories · search · recently used · skin tones
- **Advanced:**
  - Virtualized grid
  - Custom emoji
  - Frequency-ranked "frequently used"
  - Native vs image rendering

### Filter Builder / Query Builder
- **Core:** rule rows (field, operator, value) · add/remove rules
- **Advanced:**
  - Nested AND/OR groups
  - Type-aware operators and value editors per field
  - Export to SQL, MongoDB, JSON
  - Natural language → filter (AI)
  - Saved filters

---

## 9. Editors & Canvases

### Rich Text Editor
- **Core:** bold/italic/underline · headings · lists · links · toolbar · undo/redo · paste handling · HTML/JSON output
- **Advanced:**
  - Real-time collaboration (Yjs CRDT) with presence cursors
  - Slash command menu and floating bubble menu on selection
  - Block-based editing (Notion style) with drag handles
  - Markdown shortcuts (`##` → heading)
  - Embeds, tables, syntax-highlighted code blocks, math
  - Mentions, comments anchored to text ranges, suggestion/track-changes mode
  - AI assist (inline completion, rewrite selection)
  - Schema-enforced content, plugin/extension API (Tiptap, ProseMirror, Lexical)
  - Version history with diffs

### Markdown Editor
- **Core:** write/preview tabs or split view · toolbar
- **Advanced:**
  - Live-render WYSIWYG Markdown (Obsidian style)
  - Paste-to-upload images
  - Synced scroll between editor and preview

### Code Editor
- **Core:** syntax highlighting · line numbers · themes · read-only mode
- **Advanced:**
  - LSP integration (completions, diagnostics, hover)
  - Multiple cursors, minimap, code folding
  - Vim/Emacs keybindings
  - Diff/merge mode
  - Collaborative editing
  - Inline AI completions (ghost text)
  - CodeMirror 6 or Monaco under the hood

### Diff Viewer
- **Core:** side-by-side and unified · added/removed highlighting
- **Advanced:**
  - Word-level intra-line diffs
  - Collapse unchanged regions
  - Inline comments
  - Syntax highlighting
  - Virtualized large files
  - Accept/reject per hunk

### Node Editor / Flow Canvas
- **Core:** nodes and edges · pan/zoom · drag nodes · connect handles
- **Advanced:**
  - Minimap and controls
  - Auto-layout (dagre, ELK)
  - Custom node types with embedded UI
  - Connection validation rules
  - Subflows/groups
  - Undo/redo, copy/paste
  - Multiplayer editing (React Flow style)

### Whiteboard / Infinite Canvas
- **Core:** shapes, text, freehand · pan/zoom · select/move/resize
- **Advanced:**
  - Multiplayer with live cursors
  - Arrows that bind to shapes
  - Frames, layers, alignment snapping
  - Export to SVG/PNG
  - Embeds (tldraw style)

### Drawing Canvas
- **Core:** freehand drawing · colors · brush size · eraser · undo
- **Advanced:**
  - Pressure sensitivity
  - Layers
  - Shape recognition (scribble → circle)

### Terminal Emulator
- **Core:** renders a shell session · ANSI colors · input
- **Advanced:**
  - WebGL renderer (xterm.js)
  - Links detection, search, copy on select
  - Resize/fit to container
  - Ligatures and Unicode width handling

---

## 10. Data Display

### Avatar & Avatar Group
- **Core:** image · initials fallback · icon fallback · sizes · shapes (circle, square)
- **Advanced:**
  - Deterministic color from a name hash
  - Status indicator (online, away, busy, offline)
  - Ring/border variants (story-style ring)
  - Lazy load with fade-in
  - Group: overlapping stack, max count with "+N" overflow, hover-to-spread, tooltip per user

### Badge
- **Core:** label pill · variants/colors · sizes · dot variant
- **Advanced:**
  - Count with max (`99+`)
  - Anchored to a corner of another element (indicator)
  - Animated count change
  - Pulse/ping for live status

### Tag / Chip
- **Core:** label · removable · leading icon or avatar · variants · clickable
- **Advanced:**
  - Selectable filter chips
  - Editable input chips
  - Truncation with tooltip
  - Color derived from category hash

### Status Indicator
- **Core:** colored dot + label (online, error, pending)
- **Advanced:**
  - Pulsing live animation
  - Uptime history bars (status-page style)

### Card
- **Core:** header/body/footer slots · media area · variants (elevated, outlined, filled) · clickable/link card
- **Advanced:**
  - Whole-card link that still allows nested interactive elements (pseudo-element pattern)
  - Hover lift or 3D tilt
  - Cursor-following spotlight glow
  - Expands into a modal via shared layout transition
  - Selectable card state
  - Drag handle for reordering
  - Matching skeleton variant

### List / List Item
- **Core:** items with leading/trailing content · dividers · interactive items · dense mode
- **Advanced:**
  - Virtualization
  - Swipe actions (iOS style)
  - Drag to reorder
  - Single/multi selection with shift-range
  - Sticky section headers
  - Infinite loading and pull-to-refresh

### Description List / Key-Value
- **Core:** label/value pairs · horizontal or vertical layout
- **Advanced:**
  - Copy-on-click values
  - Inline-editable values
  - Responsive stacking

### Stat / KPI
- **Core:** label · value · delta with up/down indicator · help text
- **Advanced:**
  - Inline sparkline
  - Animated number tick-up
  - Comparison period label
  - Goal progress
  - Semantic inversion (green when lower is better, e.g. churn)

### Timeline
- **Core:** vertical events · dots/icons · timestamps · connectors
- **Advanced:**
  - Horizontal mode
  - Alternating sides
  - Grouping by date
  - Collapsible entries
  - Zoomable time scale

### Tree View
- **Core:** nested expand/collapse · selection · icons · arrow-key navigation
- **Advanced:**
  - Virtualization
  - Lazy-loaded children
  - Drag and drop to reorder or reparent
  - Checkbox propagation
  - Inline rename
  - Multi-select
  - Filter that keeps ancestors visible
  - Typeahead
  - File-explorer mode

### Empty State
- **Core:** icon/illustration · title · description · primary action
- **Advanced:**
  - Context variants (first use, no results, error, no permission)
  - Suggested next actions

### JSON Viewer / Object Inspector
- **Core:** collapsible JSON tree · syntax colors
- **Advanced:**
  - Copy path / copy value
  - Search
  - Inline editing
  - Virtualized huge payloads
  - Type badges

### Log Viewer
- **Core:** monospaced log lines · ANSI color rendering
- **Advanced:**
  - Virtualization for millions of lines
  - Follow-tail mode
  - Filter by level and regex search
  - Line linking and timestamps toggle

### QR Code
- **Core:** render QR from a string · size · error correction level
- **Advanced:**
  - Center logo
  - Styled modules (dots, rounded)
  - Download as PNG/SVG

### Before/After Comparison Slider
- **Core:** two overlaid images with draggable divider
- **Advanced:**
  - Vertical orientation
  - Keyboard control
  - Hover-follow mode

### Countdown / Timer / Clock
- **Core:** countdown to a date · stopwatch · formatting
- **Advanced:**
  - Animated flip/roll digits
  - Server-time sync to avoid client clock drift
  - Completion callback

---

## 11. Tables & Data Grids

### Table (Basic)
- **Core:** semantic table · header/body/footer · striped · bordered · hover rows · dense · caption · horizontal scroll on small screens
- **Advanced:**
  - Sticky header and first column
  - Stacked card layout on mobile

### Data Grid / Data Table
- **Core:** sorting · filtering · pagination · row selection · column resizing · loading and empty states
- **Advanced:**
  - Virtualized rows and columns (100k+ rows)
  - Server-side mode (sort, filter, paginate remotely) with cursor pagination
  - Column pinning, reordering, hiding, grouped headers
  - Row grouping with aggregation (sum, avg) and pivot mode
  - Tree data and master-detail expandable rows
  - Inline cell editing (text, select, date) with validation and undo/redo
  - Spreadsheet-style range selection, copy/paste to Excel, fill handle
  - Faceted filters and AND/OR filter builder
  - Global search with match highlighting
  - Saved views (column order, filters, sorts)
  - Export to CSV, Excel, PDF
  - Per-cell keyboard navigation (ARIA grid)
  - Row drag reordering
  - Infinite scroll
  - Sparklines and conditional formatting inside cells
  - Live row updates with flash highlight
  - Canvas rendering for massive datasets (Glide Data Grid)
  - Column auto-size, density toggle, sticky totals footer

### Spreadsheet
- **Core:** editable cell grid · formulas · selection
- **Advanced:**
  - Formula engine (hundreds of functions), cross-sheet references
  - Multiple sheets, frozen panes, merged cells
  - Collaboration
  - XLSX import/export

---

## 12. Feedback & Status

### Alert / Callout
- **Core:** info/success/warning/error · title · description · icon · dismissible · actions
- **Advanced:**
  - Collapsible details
  - Auto-expiry
  - Persisted dismissal

### Banner / Announcement Bar
- **Core:** full-width top or bottom message · dismissible · CTA
- **Advanced:**
  - Rotating announcements
  - Scheduled display windows
  - Persisted dismissal
  - Marquee mode

### Toast / Snackbar
- **Core:** success/error/info/warning · auto-dismiss duration · action button · close · 6 placements
- **Advanced:**
  - Stacked toasts that expand on hover (Sonner style)
  - Swipe to dismiss
  - Timer pauses on hover, focus, and hidden tab
  - Promise toasts (loading → success/error)
  - Update an existing toast by ID, deduplication
  - Undo action pattern
  - Hotkey to jump to the toast region (F8)
  - Max visible count with queue
  - Remaining-time progress bar
  - Fully custom content

### Progress Bar
- **Core:** determinate · indeterminate · label/value · sizes · colors
- **Advanced:**
  - Buffer layer (video loading)
  - Multi-segment bars
  - Striped animated style
  - ETA display

### Progress Circle / Ring
- **Core:** determinate/indeterminate · value in center · thickness
- **Advanced:**
  - Concentric multi-ring (Apple Activity style)
  - Semicircle variant
  - Gradient stroke
  - Animated value

### Spinner / Loader
- **Core:** sizes · colors · accessible label
- **Advanced:**
  - Delay before showing (no flash on fast loads)
  - Minimum display time
  - Variants (dots, bars, pulse, orbit)

### Skeleton
- **Core:** text/circle/rect shapes · pulse or shimmer animation
- **Advanced:**
  - Wraps the real component and inherits its dimensions (`isLoaded` toggle)
  - Auto-generated skeleton from a component's layout
  - Crossfade into content

### Meter / Gauge
- **Core:** value within range · low/high/optimum thresholds
- **Advanced:**
  - Semicircle gauge with colored zones
  - Animated needle

### Result / Status Page
- **Core:** success, error, 403, 404, 500 states with message and actions
- **Advanced:**
  - Illustrations
  - Retry with backoff
  - Copyable error/request IDs

### Error Boundary / Fallback
- **Core:** catch render errors · fallback UI · retry
- **Advanced:**
  - Error-reporting hook (Sentry etc.)
  - Auto-reset on route change

### Connection / Offline Indicator
- **Core:** detects offline and shows a banner
- **Advanced:**
  - Queued-actions sync status
  - Reconnecting countdown

### Cookie Consent
- **Core:** accept/reject · policy link
- **Advanced:**
  - Granular categories
  - Respects Global Privacy Control
  - Consent logging
  - Script gating until consent

### Feedback Widget / Survey
- **Core:** rating scale (NPS 0 to 10, emoji, stars) · comment box
- **Advanced:**
  - Screenshot capture with annotation
  - Targeting rules (show after action X)
  - Multi-step micro-surveys

---

## 13. Overlays & Popups

### Modal / Dialog
- **Core:** open/close · backdrop · close on Esc and outside click · focus trap · focus return · scroll lock · sizes · header/body/footer
- **Advanced:**
  - Native `<dialog>` in the top layer
  - Nested/stacked dialogs with correct focus and Esc handling
  - Responsive: dialog on desktop, drawer/bottom sheet on mobile
  - Animates out of the trigger's position
  - Draggable and resizable
  - Scroll modes (inside body vs whole overlay)
  - Async close guard for unsaved changes
  - Imperative API (`await confirm(...)`)
  - URL-driven modals (intercepting routes, shareable open state)
  - Fullscreen mode

### Alert Dialog / Confirm
- **Core:** forces a decision · no outside-click dismiss · cancel focused by default on destructive actions
- **Advanced:**
  - Type-to-confirm (enter the resource name)
  - Promise-based API
  - Countdown before the confirm button enables

### Drawer / Sheet
- **Core:** slides from any edge · sizes · overlay · focus management
- **Advanced:**
  - Swipe to dismiss with velocity detection
  - Snap points
  - Non-modal mode (background stays interactive)
  - Background scale-down effect (iOS)
  - Nested drawers
  - Resizable width

### Bottom Sheet
- **Core:** mobile bottom panel · drag handle
- **Advanced:**
  - Snap points (peek, half, full)
  - Scroll handoff between sheet drag and inner content
  - Virtual-keyboard aware
  - Persistent sheet (maps-app style)

### Popover
- **Core:** anchored floating panel · click trigger · 12 placements · close on outside/Esc · arrow
- **Advanced:**
  - Collision handling: flip, shift, size to available space, hide when anchor scrolls away (Floating UI)
  - CSS Anchor Positioning + Popover API
  - Virtual anchors (cursor position, text selection)
  - Modal vs non-modal
  - Nested popovers with correct outside-click logic
  - Transform-origin animation from anchor
  - Auto-update position on scroll/resize

### Tooltip
- **Core:** hover and focus trigger · placement · delay · arrow · accessible description
- **Advanced:**
  - Delay groups (instant open after the first tooltip in a group)
  - Follow-cursor mode
  - Hoverable content with safe area
  - Long-press support on touch
  - Shows only when text is truncated
  - Rich content

### Hover Card
- **Core:** rich preview on hover (profile, link) · open/close delays
- **Advanced:**
  - Safe-polygon pointer tracking into the card
  - Prefetch data on hover intent

### Lightbox
- **Core:** fullscreen media view · next/prev · close
- **Advanced:**
  - Pinch-zoom and pan
  - Swipe navigation
  - Thumbnail strip
  - Video support
  - Shared transition from the thumbnail
  - Captions, slideshow, download/share

### Tour / Onboarding / Coachmarks
- **Core:** step-by-step highlights · next/prev/skip · spotlight on target
- **Advanced:**
  - Cutout mask around target element
  - Waits for elements or routes before advancing
  - Progress persistence
  - Branching tours
  - Onboarding checklist widget
  - Pulsing hotspots/beacons

### Floating Window
- **Core:** draggable floating panel
- **Advanced:**
  - Resize, minimize, maximize
  - Edge snapping and docking
  - Z-order management
  - Pop out to a real window (Document Picture-in-Picture API)

### Backdrop / Overlay
- **Core:** dims background · click to close
- **Advanced:**
  - Backdrop blur
  - Inert background

---

## 14. Menus & Commands

### Dropdown Menu
- **Core:** trigger + action list · icons · shortcut labels · separators · groups/labels · disabled items · keyboard navigation · typeahead
- **Advanced:**
  - Submenus with hover-intent safe triangle
  - Checkbox and radio items
  - Destructive item styling
  - Async-loaded items
  - Search within menu
  - Virtualized long menus
  - Becomes an action sheet on mobile

### Context Menu
- **Core:** right-click menu with the same item types as Dropdown
- **Advanced:**
  - Long-press on touch
  - Positioned at cursor with collision handling
  - Items depend on the current selection

### Menubar
- **Core:** desktop-app horizontal menu (File, Edit, View) · arrow-key travel between menus
- **Advanced:**
  - Platform-aware shortcut labels
  - Alt-key mnemonics
  - Checkbox/radio items

### Command Palette (⌘K)
- **Core:** global shortcut · search input · grouped results · keyboard navigation · run action
- **Advanced:**
  - Fuzzy ranking with aliases/keywords
  - Nested pages (drill into "Change theme...")
  - Recent and suggested commands
  - Async remote results
  - Context-aware commands (based on current page or selection)
  - Inline command arguments
  - Shortcut display and global registration
  - AI fallback ("Ask AI about ...")

### Action Sheet
- **Core:** list of actions from the bottom on mobile · cancel
- **Advanced:**
  - Adapts to a popover on desktop
  - Destructive styling

### Bulk Action Bar / Selection Toolbar
- **Core:** appears when items are selected · selected count · actions
- **Advanced:**
  - Slide-in animation, docked floating style (Linear style)
  - Keyboard shortcuts per action
  - "Select all N matching" across pages

---

## 15. Navigation

### Navbar / Header / App Bar
- **Core:** logo · links · actions · collapses into a hamburger menu
- **Advanced:**
  - Hide on scroll down, reveal on scroll up
  - Transparent-to-solid on scroll, backdrop blur
  - Shrink on scroll
  - Animated active indicator
  - Mega menu integration

### Hamburger / Burger Icon
- **Core:** menu toggle icon with accessible label
- **Advanced:**
  - Morphing animation into an X

### Navigation Menu / Mega Menu
- **Core:** top-level links with dropdown panels
- **Advanced:**
  - Animated shared viewport that resizes between panels (Radix NavigationMenu)
  - Hover intent
  - Rich multi-column panels

### Sidebar
- **Core:** vertical nav · sections · nested items · active state · mobile drawer
- **Advanced:**
  - Collapse to icon rail with tooltips
  - Resizable width
  - Pinned/favorites section
  - Expandable groups with persisted state
  - Toggle shortcut
  - Workspace/team switcher
  - Search within navigation

### Tabs
- **Core:** horizontal/vertical · keyboard navigation · disabled tabs · variants (line, enclosed, pills) · controlled mode
- **Advanced:**
  - Animated indicator
  - Overflow scrolling with arrows or "more" menu
  - Closable and reorderable tabs (browser style), add-tab button
  - Lazy panels with keep-alive
  - URL-synced state
  - Manual vs automatic activation

### Breadcrumbs
- **Core:** hierarchical path · separators · current page
- **Advanced:**
  - Collapse middle items into an ellipsis menu
  - Dropdown per segment to jump to siblings
  - Auto-generated from the router

### Pagination
- **Core:** prev/next · page numbers · ellipsis · current page
- **Advanced:**
  - Page size selector and jump-to-page
  - Cursor-based mode
  - "Showing 1 to 20 of 400"
  - Responsive compact mode
  - URL sync

### Stepper / Wizard
- **Core:** labeled steps · current/completed/error states · horizontal/vertical · next/back
- **Advanced:**
  - Per-step validation gating
  - Non-linear navigation and optional steps
  - Progress persistence
  - Branching flows
  - Animated step transitions

### Bottom Navigation / Tab Bar
- **Core:** 3 to 5 destinations · icon + label · active state
- **Advanced:**
  - Badges
  - Center action button
  - Hide on scroll
  - Safe-area padding

### Navigation Rail
- **Core:** compact vertical icon nav for tablet/desktop
- **Advanced:**
  - Expands into a full drawer
  - FAB slot

### Table of Contents / Scrollspy
- **Core:** list of headings · highlights active section on scroll
- **Advanced:**
  - Auto-generated from headings
  - Progress line along the TOC
  - Smooth scroll with header offset

### Skip Link
- **Core:** "Skip to content" link visible on focus
- **Advanced:**
  - Multiple skip targets (nav, search, main)

### Back to Top
- **Core:** appears after scrolling · smooth scroll up
- **Advanced:**
  - Scroll-progress ring around the button

### Language / Locale Switcher
- **Core:** list of locales · current locale
- **Advanced:**
  - Native-language labels
  - Persists choice and preserves current route

### Dock
- **Core:** row of app icons
- **Advanced:**
  - macOS-style magnification on hover
  - Bounce/launch animations

### Infinite Scroll / Load More
- **Core:** "Load more" button · sentinel-based auto-load
- **Advanced:**
  - Bidirectional loading (older messages above, chat style)
  - Scroll position restoration on back navigation
  - Combined with virtualization

### Footer
- **Core:** link columns · legal links · social icons
- **Advanced:**
  - Newsletter signup
  - Locale and theme switchers

---

## 16. Disclosure & Containers

### Accordion
- **Core:** single or multiple open · collapsible · keyboard navigation · chevron icons
- **Advanced:**
  - Smooth animation to `height: auto`
  - Lazy-rendered content
  - `hidden="until-found"` so browser find (Ctrl+F) auto-expands matches
  - Nested accordions
  - Deep-link open via URL hash

### Collapsible / Disclosure
- **Core:** show/hide a region with a trigger
- **Advanced:**
  - Native `<details>` based, find-in-page aware

### Read More / Show More
- **Core:** truncated content with expand toggle
- **Advanced:**
  - Gradient fade at cutoff
  - Line-count based clamp
  - Toggle only appears if content overflows

### Panel / Section
- **Core:** titled container
- **Advanced:**
  - Collapsible with header actions

---

## 17. Media

### Video Player
- **Core:** play/pause · seek · volume · fullscreen · captions · poster image
- **Advanced:**
  - HLS/DASH adaptive streaming with quality selector
  - Playback speed
  - Picture-in-picture
  - Chapters and thumbnail scrub previews (VTT sprites)
  - Full keyboard shortcuts
  - Audio track selection
  - AirPlay/Chromecast casting
  - Resume from last position
  - Ambient-mode glow
  - Fully composable controls (Media Chrome / Vidstack style)

### Audio Player
- **Core:** play/pause · seek · volume · time display
- **Advanced:**
  - Waveform with click-to-seek
  - Playlist/queue
  - Media Session API (lock-screen and hardware key controls)
  - Playback speed, gapless playback
  - A-B looping

### Waveform / Audio Visualizer
- **Core:** render a waveform from audio
- **Advanced:**
  - Precomputed peaks for long files
  - Regions and markers
  - Zoom
  - Spectrogram view
  - Live microphone visualization (Web Audio AnalyserNode)

### Carousel
- **Core:** slides · prev/next · dots · autoplay · loop
- **Advanced:**
  - Swipe/drag with momentum
  - Multiple slides per view, responsive
  - Free-scroll mode
  - Native scroll-snap foundation
  - Synced thumbnail navigation
  - Effects (fade, 3D coverflow, parallax)
  - Lazy-loaded slides
  - Accessibility (pause autoplay on focus/hover, slide announcements)
  - Variable-width slides
  - Plugin API (Embla style)

### Gallery
- **Core:** image grid · opens lightbox
- **Advanced:**
  - Justified rows (Flickr layout) or masonry
  - Virtualization
  - Selection mode for bulk actions

### Image Hotspots
- **Core:** pins on an image with popovers
- **Advanced:**
  - Responsive pin positioning
  - Pulsing beacons
  - Shoppable product tags

### Marquee
- **Core:** infinitely scrolling content (logos, text)
- **Advanced:**
  - Pause on hover
  - Direction and speed control, vertical mode
  - Faded edges
  - Reduced-motion fallback

### Embed
- **Core:** responsive iframe
- **Advanced:**
  - oEmbed auto-detection
  - Facade/lite embeds (load only on click, like lite-youtube)
  - Consent-gated embeds

### Map
- **Core:** map display · markers · zoom/pan
- **Advanced:**
  - Marker clustering
  - Custom vector tile styles
  - Popups
  - Drawing tools and geofences
  - Heatmap layers
  - 3D terrain
  - Geolocation

### PDF / Document Viewer
- **Core:** render pages · zoom · page navigation
- **Advanced:**
  - Text selection and search
  - Thumbnail sidebar
  - Annotations
  - Form filling
  - Virtualized pages

### 3D Model Viewer
- **Core:** renders glTF/GLB · orbit controls
- **Advanced:**
  - AR mode (WebXR, Quick Look)
  - Hotspots/annotations
  - Environment lighting
  - Auto-rotate

### Camera / Scanner
- **Core:** camera preview · capture photo
- **Advanced:**
  - Barcode/QR scanning (BarcodeDetector API)
  - Document edge detection and perspective correction
  - Camera switching

### Animation Player (Lottie / Rive)
- **Core:** plays vector animations
- **Advanced:**
  - Interactive state machines (Rive inputs)
  - Scroll-linked playback

---

## 18. Data Visualization

### Chart Types
Line · Area (stacked, streamgraph) · Bar/Column (grouped, stacked, horizontal) · Pie/Donut · Scatter/Bubble · Radar · Radial bar · Heatmap · Calendar heatmap · Treemap · Sunburst · Sankey · Funnel · Candlestick/OHLC · Box plot · Histogram · Violin · Waterfall · Gauge · Bullet · Sparkline · Network/force graph · Chord · Choropleth/geo map · Parallel coordinates

### Shared Chart Features
- **Core:** axes · legend · tooltips · responsive sizing · theme-driven colors · load animation · data labels
- **Advanced:**
  - Crosshair synced across multiple charts
  - Zoom, pan, and brush selection to filter
  - Real-time streaming data
  - Canvas/WebGL rendering for millions of points
  - Accessible charts: data-table fallback, keyboard-navigable points, sonification
  - Annotations (reference lines, regions, markers)
  - Export to PNG, SVG, CSV
  - Clickable legend to toggle series
  - Drill-down
  - Smart label collision avoidance and auto-contrast labels
  - Composable primitives (Visx/Recharts style)
  - Dual axes, log scales, time scales with gaps

### Sparkline
- **Core:** tiny inline line or bar chart
- **Advanced:**
  - Hover value readout
  - Min/max/last markers

---

## 19. Scheduling & Planning

### Event Calendar / Scheduler
- **Core:** month, week, day, agenda views · event display · click to create
- **Advanced:**
  - Drag to create, move, and resize events
  - Recurring events (RRULE)
  - Resource view (rooms or people as columns)
  - Time zones
  - Overlapping event layout
  - Virtualization
  - Drag external items onto the calendar
  - Working hours and availability shading

### Kanban Board
- **Core:** columns · cards · drag between columns
- **Advanced:**
  - WIP limits
  - Swimlanes
  - Virtualization
  - Keyboard drag and drop
  - Column reordering and collapsing
  - Optimistic moves

### Gantt Chart
- **Core:** tasks on a timeline · durations
- **Advanced:**
  - Dependency arrows
  - Critical path highlighting
  - Drag to resize/move
  - Baselines and milestones
  - Zoom levels (day, week, month)

---

## 20. Collaboration & Social

### Comments / Thread
- **Core:** comment list · reply · author and time · edit/delete
- **Advanced:**
  - Nested threads
  - Reactions and mentions
  - Resolve/reopen
  - Anchored to content (text ranges, canvas pins)
  - Real-time updates
  - Rich text bodies

### Presence & Live Cursors
- **Core:** avatars of who's here
- **Advanced:**
  - Live named cursors
  - Selection highlights per user
  - Follow mode
  - Typing indicators (Liveblocks style)

### Reactions
- **Core:** emoji counts · toggle your own
- **Advanced:**
  - Who-reacted tooltip
  - Animated burst

### Activity Feed
- **Core:** chronological actor/verb/object items
- **Advanced:**
  - Aggregation ("Sam and 4 others liked...")
  - Real-time updates
  - Infinite scroll

### Notification Center / Inbox
- **Core:** notification list · unread badge · mark as read
- **Advanced:**
  - Tabs and filters
  - Archive and snooze
  - Real-time delivery
  - Per-channel preferences
  - Grouped notifications

### User / Profile Card
- **Core:** avatar · name · role · actions
- **Advanced:**
  - Live status and local time
  - Mutual connections

### Share Dialog / Permissions
- **Core:** invite by email · role selector · copy link
- **Advanced:**
  - Link access levels (anyone with link, org only)
  - Expiring links
  - Access requests

---

## 21. AI & Conversational

### Chat / Message List
- **Core:** user and assistant bubbles · timestamps · auto-scroll to bottom · avatars
- **Advanced:**
  - Stick to bottom only when the user is already at the bottom
  - "New messages" jump button
  - Virtualized long threads
  - Message grouping
  - Branch navigation for regenerated/edited messages (`< 2/3 >`)
  - Edit and resend

### Prompt Input / Composer
- **Core:** auto-growing textarea · send button · Enter to send, Shift+Enter for newline · stop button while streaming
- **Advanced:**
  - Attachments via drag, paste, or picker
  - Slash commands and @ context mentions
  - Model selector
  - Voice input
  - Prompt history (up arrow)
  - Token/character counter
  - Draft persistence

### Streaming Response
- **Core:** incremental text rendering
- **Advanced:**
  - Streaming Markdown without flicker (handles unclosed code fences and tables)
  - Smooth token reveal
  - Caret indicator
  - Code blocks with copy/run actions

### Reasoning / Thinking Block
- **Core:** collapsible thought content
- **Advanced:**
  - Auto-collapse when finished
  - Elapsed time ("Thought for 12s")
  - Shimmer while thinking

### Tool Call / Agent Step
- **Core:** tool name · input · output · status
- **Advanced:**
  - Approve/deny gates
  - Nested task trees
  - Diff previews of proposed changes
  - Step timeline

### Citations / Sources
- **Core:** inline numbered citations · sources list
- **Advanced:**
  - Hover preview of the source
  - Favicon source chips
  - Highlight of the cited span

### Suggestion Chips
- **Core:** clickable starter prompts
- **Advanced:**
  - Context-aware follow-up suggestions

### Message Actions
- **Core:** copy · regenerate · thumbs up/down
- **Advanced:**
  - Feedback form with reasons
  - Share
  - Read aloud (TTS)

### Voice Interface
- **Core:** mic button with recording state
- **Advanced:**
  - Audio-reactive orb/waveform
  - Voice activity detection
  - Barge-in (interrupt the response)
  - Live transcript

### Artifact / Canvas Panel
- **Core:** side panel showing generated content
- **Advanced:**
  - Version history
  - Editable content
  - Preview/code toggle

---

## 22. Commerce

### Product Card
- **Core:** image · title · price · rating · add to cart
- **Advanced:**
  - Image swap on hover
  - Quick-view modal
  - Swatch previews
  - Wishlist toggle
  - Badges (sale, new, low stock)

### Price Display
- **Core:** currency formatting · sale price with strikethrough original
- **Advanced:**
  - Localized currency
  - Per-unit pricing
  - Subscription intervals
  - Tax-inclusive notes

### Quantity Selector
- **Core:** +/- stepper · min/max
- **Advanced:**
  - Stock-aware limits
  - Debounced cart sync

### Variant Selector / Swatches
- **Core:** color and size options · out-of-stock disabled
- **Advanced:**
  - Image swatches
  - Availability matrix (disables impossible combinations)
  - Size guide link

### Cart / Mini Cart
- **Core:** line items · quantities · subtotal · checkout button
- **Advanced:**
  - Slide-out drawer
  - Optimistic updates
  - Upsells
  - Free-shipping progress bar
  - Save for later

### Checkout / Payment Form
- **Core:** address fields · payment fields · order summary
- **Advanced:**
  - Apple Pay / Google Pay (Payment Request API)
  - Card type detection
  - Address autocomplete
  - Express checkout
  - Step progress

### Pricing Table
- **Core:** plan cards · feature lists · CTA · highlighted plan
- **Advanced:**
  - Monthly/annual toggle with savings
  - Feature comparison matrix
  - Usage-based pricing slider/calculator
  - Currency localization

### Coupon / Promo Code
- **Core:** input + apply · success/error states
- **Advanced:**
  - Auto-apply
  - Stacked codes

### Reviews
- **Core:** rating summary · review list
- **Advanced:**
  - Rating distribution bars
  - Filter by star rating
  - Photo reviews
  - Helpful votes

---

## 23. Effects & Motion

These come from high-end "motion" libraries (Magic UI, Aceternity UI, Motion Primitives, React Bits). Everything here is advanced by nature; the shared must-haves are reduced-motion fallbacks, GPU-only properties, and pausing when offscreen.

- **Number Ticker / Animated Number:** spring count-up, rolling digits, format-aware
- **Text Effects:** typewriter, scramble/decrypt, gradient text, shimmer text, word rotate, split-text reveal, blur-in, morphing text
- **Text Highlighter:** animated marker underline/highlight on scroll into view
- **Animated Border / Border Beam:** light that travels around a border
- **Spotlight / Glow:** cursor-following radial light
- **Tilt / 3D Card:** perspective tilt following the mouse, with glare
- **Magnetic:** element pulled toward the cursor
- **Parallax:** layers moving at different scroll speeds
- **Scroll Reveal / Blur Fade:** elements animate in when entering the viewport
- **Scroll Progress Bar:** reading-progress indicator
- **Shared Layout / Morph Transitions:** elements morph between states or pages
- **Animated List:** items enter and exit with springs
- **Confetti / Fireworks:** celebration bursts
- **Particles / Starfield / Meteors / Sparkles**
- **Backgrounds:** grid and dot patterns, animated mesh gradients, aurora, noise/grain, retro grid, light beams
- **Ripple:** expanding concentric rings
- **Animated Beam:** animated connector lines between elements (integration diagrams)
- **Orbiting Circles:** icons orbiting a center
- **Interactive Globe:** 3D globe with arcs and markers
- **Lens / Magnifier:** zoom lens following the cursor
- **Custom Cursor / Cursor Trail**
- **Hover Image Reveal:** image follows cursor over list items
- **Animated Icons:** morphing or path-drawing icons

---

## 24. Utilities & Behavior (Headless)

Non-visual building blocks that high-end libraries expose directly.

- **Portal:** render outside the DOM hierarchy, custom container, shadow DOM support
- **Focus Scope / Focus Trap:** contain focus, auto-focus first element, restore on unmount
- **Dismissable Layer:** outside-click and Esc handling with correct layer stacking
- **Visually Hidden:** content for screen readers only
- **Presence:** keeps elements mounted until exit animation completes
- **Slot / asChild:** merges props, refs, and handlers onto a child element
- **Live Announcer:** programmatic screen reader announcements
- **Hotkeys Manager:** scoped shortcuts, key sequences (`g` then `i`), conflict detection, auto-generated cheat sheet (`?`)
- **Drag and Drop / Sortable:** pointer, touch, and keyboard sensors, collision strategies, auto-scroll, drop animations, multiple containers, screen reader announcements
- **Virtualizer:** fixed, variable, and dynamic sizes, horizontal, grid, sticky items, reverse mode (chat), scroll to index
- **In-View / Intersection Observer**
- **Measure / Resize Observer**
- **Media Query & Breakpoint hooks, Show/Hide responsive wrappers**
- **Color Mode / Theme Toggle:** system preference, no flash on load (pre-hydration script), animated toggle (View Transition circular reveal)
- **Locale & Direction Providers**
- **Client Only / No SSR wrapper**
- **Clipboard hook**
- **Undo/Redo manager**
- **Persisted State:** URL query-param state sync, localStorage state
- **Error and Suspense boundaries**
- **Scroll Lock:** scrollbar gutter compensation, iOS Safari support
- **Click Outside, Long Press, Gestures** (swipe, pinch, drag via Pointer Events)
- **Idle and Page Visibility detection**
- **Download helper**

---

## 25. Page Blocks & Templates

High-end libraries ship pre-composed sections on top of components.

- **App blocks:** dashboard shell, settings pages, auth (sign in, sign up, forgot password, MFA, magic link), onboarding flow, profile, billing, team management, data table page, mail/inbox, chat app, file manager, kanban app, calendar app
- **Marketing blocks:** hero (many variants), logo cloud, feature grid/bento, testimonials, stats, pricing, FAQ, CTA, newsletter, blog list/post, changelog, team, contact form, comparison table, waitlist, footer
- **System pages:** 404, 500, maintenance, coming soon, no permission
- **Advanced:**
  - Block registry with variants installable via CLI
  - Responsive and dark-mode ready out of the box
  - CMS integration hooks
  - A/B variant support
