# Page blocks

Bracket ships 39 root-exported and focused-entry page blocks. Every block specializes the shared runtime; the `mode` prop is fixed internally.

## Shared contract

```ts
interface BlockContent { title?: string; description?: string; cta?: string; eyebrow?: string }
interface BlockSurfaceProps {
  variant?: 'default' | 'compact' | 'split';
  experiment?: 'A' | 'B';
  content?: BlockContent;
  onaction?: (detail: { block: string; action: string; experiment: 'A' | 'B' }) => void;
}
```

`content` is the serializable CMS seam. `onaction` is the routing/analytics seam and does not select a vendor. Blocks inherit direction and theme from their parent, use container-query reflow, and expose native controls. Applications remain responsible for routing, persistence, authentication, authorization, form delivery, and domain data.

## Package example

```svelte
<script lang="ts">
  import { HeroSection } from '@nunera/bracket/blocks';
</script>

<HeroSection
  variant="split"
  experiment="B"
  content={{ title: 'Coordinate every mission', cta: 'Open console' }}
  onaction={({ action, experiment }) => track(action, experiment)}
/>
```

## Inventory

| Registry ID | Export | Variants |
| --- | --- | --- |
| `dashboard-shell` | `DashboardShell` | `default`, `compact`, `split` |
| `settings-page` | `SettingsPage` | `default`, `compact`, `split` |
| `sign-in` | `SignIn` | `default`, `compact`, `split` |
| `sign-up` | `SignUp` | `default`, `compact`, `split` |
| `forgot-password` | `ForgotPassword` | `default`, `compact`, `split` |
| `mfa-challenge` | `MfaChallenge` | `default`, `compact`, `split` |
| `magic-link` | `MagicLink` | `default`, `compact`, `split` |
| `onboarding-flow` | `OnboardingFlow` | `default`, `compact`, `split` |
| `profile-page` | `ProfilePage` | `default`, `compact`, `split` |
| `billing-page` | `BillingPage` | `default`, `compact`, `split` |
| `team-management` | `TeamManagement` | `default`, `compact`, `split` |
| `data-table-page` | `DataTablePage` | `default`, `compact`, `split` |
| `mail-inbox-app` | `MailInboxApp` | `default`, `compact`, `split` |
| `chat-app` | `ChatApp` | `default`, `compact`, `split` |
| `file-manager` | `FileManager` | `default`, `compact`, `split` |
| `kanban-app` | `KanbanApp` | `default`, `compact`, `split` |
| `calendar-app` | `CalendarApp` | `default`, `compact`, `split` |
| `hero-section` | `HeroSection` | `default`, `compact`, `split` |
| `logo-cloud` | `LogoCloud` | `default`, `compact`, `split` |
| `feature-grid-bento` | `FeatureGridBento` | `default`, `compact`, `split` |
| `testimonials` | `Testimonials` | `default`, `compact`, `split` |
| `stats-section` | `StatsSection` | `default`, `compact`, `split` |
| `pricing-section` | `PricingSection` | `default`, `compact`, `split` |
| `faq-section` | `FaqSection` | `default`, `compact`, `split` |
| `cta-section` | `CtaSection` | `default`, `compact`, `split` |
| `newsletter-signup` | `NewsletterSignup` | `default`, `compact`, `split` |
| `blog-list` | `BlogList` | `default`, `compact`, `split` |
| `blog-post` | `BlogPost` | `default`, `compact`, `split` |
| `changelog` | `ChangelogBlock` | `default`, `compact`, `split` |
| `team-section` | `TeamSection` | `default`, `compact`, `split` |
| `contact-form` | `ContactFormBlock` | `default`, `compact`, `split` |
| `comparison-table` | `ComparisonTable` | `default`, `compact`, `split` |
| `waitlist` | `Waitlist` | `default`, `compact`, `split` |
| `marketing-footer` | `MarketingFooter` | `default`, `compact`, `split` |
| `404-page` | `NotFoundPage` | `default`, `compact`, `split` |
| `500-page` | `ServerErrorPage` | `default`, `compact`, `split` |
| `maintenance-page` | `MaintenancePage` | `default`, `compact`, `split` |
| `coming-soon-page` | `ComingSoonPage` | `default`, `compact`, `split` |
| `no-permission-page` | `NoPermissionPage` | `default`, `compact`, `split` |

## Dashboard Shell

- **Registry ID:** `dashboard-shell`
- **Export:** `DashboardShell` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add dashboard-shell`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/DashboardShell.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Dashboard Shell
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Settings Page

- **Registry ID:** `settings-page`
- **Export:** `SettingsPage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add settings-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/SettingsPage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Settings Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Sign In

- **Registry ID:** `sign-in`
- **Export:** `SignIn` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add sign-in`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/SignIn.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Sign In
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Sign Up

- **Registry ID:** `sign-up`
- **Export:** `SignUp` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add sign-up`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/SignUp.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Sign Up
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Forgot Password

- **Registry ID:** `forgot-password`
- **Export:** `ForgotPassword` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add forgot-password`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/ForgotPassword.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Forgot Password
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## MFA Challenge

- **Registry ID:** `mfa-challenge`
- **Export:** `MfaChallenge` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add mfa-challenge`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/MfaChallenge.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: MFA Challenge
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Magic Link

- **Registry ID:** `magic-link`
- **Export:** `MagicLink` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add magic-link`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/MagicLink.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Magic Link
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Onboarding Flow

- **Registry ID:** `onboarding-flow`
- **Export:** `OnboardingFlow` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add onboarding-flow`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/OnboardingFlow.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Onboarding Flow
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Profile Page

- **Registry ID:** `profile-page`
- **Export:** `ProfilePage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add profile-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/ProfilePage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Profile Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Billing Page

- **Registry ID:** `billing-page`
- **Export:** `BillingPage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add billing-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/BillingPage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Billing Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Team Management

- **Registry ID:** `team-management`
- **Export:** `TeamManagement` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add team-management`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/TeamManagement.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Team Management
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Data Table Page

- **Registry ID:** `data-table-page`
- **Export:** `DataTablePage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add data-table-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/DataTablePage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Data Table Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Mail / Inbox App

- **Registry ID:** `mail-inbox-app`
- **Export:** `MailInboxApp` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add mail-inbox-app`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/MailInboxApp.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Mail / Inbox App
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Chat App

- **Registry ID:** `chat-app`
- **Export:** `ChatApp` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add chat-app`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/ChatApp.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Chat App
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## File Manager

- **Registry ID:** `file-manager`
- **Export:** `FileManager` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add file-manager`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/FileManager.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: File Manager
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Kanban App

- **Registry ID:** `kanban-app`
- **Export:** `KanbanApp` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add kanban-app`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/KanbanApp.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Kanban App
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Calendar App

- **Registry ID:** `calendar-app`
- **Export:** `CalendarApp` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add calendar-app`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/CalendarApp.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Calendar App
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Hero Section

- **Registry ID:** `hero-section`
- **Export:** `HeroSection` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add hero-section`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/HeroSection.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Hero Section
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Logo Cloud

- **Registry ID:** `logo-cloud`
- **Export:** `LogoCloud` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add logo-cloud`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/LogoCloud.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Logo Cloud
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Feature Grid / Bento

- **Registry ID:** `feature-grid-bento`
- **Export:** `FeatureGridBento` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add feature-grid-bento`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/FeatureGridBento.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Feature Grid / Bento
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Testimonials

- **Registry ID:** `testimonials`
- **Export:** `Testimonials` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add testimonials`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/Testimonials.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Testimonials
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Stats Section

- **Registry ID:** `stats-section`
- **Export:** `StatsSection` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add stats-section`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/StatsSection.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Stats Section
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Pricing Section

- **Registry ID:** `pricing-section`
- **Export:** `PricingSection` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add pricing-section`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/PricingSection.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Pricing Section
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## FAQ Section

- **Registry ID:** `faq-section`
- **Export:** `FaqSection` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add faq-section`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/FaqSection.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: FAQ Section
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## CTA Section

- **Registry ID:** `cta-section`
- **Export:** `CtaSection` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add cta-section`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/CtaSection.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: CTA Section
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Newsletter Signup

- **Registry ID:** `newsletter-signup`
- **Export:** `NewsletterSignup` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add newsletter-signup`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/NewsletterSignup.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Newsletter Signup
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Blog List

- **Registry ID:** `blog-list`
- **Export:** `BlogList` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add blog-list`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/BlogList.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Blog List
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Blog Post

- **Registry ID:** `blog-post`
- **Export:** `BlogPost` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add blog-post`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/BlogPost.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Blog Post
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Changelog

- **Registry ID:** `changelog`
- **Export:** `ChangelogBlock` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add changelog`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/ChangelogBlock.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Changelog
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Team Section

- **Registry ID:** `team-section`
- **Export:** `TeamSection` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add team-section`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/TeamSection.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Team Section
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Contact Form

- **Registry ID:** `contact-form`
- **Export:** `ContactFormBlock` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add contact-form`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/ContactFormBlock.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Contact Form
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Comparison Table

- **Registry ID:** `comparison-table`
- **Export:** `ComparisonTable` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add comparison-table`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/ComparisonTable.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Comparison Table
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Waitlist

- **Registry ID:** `waitlist`
- **Export:** `Waitlist` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add waitlist`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/Waitlist.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Waitlist
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Marketing Footer

- **Registry ID:** `marketing-footer`
- **Export:** `MarketingFooter` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add marketing-footer`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/MarketingFooter.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Marketing Footer
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## 404 Page

- **Registry ID:** `404-page`
- **Export:** `NotFoundPage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add 404-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/NotFoundPage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: 404 Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## 500 Page

- **Registry ID:** `500-page`
- **Export:** `ServerErrorPage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add 500-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/ServerErrorPage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: 500 Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Maintenance Page

- **Registry ID:** `maintenance-page`
- **Export:** `MaintenancePage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add maintenance-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/MaintenancePage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Maintenance Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## Coming Soon Page

- **Registry ID:** `coming-soon-page`
- **Export:** `ComingSoonPage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add coming-soon-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/ComingSoonPage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: Coming Soon Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

## No Permission Page

- **Registry ID:** `no-permission-page`
- **Export:** `NoPermissionPage` from `@nunera/bracket` or `@nunera/bracket/blocks`
- **CLI:** `bracket add no-permission-page`
- **Variants:** `default`, `compact`, `split`
- **Installed files:** `components/NoPermissionPage.svelte`, `blocks/_BlockSurface.svelte`
- **Requirements:**
  - core: No Permission Page
  - advanced: Block registry with variants installable via CLI
  - advanced: Responsive and dark-mode ready out of the box
  - advanced: CMS integration hooks
  - advanced: A/B variant support

